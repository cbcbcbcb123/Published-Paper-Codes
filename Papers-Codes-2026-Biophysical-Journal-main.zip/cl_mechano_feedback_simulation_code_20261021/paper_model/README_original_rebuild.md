# Theory rebuild for manuscript Figures 2, 3, and 5

This package replaces the previous hand-constructed slow-manifold landscape with a single, auditable stochastic model:

`dZ = b(Z; theta) dt + sqrt(2D) dW`, reflected on `[0,1]^2`.

The same drift and canonical parameter file are used for deterministic bifurcation analysis, the conservative stationary Fokker-Planck solve, mutual information, deterministic basin classification, backward-Kolmogorov mean first-passage times, Freidlin-Wentzell minimum-action paths, and reflected SDE validation.

## Numerical design

- Fokker-Planck: exponentially fitted finite-volume/continuous-time Markov generator.
- Boundaries: reflecting, implemented by zero rates through the four outer faces.
- Stationary density: null vector of the forward generator with exact normalization.
- MFPT: backward generator with the opposite deterministic basin treated as absorbing.
- Freidlin-Wentzell: geometric action minimized between each attractor and the saddle.
- SDE: Euler-Maruyama with normal reflection; used only as an independent validation layer.

## Scientific guardrails

- `D` and the physical time unit are not treated as measured quantities until calibration data are supplied.
- Grade-linked stiffness and feedback-strength values remain representative anchors, not patient-specific measurements.
- Strong irreversibility claims are retained only if FPE, minimum-action, backward-MFPT, SDE, and convergence results agree over a prespecified uncertainty range.
- Existing manuscript files and figures are not overwritten by this package.
