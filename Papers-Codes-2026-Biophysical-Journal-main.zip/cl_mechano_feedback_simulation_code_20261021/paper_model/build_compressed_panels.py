from __future__ import annotations

import html
import json
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import build_final_panels as base


ROOT = Path(__file__).resolve().parent
FIGURES_ROOT = base.FIGURES_ROOT
FINAL_RESULTS = base.FINAL_RESULTS
DATE = base.DATE
COLORS = base.COLORS

COMPRESSED_META = {
    "fig3A": (
        "fig3a_information_compressed_v03_20260712",
        "FPE information across stiffness and noise",
    ),
    "fig3B": (
        "fig3b_tcga_grade_compressed_v03_20260712",
        "TCGA grade-stratified association",
    ),
    "fig5A": (
        "fig5a_stationary_fw_compressed_v03_20260712",
        "Stationary FPE and action paths",
    ),
    "fig5B": (
        "fig5b_mfpt_sde_compressed_v03_20260712",
        "Noise-dependent kinetics and SDE validation",
    ),
}

SOURCE_SLUGS = {
    "fig3A": "fig3a_fpe_mutual_information_reviewed_v02_20260712",
    "fig3B": "fig3b_tcga_grade_correlation_reviewed_v02_20260712",
    "fig3C": "fig3c_information_map_reviewed_v02_20260712",
    "fig5A": "fig5a_stationary_map_reviewed_v02_20260712",
    "fig5B": "fig5b_mfpt_noise_reviewed_v02_20260712",
    "fig5C": "fig5c_marginal_sde_reviewed_v02_20260712",
}


def source_csv(panel: str) -> Path:
    return FIGURES_ROOT / panel / f"01-原始数据-{SOURCE_SLUGS[panel]}.csv"


def save_compressed(panel: str, figure, rows: list[dict], methods: str) -> dict[str, Path]:
    original_meta = base.PANEL_META[panel]
    base.PANEL_META[panel] = COMPRESSED_META[panel]
    try:
        paths = base.save_panel(panel, figure, rows, methods)
    finally:
        base.PANEL_META[panel] = original_meta
    wrapper = f'''from pathlib import Path
import sys

ROOT = Path(r"{ROOT}")
sys.path.insert(0, str(ROOT))

from build_compressed_panels import build_named

if __name__ == "__main__":
    build_named("{panel}")
'''
    paths["script"].write_text(wrapper, encoding="utf-8")
    return paths


def tagged_records(frame: pd.DataFrame, source_panel: str) -> list[dict]:
    records = []
    for record in frame.to_dict("records"):
        record["source_panel"] = source_panel
        records.append(record)
    return records


def build_fig3A() -> dict[str, Path]:
    curve_frame = pd.read_csv(source_csv("fig3A"))
    map_frame = pd.read_csv(source_csv("fig3C"))
    heat_rows = map_frame[map_frame["series"] == "FPE_MI_map"].copy()
    reference_rows = curve_frame[
        (curve_frame["series"] == "FPE_MI") & np.isclose(curve_frame["D"], 0.008)
    ].copy()
    onset = float(curve_frame.loc[curve_frame["series"] == "bistability_onset", "E_kpa"].iloc[0])

    pivot = heat_rows.pivot(index="D", columns="E_kpa", values="MI_nats").sort_index().sort_index(axis=1)
    stiffness = pivot.columns.to_numpy(dtype=float)
    diffusions = pivot.index.to_numpy(dtype=float)
    heat = pivot.to_numpy(dtype=float)

    figure, axis = plt.subplots(figsize=(3.35, 2.70))
    image = axis.pcolormesh(stiffness, diffusions, heat, shading="auto", cmap="cividis")
    colorbar = figure.colorbar(image, ax=axis, pad=0.025, fraction=0.06)
    colorbar.set_label("MI (nats)", fontsize=7)
    colorbar.ax.tick_params(labelsize=6)
    axis.axhline(0.008, color="white", ls="--", lw=1.0)
    axis.axvline(onset, color="white", ls=":", lw=1.0)
    axis.text(22.8, 0.00835, "reference D", color="white", ha="right", va="bottom", fontsize=5.7)
    axis.text(onset + 0.35, 0.0192, "bistability onset", color="white", ha="left", va="top", fontsize=5.5)
    axis.set(
        xlabel="ECM stiffness, E (kPa)",
        ylabel="noise intensity, D",
        title="FPE information across stiffness and noise",
    )

    inset = axis.inset_axes([0.57, 0.53, 0.38, 0.37])
    reference_rows = reference_rows.sort_values("E_kpa")
    inset.plot(
        reference_rows["E_kpa"],
        reference_rows["MI_nats"],
        color=COLORS["blue"],
        lw=1.35,
        marker="o",
        ms=1.9,
    )
    inset.axvline(onset, color=COLORS["gray"], ls=":", lw=0.8)
    inset.set(xlim=(1, 25), xlabel="E (kPa)", ylabel="MI", title="D = 0.008 cut")
    inset.patch.set_facecolor("white")
    inset.patch.set_alpha(0.93)
    inset.tick_params(labelsize=4.8, length=2)
    inset.xaxis.label.set_size(5.2)
    inset.yaxis.label.set_size(5.2)
    inset.title.set_size(5.5)

    rows = tagged_records(heat_rows, "fig3C_v02") + tagged_records(reference_rows, "fig3A_v02")
    rows.append(
        {
            "series": "bistability_onset",
            "source_panel": "fig3A_v02",
            "delta1": 1.4,
            "E_kpa": onset,
        }
    )
    methods = base.common_methods(
        "Fig3A compressed",
        "This panel compresses the previous Fig. 3A and Fig. 3C without changing their numerical values. The main field is the 28x28-grid stationary reflecting-FPE mutual-information scan over stiffness and D. The inset is the independently retained 40x40 reference cut at D=0.008. The horizontal dashed line marks the uncalibrated reference D; the vertical dotted line marks the deterministic bistability onset at delta1=1.4.",
        "The heat map is a model sensitivity analysis, not a fitted biological distribution. The inset and main field use their recorded grid sizes, both retained in the CSV. D remains uncalibrated.",
    )
    return save_compressed("fig3A", figure, rows, methods)


def build_fig3B() -> dict[str, Path]:
    frame = pd.read_csv(source_csv("fig3B"))
    summary = frame[frame["record_type"] == "summary"].copy().sort_values("grade_index")
    x_values = summary["grade_index"].to_numpy(dtype=float)
    rho = summary["spearman_rho"].to_numpy(dtype=float)
    low = summary["ci95_low"].to_numpy(dtype=float)
    high = summary["ci95_high"].to_numpy(dtype=float)
    grades = summary["grade"].astype(str).tolist()

    figure, axis = plt.subplots(figsize=(3.18, 2.70))
    axis.errorbar(
        x_values,
        rho,
        yerr=[rho - low, high - rho],
        fmt="D",
        ms=4.2,
        color=COLORS["blue"],
        ecolor="#9BBAD8",
        elinewidth=1.35,
        capsize=3,
    )
    for x_value, sample_size in zip(x_values, summary["n"].astype(int)):
        axis.text(x_value, 0.965, f"n={sample_size}", ha="center", va="top", fontsize=6.0, color=COLORS["gray"])
    axis.set(
        xticks=x_values,
        xticklabels=grades,
        xlim=(0.75, 4.25),
        ylim=(0, 1),
        xlabel="TCGA-LIHC tumour grade",
        ylabel=r"Spearman $\rho$(ITGB1, YAP1)",
        title="TCGA grade-stratified association",
    )
    methods = base.common_methods(
        "Fig3B compressed",
        "This is the retained TCGA-LIHC grade-stratified Spearman analysis. Point estimates and percentile 95% intervals are copied from the reviewed v02 panel, which recomputed rho and used 10,000 within-grade bootstrap resamples with seed 20260712. The bootstrap grade-slope support remains in the CSV and methods record rather than being promoted as an in-panel significance claim.",
        "These are bulk-tumour patient-level correlations, not stationary single-cell FPE distributions. The G4 interval is wide because n=12. No stiffness value is assigned to TCGA grades.",
    )
    return save_compressed("fig3B", figure, tagged_records(frame, "fig3B_v02"), methods)


def build_fig5A() -> dict[str, Path]:
    frame = pd.read_csv(source_csv("fig5A"))
    validation = json.loads((FINAL_RESULTS / "final_validation_summary.json").read_text(encoding="utf-8"))
    density_rows = frame[frame["series"] == "stationary_density"].copy()
    pivot = density_rows.pivot(index="y", columns="x", values="display_relative_log10_density").sort_index().sort_index(axis=1)
    x_values = pivot.columns.to_numpy(dtype=float)
    y_values = pivot.index.to_numpy(dtype=float)
    display_density = pivot.to_numpy(dtype=float)
    paths = frame[frame["series"] == "minimum_action_path"].copy()
    points = frame[frame["series"] == "fixed_point"].copy()

    figure, axis = plt.subplots(figsize=(3.30, 2.72))
    image = axis.contourf(
        x_values,
        y_values,
        display_density,
        levels=np.linspace(-12.0, 0.0, 25),
        cmap="magma",
        extend="min",
    )
    colorbar = figure.colorbar(image, ax=axis, pad=0.025, fraction=0.06)
    colorbar.set_label(r"$\log_{10}[p/p_{\max}]$ (clipped)", fontsize=7)
    colorbar.ax.tick_params(labelsize=6)

    for direction, color in [("normal_to_saddle", COLORS["blue"]), ("high_to_saddle", COLORS["red"])]:
        selected = paths[paths["direction"] == direction].sort_values("node")
        axis.plot(selected["x"], selected["y"], color=color, lw=1.85)
    for _, point in points.sort_values("x").iterrows():
        label = str(point["label"])
        if label == "S":
            axis.scatter(point["x"], point["y"], s=30, marker="s", facecolor="white", edgecolor=COLORS["gray"], lw=0.9, zorder=5)
            text_color = COLORS["black"]
        else:
            point_color = COLORS["blue"] if label == "L" else COLORS["red"]
            axis.scatter(point["x"], point["y"], s=28, color=point_color, edgecolor="white", lw=0.7, zorder=5)
            text_color = "white" if label == "H" else COLORS["black"]
        axis.text(point["x"] + 0.022, point["y"] + 0.018, label, fontsize=6.7, fontweight="bold", color=text_color)

    action = validation["minimum_action_final"]
    mass = validation["baseline"]["high_basin_mass"]
    axis.text(0.105, 0.125, "L→S", color=COLORS["blue"], fontsize=5.7, fontweight="bold")
    axis.text(0.405, 0.455, "H→S", color=COLORS["red"], fontsize=5.7, fontweight="bold")
    axis.text(
        0.98,
        0.035,
        rf"$P_H={mass:.4f}$;  $S_{{L\to S}}={action['action_normal_to_saddle']:.5f}$;  $S_{{H\to S}}={action['action_high_to_saddle']:.5f}$",
        transform=axis.transAxes,
        ha="right",
        va="bottom",
        fontsize=5.0,
        bbox={"facecolor": "white", "edgecolor": "#D5D9DD", "alpha": 0.90, "pad": 2.5},
    )
    axis.set(
        xlim=(0, 0.75),
        ylim=(0, 0.78),
        xlabel="normalized ITGB1, x",
        ylabel="normalized YAP/TEAD, y",
        title="Stationary FPE and FW action paths",
    )
    methods = base.common_methods(
        "Fig5A compressed",
        "This is the reviewed 100x100 reflecting stationary FPE at delta1=1.5, E=15 kPa and D=0.008 with both independently optimized 64-node Freidlin-Wentzell geometric action paths. The panel now directly reports the high-basin stationary mass and both action values, replacing the need for a separate marginal-weight panel.",
        "The displayed field is log10[p/p_max], clipped below -12 only for legibility; the CSV retains the unclipped density and log-density. It is not a thermodynamic energy landscape. D remains uncalibrated.",
    )
    return save_compressed("fig5A", figure, tagged_records(frame, "fig5A_v02"), methods)


def build_fig5B() -> dict[str, Path]:
    mfpt_frame = pd.read_csv(source_csv("fig5B"))
    validation_frame = pd.read_csv(source_csv("fig5C"))
    validation = json.loads((FINAL_RESULTS / "final_validation_summary.json").read_text(encoding="utf-8"))
    curve = mfpt_frame[mfpt_frame["series"] == "backward_MFPT_ratio"].copy().sort_values("D")
    sde = validation_frame[
        (validation_frame["series"] == "SDE_timestep_validation")
        & np.isclose(validation_frame["time_step"], 0.0025)
    ].copy()
    threshold = float(validation["D_threshold_mean"])
    half_range = float(validation["D_threshold_half_range"])
    reference_D = float(validation["baseline"]["D"])

    figure, axis = plt.subplots(figsize=(3.30, 2.72))
    axis.semilogy(
        curve["D"],
        curve["mfpt_ratio"],
        color=COLORS["purple"],
        marker="o",
        ms=2.6,
        lw=1.7,
    )
    axis.axhline(1e4, color=COLORS["gray"], ls="--", lw=1.0)
    axis.axvspan(threshold - half_range, threshold + half_range, color=COLORS["orange"], alpha=0.32, lw=0)
    axis.axvline(reference_D, color=COLORS["black"], ls=":", lw=1.0)
    axis.text(threshold + 0.00018, 2.2e4, r"$D^*$", color=COLORS["orange"], fontsize=6.3)
    axis.text(reference_D + 0.00030, 4.1e4, "reference D", ha="left", va="bottom", fontsize=5.8)
    axis.set(
        xlim=(curve["D"].min(), curve["D"].max()),
        xlabel="noise intensity, D",
        ylabel=r"MFPT ratio, $T_{H\to L}/T_{L\to H}$",
        title="Noise-dependent kinetics and SDE validation",
    )

    inset = axis.inset_axes([0.59, 0.55, 0.36, 0.36])
    fpe = sde["fpe_mfpt"].to_numpy(dtype=float)
    sde_mean = sde["sde_mean"].to_numpy(dtype=float)
    low = sde["sde_ci95_low"].to_numpy(dtype=float)
    high = sde["sde_ci95_high"].to_numpy(dtype=float)
    inset.errorbar(
        fpe,
        sde_mean,
        yerr=[sde_mean - low, high - sde_mean],
        fmt="o",
        color=COLORS["teal"],
        ecolor=COLORS["teal"],
        capsize=2,
        ms=3.3,
    )
    limits = [min(fpe.min(), low.min()) * 0.75, max(fpe.max(), high.max()) * 1.3]
    inset.loglog(limits, limits, color=COLORS["gray"], ls="--", lw=0.8)
    inset.set(xlim=limits, ylim=limits, xlabel="FPE MFPT", ylabel="SDE mean", title=r"D=.02, $\Delta t=.0025$")
    inset.patch.set_facecolor("white")
    inset.patch.set_alpha(0.94)
    inset.tick_params(labelsize=4.6, length=2)
    inset.xaxis.label.set_size(5.0)
    inset.yaxis.label.set_size(5.0)
    inset.title.set_size(5.2)

    rows = tagged_records(mfpt_frame, "fig5B_v02") + tagged_records(
        validation_frame[validation_frame["series"] == "SDE_timestep_validation"],
        "fig5C_v02",
    )
    methods = base.common_methods(
        "Fig5B compressed",
        "The main axis retains the backward-Kolmogorov MFPT-ratio scan and the independently converged D* interval for a ratio of 1e4. The inset absorbs the previous SDE-validation content: 1,200 reflected Euler-Maruyama trajectories per direction at D=0.02 and dt=0.0025 are compared with the backward FPE MFPT, including 95% confidence intervals.",
        "The ratio is dimensionless until the physical time scale is calibrated. D is uncalibrated; the ratio above 1e4 remains a conditional low-noise prediction. The inset is a numerical cross-check, not biological calibration.",
    )
    return save_compressed("fig5B", figure, rows, methods)


BUILDERS = {
    "fig3A": build_fig3A,
    "fig3B": build_fig3B,
    "fig5A": build_fig5A,
    "fig5B": build_fig5B,
}


def build_index(outputs: dict[str, dict[str, Path]]) -> Path:
    groups = []
    for figure_name, panels in [("Compressed Figure 3", ["fig3A", "fig3B"]), ("Compressed Figure 5", ["fig5A", "fig5B"])]:
        cards = []
        for panel in panels:
            paths = outputs[panel]
            _, title = COMPRESSED_META[panel]
            image_rel = paths["candidate"].relative_to(FIGURES_ROOT).as_posix()
            html_rel = paths["html"].relative_to(FIGURES_ROOT).as_posix()
            methods_rel = paths["methods"].relative_to(FIGURES_ROOT).as_posix()
            data_rel = paths["data"].relative_to(FIGURES_ROOT).as_posix()
            cards.append(
                f'<article><div class="tag">{html.escape(panel[-1])}</div><h3>{html.escape(title)}</h3>'
                f'<img src="{html.escape(image_rel)}" alt="{html.escape(panel)} compressed preview">'
                f'<p><a href="{html.escape(html_rel)}">Open tuner</a> &middot; '
                f'<a href="{html.escape(methods_rel)}">Methods</a> &middot; '
                f'<a href="{html.escape(data_rel)}">Data</a></p></article>'
            )
        groups.append(f'<section><h2>{figure_name}</h2><div class="grid">{"".join(cards)}</div></section>')
    page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Compressed Figure 3 and Figure 5</title><style>
body{{margin:0;background:#f3f4f6;color:#111827;font:14px Arial,sans-serif}}header{{padding:26px 4vw 18px;background:white;border-bottom:1px solid #d9dde2}}header p{{max-width:900px;color:#59616c;line-height:1.5}}main{{padding:22px 4vw 34px}}section{{margin:0 0 28px}}h2{{font-size:20px}}.grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}}article{{background:white;border:1px solid #d9dde2;border-radius:8px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,.04)}}h3{{font-size:15px;margin:6px 0 10px}}img{{width:100%;height:340px;object-fit:contain;border:1px solid #edf0f2;background:white}}a{{color:#245f8d;text-decoration:none}}.tag{{display:inline-block;background:#e4eef6;color:#315f82;border-radius:12px;padding:3px 8px;font-weight:bold}}.note{{font-weight:bold;color:#8a4b08}}@media(max-width:850px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><header><h1>Compressed A–B candidates for Figures 3 and 5</h1><p>Both figures now contain only two lettered panels. Previous v02 C panels remain in their folders for provenance but are not used in this compressed layout. <span class="note">No manuscript file has been modified.</span></p></header><main>{"".join(groups)}</main></body></html>'''
    output = FIGURES_ROOT / f"Figure_3_5_compressed_AB_index_{DATE}.html"
    output.write_text(page, encoding="utf-8")
    return output


def build_named(panel: str) -> dict[str, Path]:
    if panel not in BUILDERS:
        raise KeyError(panel)
    base.configure_style()
    return BUILDERS[panel]()


def build_all() -> None:
    base.configure_style()
    outputs = {}
    for panel, builder in BUILDERS.items():
        print("building", panel, flush=True)
        outputs[panel] = builder()
    print(build_index(outputs))


if __name__ == "__main__":
    selected = sys.argv[1:]
    if selected:
        output_map = {panel: build_named(panel) for panel in selected}
        if set(output_map) == set(BUILDERS):
            print(build_index(output_map))
    else:
        build_all()
