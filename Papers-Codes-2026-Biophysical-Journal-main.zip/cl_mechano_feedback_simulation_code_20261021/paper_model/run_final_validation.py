from __future__ import annotations

import csv
import json
from pathlib import Path
import sys
import time

import numpy as np
from scipy.optimize import brentq


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from fpe import (
    Grid,
    build_generator,
    deterministic_basin_labels,
    generator_moment_errors,
    high_state_mass,
    mean_first_passage_time,
    mutual_information,
    simulate_first_passage,
    stationarity_residual,
    stationary_distribution,
)
from freidlin_wentzell import minimum_action_path
from model import classify_fixed_points, fixed_points, load_config, params_from_config, stable_points


OUT = ROOT / "results" / "final_review"
OUT.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fpe_metrics(grid_n, diffusion, delta1, E_kpa, params, states):
    grid = Grid.unit_square(int(grid_n))
    generator = build_generator(grid, delta1, E_kpa, params, diffusion)
    probability = stationary_distribution(generator)
    labels = deterministic_basin_labels(grid, delta1, E_kpa, params, states)
    forward, _ = mean_first_passage_time(generator, labels == 1, states[0], grid)
    reverse, _ = mean_first_passage_time(generator, labels == 0, states[1], grid)
    return {
        "grid_n": int(grid_n),
        "D": float(diffusion),
        "mutual_information_nats": mutual_information(probability, grid),
        "high_basin_mass": high_state_mass(probability, labels),
        "mfpt_normal_to_high": forward,
        "mfpt_high_to_normal": reverse,
        "mfpt_ratio": reverse / forward,
        "stationarity_l1_residual": stationarity_residual(generator, probability),
        **generator_moment_errors(generator, grid, delta1, E_kpa, params, diffusion, margin_cells=3),
    }, grid, generator, probability, labels


def threshold_for_grid(grid_n, delta1, E_kpa, params, states):
    def objective(diffusion):
        metrics, *_ = fpe_metrics(grid_n, diffusion, delta1, E_kpa, params, states)
        return np.log10(metrics["mfpt_ratio"]) - 4.0

    return float(brentq(objective, 0.0035, 0.0060, xtol=2e-6, rtol=2e-5))


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    params = params_from_config(config)
    hcc = config["operating_points"]["hcc_reference"]
    delta1 = float(hcc["delta1"])
    E_kpa = float(hcc["E_kpa"])
    diffusion = float(config["stochastic"]["D_reference"])
    points = fixed_points(delta1, E_kpa, params)
    classified = classify_fixed_points(points, delta1, E_kpa, params)
    states = stable_points(delta1, E_kpa, params)
    saddle = points[1]

    fixed_point_rows = []
    for index, record in enumerate(classified):
        residual = np.linalg.norm(
            np.asarray(
                [
                    (params.alpha1 + delta1 * record["y"] ** params.m / (params.K1 ** params.m + record["y"] ** params.m)) * (1.0 - record["x"]) - params.gamma1 * record["x"],
                    (params.alpha2 + params.delta2 * (E_kpa ** params.p_mech / (params.Ec_kpa ** params.p_mech + E_kpa ** params.p_mech)) * record["x"] ** params.n / (params.K2 ** params.n + record["x"] ** params.n)) * (1.0 - record["y"]) - params.gamma2 * record["y"],
                ]
            )
        )
        fixed_point_rows.append({"index": index, **record, "drift_residual_l2": float(residual)})

    grid_rows = []
    for grid_n in config["analysis"]["convergence_grids"]:
        started = time.perf_counter()
        metrics, *_ = fpe_metrics(grid_n, diffusion, delta1, E_kpa, params, states)
        metrics["elapsed_seconds"] = time.perf_counter() - started
        grid_rows.append(metrics)
        print("grid", grid_n, "ratio", metrics["mfpt_ratio"])

    threshold_rows = []
    for grid_n in [60, 80, 100]:
        threshold_rows.append({"grid_n": grid_n, "D_for_mfpt_ratio_1e4": threshold_for_grid(grid_n, delta1, E_kpa, params, states)})
        print("threshold", threshold_rows[-1])

    path_rows = []
    selected_paths = {}
    for nodes in [32, 48, 64, 80]:
        normal_path = minimum_action_path(states[0], saddle, delta1, E_kpa, params, nodes=nodes, restarts=5, adam_steps=1000, lbfgs_steps=220, seed=20260712)
        high_path = minimum_action_path(states[1], saddle, delta1, E_kpa, params, nodes=nodes, restarts=5, adam_steps=1000, lbfgs_steps=220, seed=20260713)
        row = {
            "nodes": nodes,
            "action_normal_to_saddle": normal_path.action,
            "action_high_to_saddle": high_path.action,
            "action_difference": high_path.action - normal_path.action,
            "asymptotic_ratio_at_D_reference": float(np.exp((high_path.action - normal_path.action) / diffusion)),
            "normal_gradient_norm": normal_path.gradient_norm,
            "high_gradient_norm": high_path.gradient_norm,
            "normal_segment_cv": normal_path.segment_cv,
            "high_segment_cv": high_path.segment_cv,
            "normal_converged": int(normal_path.converged),
            "high_converged": int(high_path.converged),
            "normal_restart": normal_path.restart,
            "high_restart": high_path.restart,
        }
        path_rows.append(row)
        selected_paths[nodes] = (normal_path, high_path)
        print("path", row)

    final_nodes = int(config["analysis"]["fw_path_nodes"])
    normal_path, high_path = selected_paths[final_nodes]
    path_coordinate_rows = []
    for direction, result in [("normal_to_saddle", normal_path), ("high_to_saddle", high_path)]:
        for index, (x_value, y_value) in enumerate(result.path):
            path_coordinate_rows.append({"direction": direction, "node": index, "x": x_value, "y": y_value})

    validation_D = float(config["stochastic"]["D_validation"])
    validation_metrics, validation_grid, _, _, validation_labels = fpe_metrics(80, validation_D, delta1, E_kpa, params, states)
    sde_rows = []
    for time_step in [0.010, 0.005, 0.0025]:
        for direction, start, target_label, fpe_key, seed in [
            ("normal_to_high", states[0], 1, "mfpt_normal_to_high", 20260712),
            ("high_to_normal", states[1], 0, "mfpt_high_to_normal", 20260713),
        ]:
            fpe_value = float(validation_metrics[fpe_key])
            simulation = simulate_first_passage(
                validation_grid,
                delta1,
                E_kpa,
                params,
                validation_D,
                validation_labels,
                start,
                target_label,
                particles=1200,
                time_step=time_step,
                max_time=12.0 * fpe_value,
                seed=seed + int(time_step * 100000),
            )
            sde_rows.append(
                {
                    "direction": direction,
                    "D": validation_D,
                    "time_step": time_step,
                    "particles": simulation["particles"],
                    "observed_transitions": simulation["observed_transitions"],
                    "censor_fraction": simulation["censor_fraction"],
                    "fpe_mfpt": fpe_value,
                    "sde_mean": simulation["mean_observed"],
                    "sde_ci95_low": simulation["mean_ci95_low"],
                    "sde_ci95_high": simulation["mean_ci95_high"],
                    "relative_difference": (simulation["mean_observed"] - fpe_value) / fpe_value,
                }
            )
            print("sde", sde_rows[-1])

    write_csv(OUT / "fixed_point_verification.csv", fixed_point_rows)
    write_csv(OUT / "grid_and_generator_convergence.csv", grid_rows)
    write_csv(OUT / "noise_threshold_grid_convergence.csv", threshold_rows)
    write_csv(OUT / "minimum_action_diagnostics.csv", path_rows)
    write_csv(OUT / "minimum_action_paths_final.csv", path_coordinate_rows)
    write_csv(OUT / "sde_timestep_validation.csv", sde_rows)

    baseline = next(row for row in grid_rows if row["grid_n"] == int(config["analysis"]["baseline_grid"]))
    summary = {
        "fixed_points": fixed_point_rows,
        "baseline": baseline,
        "D_threshold_grid_values": threshold_rows,
        "D_threshold_mean": float(np.mean([row["D_for_mfpt_ratio_1e4"] for row in threshold_rows])),
        "D_threshold_half_range": float(0.5 * np.ptp([row["D_for_mfpt_ratio_1e4"] for row in threshold_rows])),
        "minimum_action_final": next(row for row in path_rows if row["nodes"] == final_nodes),
        "sde_validation": sde_rows,
        "interpretation": "MFPT is dimensionless until tau0 is fitted. D is an uncalibrated effective diffusion parameter. The ratio above 1e4 is a conditional low-noise prediction.",
    }
    with (OUT / "final_validation_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
