from __future__ import annotations

import csv
import json
from pathlib import Path
import sys

import numpy as np
from scipy.stats import qmc, rankdata, spearmanr


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from fpe import Grid, build_generator, deterministic_basin_labels, high_state_mass, mean_first_passage_time, mutual_information, stationary_distribution
from model import classify_fixed_points, fixed_points, load_config, params_from_config


OUT = ROOT / "results" / "final_review"
OUT.mkdir(parents=True, exist_ok=True)

MODEL_FIELDS = {"alpha1", "alpha2", "delta2", "K1", "K2", "m", "n", "gamma1", "gamma2", "Ec_kpa", "p_mech"}


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def scale_samples(unit_samples: np.ndarray, names: list[str], ranges: dict) -> np.ndarray:
    output = np.empty_like(unit_samples)
    for index, name in enumerate(names):
        low, high = ranges[name]
        output[:, index] = low + unit_samples[:, index] * (high - low)
    return output


def wilson_interval(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total == 0:
        return float("nan"), float("nan")
    proportion = successes / total
    denominator = 1.0 + z * z / total
    center = (proportion + z * z / (2.0 * total)) / denominator
    half_width = z * np.sqrt(proportion * (1.0 - proportion) / total + z * z / (4.0 * total * total)) / denominator
    return float(center - half_width), float(center + half_width)


def prcc_coefficients(matrix: np.ndarray, output: np.ndarray) -> np.ndarray:
    ranked_matrix = np.column_stack([rankdata(matrix[:, index]) for index in range(matrix.shape[1])])
    ranked_output = rankdata(output)
    coefficients = np.full(matrix.shape[1], np.nan, dtype=float)
    for index in range(matrix.shape[1]):
        controls = np.delete(ranked_matrix, index, axis=1)
        design = np.column_stack([np.ones(controls.shape[0]), controls])
        residual_x = ranked_matrix[:, index] - design @ np.linalg.lstsq(design, ranked_matrix[:, index], rcond=None)[0]
        residual_y = ranked_output - design @ np.linalg.lstsq(design, ranked_output, rcond=None)[0]
        coefficients[index] = np.corrcoef(residual_x, residual_y)[0, 1]
    return coefficients


def prcc_with_bootstrap(rows: list[dict], parameter_names: list[str], output_name: str, seed: int, bootstrap_samples: int = 300) -> list[dict]:
    matrix = np.array([[row[name] for name in parameter_names] for row in rows], dtype=float)
    output = np.array([row[output_name] for row in rows], dtype=float)
    finite = np.isfinite(output) & np.all(np.isfinite(matrix), axis=1)
    matrix = matrix[finite]
    output = output[finite]
    if matrix.shape[0] <= len(parameter_names) + 10:
        return []
    point = prcc_coefficients(matrix, output)
    rng = np.random.default_rng(seed)
    bootstrap = np.full((bootstrap_samples, len(parameter_names)), np.nan, dtype=float)
    for bootstrap_index in range(bootstrap_samples):
        indices = rng.integers(0, matrix.shape[0], matrix.shape[0])
        try:
            bootstrap[bootstrap_index] = prcc_coefficients(matrix[indices], output[indices])
        except np.linalg.LinAlgError:
            continue
    lower = np.nanquantile(bootstrap, 0.025, axis=0)
    upper = np.nanquantile(bootstrap, 0.975, axis=0)
    return [
        {
            "output": output_name,
            "parameter": name,
            "prcc": float(point[index]),
            "ci95_low": float(lower[index]),
            "ci95_high": float(upper[index]),
            "n": int(matrix.shape[0]),
            "bootstrap_samples": bootstrap_samples,
        }
        for index, name in enumerate(parameter_names)
    ]


def prefix_summary(rows: list[dict], count: int) -> dict:
    selected = rows[:count]
    bistable = [row for row in selected if row["bistable"] == 1]
    finite_ratios = np.array([row["mfpt_ratio"] for row in bistable if np.isfinite(row["mfpt_ratio"])], dtype=float)
    return {
        "sample_count": count,
        "bistable_fraction": len(bistable) / count,
        "bistable_count": len(bistable),
        "finite_mfpt_count": int(finite_ratios.size),
        "mfpt_ratio_median": float(np.median(finite_ratios)) if finite_ratios.size else float("nan"),
        "fraction_gt_1e4_among_finite_bistable": float(np.mean(finite_ratios > 1e4)) if finite_ratios.size else float("nan"),
    }


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    baseline_params = params_from_config(config)
    ranges = dict(config["uncertainty_ranges"])
    ranges["D"] = config["stochastic"]["D_uncertainty_range"]
    parameter_names = list(ranges)
    sample_count = int(config["analysis"]["global_range_scan_samples"])
    sample_power = int(round(np.log2(sample_count)))
    if 2**sample_power != sample_count:
        raise ValueError("global_range_scan_samples must be a power of two for nested Sobol prefixes")
    sampler = qmc.Sobol(d=len(parameter_names), scramble=True, seed=int(config["analysis"]["random_seed"]))
    samples = scale_samples(sampler.random_base2(sample_power), parameter_names, ranges)
    grid = Grid.unit_square(int(config["analysis"]["global_range_scan_grid"]))
    rows: list[dict] = []

    for sample_index, sample in enumerate(samples):
        values = dict(zip(parameter_names, sample))
        params = baseline_params.updated(**{key: values[key] for key in MODEL_FIELDS if key in values})
        delta1 = float(values["delta1_hcc"])
        E_kpa = float(values["E_kpa_hcc"])
        diffusion = float(values["D"])
        points = fixed_points(delta1, E_kpa, params, n_grid=1800)
        classified = classify_fixed_points(points, delta1, E_kpa, params)
        stable_states = sorted([(record["x"], record["y"]) for record in classified if record["stable"]], key=lambda state: state[0])
        generator = build_generator(grid, delta1, E_kpa, params, diffusion)
        probability = stationary_distribution(generator)
        record = {
            "sample": sample_index,
            **values,
            "n_fixed_points": len(points),
            "n_stable": len(stable_states),
            "bistable": int(len(stable_states) == 2),
            "mutual_information_nats": mutual_information(probability, grid),
            "high_basin_mass": float("nan"),
            "mfpt_normal_to_high": float("nan"),
            "mfpt_high_to_normal": float("nan"),
            "mfpt_ratio": float("nan"),
            "log10_mfpt_ratio": float("nan"),
            "mfpt_grid_n": grid.n,
            "mfpt_used_fallback": 0,
            "mfpt_solve_failed": 0,
        }
        if len(stable_states) == 2:
            try:
                labels = deterministic_basin_labels(grid, delta1, E_kpa, params, stable_states)
                forward, _ = mean_first_passage_time(generator, labels == 1, stable_states[0], grid)
                reverse, _ = mean_first_passage_time(generator, labels == 0, stable_states[1], grid)
                ratio = reverse / forward
                if not np.isfinite(ratio) or ratio <= 0.0:
                    raise FloatingPointError("non-finite MFPT ratio")
                record.update(
                    {
                        "high_basin_mass": high_state_mass(probability, labels),
                        "mfpt_normal_to_high": forward,
                        "mfpt_high_to_normal": reverse,
                        "mfpt_ratio": ratio,
                        "log10_mfpt_ratio": np.log10(ratio),
                    }
                )
            except (RuntimeError, FloatingPointError, ValueError):
                # Extremely metastable samples can make the coarse backward
                # system ill-conditioned. Recompute those rare cases on a
                # finer grid before declaring numerical failure.
                try:
                    fallback_grid = Grid.unit_square(40)
                    fallback_generator = build_generator(fallback_grid, delta1, E_kpa, params, diffusion)
                    fallback_probability = stationary_distribution(fallback_generator)
                    fallback_labels = deterministic_basin_labels(fallback_grid, delta1, E_kpa, params, stable_states)
                    forward, _ = mean_first_passage_time(fallback_generator, fallback_labels == 1, stable_states[0], fallback_grid)
                    reverse, _ = mean_first_passage_time(fallback_generator, fallback_labels == 0, stable_states[1], fallback_grid)
                    ratio = reverse / forward
                    if not np.isfinite(ratio) or ratio <= 0.0:
                        raise FloatingPointError("non-finite fallback MFPT ratio")
                    record.update(
                        {
                            "high_basin_mass": high_state_mass(fallback_probability, fallback_labels),
                            "mfpt_normal_to_high": forward,
                            "mfpt_high_to_normal": reverse,
                            "mfpt_ratio": ratio,
                            "log10_mfpt_ratio": np.log10(ratio),
                            "mfpt_grid_n": fallback_grid.n,
                            "mfpt_used_fallback": 1,
                        }
                    )
                except (RuntimeError, FloatingPointError, ValueError):
                    record["mfpt_solve_failed"] = 1
        rows.append(record)
        if (sample_index + 1) % 32 == 0:
            print(f"completed {sample_index + 1}/{sample_count}", flush=True)

    bistable_rows = [row for row in rows if row["bistable"] == 1]
    finite_bistable_rows = [row for row in bistable_rows if np.isfinite(row["mfpt_ratio"])]
    ratios = np.array([row["mfpt_ratio"] for row in finite_bistable_rows], dtype=float)
    high_masses = np.array([row["high_basin_mass"] for row in finite_bistable_rows], dtype=float)
    bistable_ci = wilson_interval(len(bistable_rows), sample_count)
    ratio_gt_count = int(np.sum(ratios > 1e4))
    ratio_gt_ci = wilson_interval(ratio_gt_count, ratios.size)

    sensitivity_rows = []
    sensitivity_rows.extend(prcc_with_bootstrap(rows, parameter_names, "mutual_information_nats", 20260720))
    sensitivity_rows.extend(prcc_with_bootstrap(finite_bistable_rows, parameter_names, "high_basin_mass", 20260721))
    sensitivity_rows.extend(prcc_with_bootstrap(finite_bistable_rows, parameter_names, "log10_mfpt_ratio", 20260722))
    for name in parameter_names:
        coefficient = spearmanr([row[name] for row in rows], [row["bistable"] for row in rows]).statistic
        sensitivity_rows.append(
            {
                "output": "bistable_indicator_rank_screen",
                "parameter": name,
                "prcc": float(coefficient),
                "ci95_low": float("nan"),
                "ci95_high": float("nan"),
                "n": sample_count,
                "bootstrap_samples": 0,
            }
        )

    convergence = [prefix_summary(rows, count) for count in [128, 256, 512]]
    summary = {
        "design": "scrambled Sobol low-discrepancy range scan; independent bounded ranges; not a fitted probability distribution and not Sobol-index estimation",
        "sample_count": sample_count,
        "grid_n": grid.n,
        "bistable_sample_count": len(bistable_rows),
        "bistable_hypercube_fraction": len(bistable_rows) / sample_count,
        "bistable_fraction_wilson95": {"low": bistable_ci[0], "high": bistable_ci[1]},
        "finite_mfpt_sample_count": len(finite_bistable_rows),
        "mfpt_solve_failure_count": int(sum(row["mfpt_solve_failed"] for row in rows)),
        "mfpt_fallback_count": int(sum(row["mfpt_used_fallback"] for row in rows)),
        "mfpt_ratio_quantiles_finite_bistable": {
            "q05": float(np.quantile(ratios, 0.05)),
            "q50": float(np.quantile(ratios, 0.50)),
            "q95": float(np.quantile(ratios, 0.95)),
        },
        "fraction_gt_1e4_among_finite_bistable": ratio_gt_count / ratios.size,
        "fraction_gt_1e4_wilson95": {"low": ratio_gt_ci[0], "high": ratio_gt_ci[1]},
        "high_basin_mass_quantiles_finite_bistable": {
            "q05": float(np.quantile(high_masses, 0.05)),
            "q50": float(np.quantile(high_masses, 0.50)),
            "q95": float(np.quantile(high_masses, 0.95)),
        },
        "sample_count_convergence": convergence,
        "top_sensitivity": {},
    }
    for output_name in sorted({row["output"] for row in sensitivity_rows}):
        selected = [row for row in sensitivity_rows if row["output"] == output_name and np.isfinite(row["prcc"])]
        selected.sort(key=lambda row: abs(row["prcc"]), reverse=True)
        summary["top_sensitivity"][output_name] = selected[:7]

    write_csv(OUT / "global_range_scan_512_samples.csv", rows)
    write_csv(OUT / "global_range_scan_sensitivity_bootstrap.csv", sensitivity_rows)
    write_csv(OUT / "global_range_scan_sample_count_convergence.csv", convergence)
    with (OUT / "global_range_scan_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
