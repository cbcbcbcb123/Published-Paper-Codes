from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from fpe import (
    Grid,
    build_generator,
    generator_moment_errors,
    mean_first_passage_time,
    mutual_information,
    stationarity_residual,
    stationary_distribution,
)
from freidlin_wentzell import geometric_action
from model import ModelParams, drift, fixed_points, load_config, params_from_config


def test_deterministic_domain_is_invariant():
    params = ModelParams()
    drift_left, _ = drift(0.0, 0.4, 1.5, 15.0, params)
    drift_right, _ = drift(1.0, 0.4, 1.5, 15.0, params)
    _, drift_bottom = drift(0.4, 0.0, 1.5, 15.0, params)
    _, drift_top = drift(0.4, 1.0, 1.5, 15.0, params)
    assert drift_left >= 0.0
    assert drift_right <= 0.0
    assert drift_bottom >= 0.0
    assert drift_top <= 0.0


def test_hcc_reference_has_three_fixed_points():
    points = fixed_points(1.5, 15.0, ModelParams())
    assert len(points) == 3
    assert points[0][0] < points[1][0] < points[2][0]


def test_reflecting_generator_is_conservative():
    grid = Grid.unit_square(24)
    generator = build_generator(grid, 1.5, 15.0, ModelParams(), 0.008)
    row_sums = np.asarray(generator.sum(axis=1)).ravel()
    assert np.max(np.abs(row_sums)) < 1e-10
    assert np.min(generator.diagonal()) < 0.0


def test_stationary_distribution_is_positive_and_stationary():
    grid = Grid.unit_square(24)
    generator = build_generator(grid, 1.5, 15.0, ModelParams(), 0.008)
    probability = stationary_distribution(generator)
    assert np.isclose(probability.sum(), 1.0)
    assert probability.min() >= 0.0
    assert stationarity_residual(generator, probability) < 1e-8
    assert mutual_information(probability, grid) >= 0.0


def test_config_roundtrip():
    config = load_config(ROOT / "config" / "canonical_model.json")
    params = params_from_config(config)
    assert params.delta2 == 2.0
    assert config["stochastic"]["calibration_status"] == "scenario_only_not_fitted"


def test_generator_matches_drift_and_diffusion_moments():
    params = ModelParams()
    coarse_grid = Grid.unit_square(48)
    fine_grid = Grid.unit_square(96)
    coarse_generator = build_generator(coarse_grid, 1.5, 15.0, params, 0.008)
    fine_generator = build_generator(fine_grid, 1.5, 15.0, params, 0.008)
    coarse = generator_moment_errors(coarse_generator, coarse_grid, 1.5, 15.0, params, 0.008, margin_cells=3)
    fine = generator_moment_errors(fine_generator, fine_grid, 1.5, 15.0, params, 0.008, margin_cells=3)
    for key in coarse:
        assert fine[key] < 0.55 * coarse[key]
    assert fine["max_abs_quadratic"] < 2.5e-2


def test_backward_mfpt_is_positive_for_nonempty_target():
    grid = Grid.unit_square(28)
    generator = build_generator(grid, 1.5, 15.0, ModelParams(), 0.02)
    target = np.zeros(grid.n * grid.n, dtype=bool)
    target.reshape((grid.n, grid.n))[:, grid.n // 2 :] = True
    value, field = mean_first_passage_time(generator, target, (0.05, 0.05), grid)
    assert value > 0.0
    assert np.all(field >= 0.0)
    assert np.all(field[target] == 0.0)


def test_geometric_action_is_nonnegative_and_zero_on_deterministic_direction():
    params = ModelParams()
    start = np.array([0.10, 0.10])
    drift_x, drift_y = drift(start[0], start[1], 1.5, 15.0, params)
    end = start + 1e-3 * np.array([drift_x, drift_y])
    path = np.vstack([start, end])
    assert geometric_action(path, 1.5, 15.0, params) >= -1e-14
    assert geometric_action(path, 1.5, 15.0, params) < 1e-10
