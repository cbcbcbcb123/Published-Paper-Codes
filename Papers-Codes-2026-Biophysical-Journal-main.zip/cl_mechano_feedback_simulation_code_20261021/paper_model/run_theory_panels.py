"""Portable entry point for the unchanged historical theory-panel builders."""
from pathlib import Path
import argparse
import os

PANELS = ("fig2B", "fig2C", "fig2D", "fig3A", "fig3C", "fig5A", "fig5B", "fig5C")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("panels", nargs="*", help="Available: " + ", ".join(PANELS))
    args = parser.parse_args()
    selected = args.panels or list(PANELS)
    if any(panel not in PANELS for panel in selected):
        parser.error("Select only simulation panels: " + ", ".join(PANELS))
    root = Path(__file__).resolve().parent
    os.environ["MPLCONFIGDIR"] = str(root / "generated_figures" / "matplotlib_config")
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
    import matplotlib
    matplotlib.use("Agg")
    import build_final_panels as builder
    builder.FIGURES_ROOT = root / "generated_figures"
    for panel in selected:
        print("Building", panel, flush=True)
        builder.build_panel(panel)

if __name__ == "__main__":
    main()
