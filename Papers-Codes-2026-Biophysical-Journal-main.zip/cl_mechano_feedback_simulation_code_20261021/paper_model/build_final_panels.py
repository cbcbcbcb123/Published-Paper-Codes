from __future__ import annotations

import csv
import html
import json
from pathlib import Path
import shutil
import sys
from typing import Callable

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, Polygon
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import brentq, root
from scipy.stats import spearmanr


ROOT = Path(__file__).resolve().parent
S02_ROOT = ROOT.parent.parent
FIGURES_ROOT = S02_ROOT / "01_Submission_Materials" / "Figures"
FINAL_RESULTS = ROOT / "results" / "final_review"
sys.path.insert(0, str(ROOT / "src"))

from fpe import Grid, build_generator, deterministic_basin_labels, high_state_mass, mean_first_passage_time, mutual_information, stationary_distribution
from model import classify_fixed_points, drift, estimate_stiffness_onset, fixed_points, jacobian, load_config, params_from_config, stable_points, x_nullcline, y_nullcline


DATE = "20260712"
COLORS = {
    "red": "#FF4A4A",
    "blue": "#5F97CF",
    "yellow": "#EFB72E",
    "green": "#55B879",
    "orange": "#F28E2B",
    "purple": "#8E63B6",
    "teal": "#17A2A4",
    "gray": "#6B6B6B",
    "light": "#D9D9D9",
    "pale": "#F3F4F6",
    "black": "#111111",
}


PANEL_META = {
    "fig2A": ("fig2a_mechanochemical_model_reviewed_v02_20260712", "Mechanochemical mutual-activation model"),
    "fig2B": ("fig2b_bifurcation_reviewed_v02_20260712", "Saddle-node onset of bistability"),
    "fig2C": ("fig2c_phase_portrait_reviewed_v02_20260712", "Phase portrait and basin separatrix"),
    "fig2D": ("fig2d_regime_map_reviewed_v02_20260712", "Two-parameter regime map"),
    "fig3A": ("fig3a_fpe_mutual_information_reviewed_v02_20260712", "FPE mutual information"),
    "fig3B": ("fig3b_tcga_grade_correlation_reviewed_v02_20260712", "TCGA grade-stratified correlation"),
    "fig3C": ("fig3c_information_map_reviewed_v02_20260712", "Noise-dependent information map"),
    "fig5A": ("fig5a_stationary_map_reviewed_v02_20260712", "Stationary FPE and minimum-action paths"),
    "fig5B": ("fig5b_mfpt_noise_reviewed_v02_20260712", "Backward MFPT noise dependence"),
    "fig5C": ("fig5c_marginal_sde_reviewed_v02_20260712", "FPE marginals and SDE cross-check"),
}


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 7.2,
            "axes.titlesize": 8.0,
            "axes.labelsize": 7.4,
            "axes.linewidth": 0.8,
            "xtick.labelsize": 6.6,
            "ytick.labelsize": 6.6,
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
            "xtick.major.size": 3.0,
            "ytick.major.size": 3.0,
            "legend.fontsize": 6.2,
            "legend.frameon": False,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )


def write_records(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def panel_paths(panel: str) -> dict[str, Path]:
    slug, _ = PANEL_META[panel]
    folder = FIGURES_ROOT / panel
    folder.mkdir(parents=True, exist_ok=True)
    return {
        "folder": folder,
        "data": folder / f"01-原始数据-{slug}.csv",
        "methods": folder / f"02-处理方法-{slug}.md",
        "script": folder / f"03-处理代码-{slug}.py",
        "preview_png": folder / f"04-Python预览图-{slug}.png",
        "preview_svg": folder / f"04-Python预览图-{slug}.svg",
        "html": folder / f"05-HTML修改-{slug}_tuner.html",
        "candidate": folder / f"06-暂定图-{slug}.png",
    }


def save_panel(panel: str, figure: plt.Figure, rows: list[dict], methods: str) -> dict[str, Path]:
    paths = panel_paths(panel)
    figure.savefig(paths["preview_png"], dpi=600, bbox_inches="tight", pad_inches=0.03)
    figure.savefig(paths["preview_svg"], bbox_inches="tight", pad_inches=0.03)
    plt.close(figure)
    write_records(paths["data"], rows)
    paths["methods"].write_text(methods.strip() + "\n", encoding="utf-8")
    shutil.copyfile(paths["preview_png"], paths["candidate"])
    make_tuner(panel, paths["preview_svg"], paths["html"])
    return paths


def common_methods(panel: str, scientific_method: str, limitations: str) -> str:
    config_path = ROOT / "config" / "canonical_model.json"
    return f"""# {panel} reviewed theory panel

## Scientific source of truth

- Canonical parameter file: `{config_path}`
- Final numerical verification: `{FINAL_RESULTS / 'final_validation_summary.json'}`
- Global range scan: `{FINAL_RESULTS / 'global_range_scan_summary.json'}`
- SDE convention: `dZ = b(Z;theta)dt + sqrt(2D)dW` with normal reflection on `[0,1]^2`.

## Processing method

{scientific_method}

## Interpretation limit

{limitations}

## Figure workflow

The numbered files implement the project small-panel rule: source data -> method note -> Python renderer -> Python PNG/SVG preview -> persistent offline HTML tuner -> tentative candidate PNG. The current `06-暂定图` is a reproducible preview copy, not an owner-approved final HTML export. Panel letters are intentionally omitted because they are added during final multi-panel assembly.
"""


def make_tuner(panel: str, svg_path: Path, output_path: Path) -> None:
    raw_svg = svg_path.read_text(encoding="utf-8")
    raw_svg = raw_svg[raw_svg.find("<svg") :]
    slug, title = PANEL_META[panel]
    storage_key = f"cl-mechano-feedback:{slug}:settings"
    escaped_svg = raw_svg.replace("</template>", "<" + "\\/" + "template>")
    page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)} tuner</title>
<style>
:root{{--ui-bg:#f3f4f6;--panel:#ffffff;--ink:#111827;--muted:#5b6470;--rule:#d4d8de;--accent:#315f82}}
*{{box-sizing:border-box}} body{{margin:0;min-height:100vh;display:grid;grid-template-columns:360px 1fr;font-family:Arial,sans-serif;color:var(--ink);background:var(--ui-bg)}}
aside{{height:100vh;overflow:auto;padding:18px;background:#fff;border-right:1px solid var(--rule)}} main{{padding:24px;overflow:auto;display:flex;align-items:flex-start;justify-content:center}}
#host{{background:#fff;padding:18px;box-shadow:0 2px 14px rgba(0,0,0,.10);transform-origin:top center}} h1{{font-size:18px;margin:0 0 6px}} h2{{font-size:13px;margin:18px 0 7px;color:var(--accent)}}
.hint{{font-size:11px;line-height:1.45;color:var(--muted)}} .grid{{display:grid;grid-template-columns:1fr 1fr;gap:8px}} label{{display:block;font-size:11px;color:#374151;margin:5px 0}} input,select,textarea{{width:100%;font:12px Arial;padding:5px;border:1px solid #c9ced6;border-radius:3px;background:#fff}}
input[type=color]{{height:31px;padding:2px}} input[type=checkbox]{{width:auto;margin-right:5px}} button{{font:12px Arial;padding:7px 9px;margin:4px 3px 4px 0;border:1px solid #aeb6c0;background:#fff;border-radius:4px;cursor:pointer}} button:hover{{background:#eef3f7}}
#json{{min-height:118px;font:11px Consolas,monospace}} #textControls{{display:grid;gap:6px}} #textControls label{{margin:0}} svg text{{paint-order:stroke;stroke:#fff;stroke-width:0;stroke-linejoin:round}}
@media(max-width:900px){{body{{grid-template-columns:1fr}} aside{{height:auto;max-height:none;border-right:0;border-bottom:1px solid var(--rule)}}}}
</style>
</head>
<body>
<aside>
<h1>{html.escape(panel)} · {html.escape(title)}</h1>
<div class="hint">Offline persistent SVG tuner. Scientific coordinates come from the retained CSV and Python renderer. Styling changes are saved locally for this file path.</div>
<h2>Canvas and axes</h2>
<div class="grid">
<label>Preview scale<input data-key="previewScale" type="number" min="0.2" max="3" step="0.05"></label>
<label>PNG scale<input data-key="pngScale" type="number" min="1" max="10" step="1"></label>
<label>Axes width scale<input data-key="axisScaleX" type="number" min="0.6" max="1.4" step="0.02"></label>
<label>Axes height scale<input data-key="axisScaleY" type="number" min="0.6" max="1.4" step="0.02"></label>
<label>Axes X shift<input data-key="axisShiftX" type="number" min="-120" max="120" step="2"></label>
<label>Axes Y shift<input data-key="axisShiftY" type="number" min="-120" max="120" step="2"></label>
<label>Font family<input data-key="fontFamily" type="text"></label>
<label>Font scale<input data-key="fontScale" type="number" min="0.6" max="1.8" step="0.05"></label>
<label>Stroke scale<input data-key="strokeScale" type="number" min="0.5" max="3" step="0.1"></label>
<label>Marker scale<input data-key="markerScale" type="number" min="0.5" max="2.5" step="0.1"></label>
<label>Grid opacity<input data-key="gridOpacity" type="number" min="0" max="1" step="0.05"></label>
<label><input data-key="showGrid" type="checkbox">Show grid/guides</label>
</div>
<h2>Semantic colors</h2>
<div class="grid">
<label>Red / high state<input data-key="red" type="color"></label><label>Blue / low state<input data-key="blue" type="color"></label>
<label>Orange / ITGB1<input data-key="orange" type="color"></label><label>Green / feedback<input data-key="green" type="color"></label>
<label>Purple / action<input data-key="purple" type="color"></label><label>Neutral<input data-key="gray" type="color"></label>
<label>Text<input data-key="textColor" type="color"></label><label>Background<input data-key="background" type="color"></label>
</div>
<h2>Exported figure text</h2><div id="textControls"></div>
<h2>Settings and export</h2>
<button id="copy">Copy settings JSON</button><button id="apply">Apply JSON</button><button id="reset">Reset</button><br>
<button id="svgExport">Export SVG</button><button id="pngExport">Export high-resolution PNG</button>
<textarea id="json" spellcheck="false"></textarea>
<div class="hint">Non-uniform axes scaling applies inverse scaling to text and markers and non-scaling strokes to lines, so labels and symbols remain undistorted.</div>
</aside>
<main><div id="host"></div></main>
<template id="sourceSvg">{escaped_svg}</template>
<script>
const STORAGE_KEY={json.dumps(storage_key)};
const defaults={{previewScale:1,pngScale:6,axisScaleX:1,axisScaleY:1,axisShiftX:0,axisShiftY:0,fontFamily:'Arial',fontScale:1,strokeScale:1,markerScale:1,gridOpacity:0.28,showGrid:false,red:'#FF4A4A',blue:'#5F97CF',orange:'#F28E2B',green:'#55B879',purple:'#8E63B6',gray:'#6B6B6B',textColor:'#111111',background:'#FFFFFF',texts:{{}}}};
let settings={{...defaults}}; const host=document.getElementById('host'); const jsonBox=document.getElementById('json');
const colorMap={{'#ff4a4a':'red','#5f97cf':'blue','#f28e2b':'orange','#55b879':'green','#8e63b6':'purple','#6b6b6b':'gray','#111111':'textColor','#000000':'textColor'}};
function load(){{
 try{{
  const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
  if(saved)settings={{...defaults,...saved,texts:{{...defaults.texts,...(saved.texts||{{}})}}}};
 }}catch(e){{}}
}}
function save(){{localStorage.setItem(STORAGE_KEY,JSON.stringify(settings));jsonBox.value=JSON.stringify(settings,null,2)}}
function assignTextIds(svg){{[...svg.querySelectorAll('text')].forEach((node,index)=>{{node.dataset.tunerId='text-'+index;if(!(node.dataset.tunerId in settings.texts))settings.texts[node.dataset.tunerId]=node.textContent}})}}
function textControls(svg){{const box=document.getElementById('textControls');box.innerHTML='';[...svg.querySelectorAll('text')].forEach(node=>{{const label=document.createElement('label');label.textContent=node.dataset.tunerId;const input=document.createElement('input');input.value=settings.texts[node.dataset.tunerId]??node.textContent;input.addEventListener('input',()=>{{settings.texts[node.dataset.tunerId]=input.value;render()}});label.appendChild(input);box.appendChild(label)}})}}
function numeric(value,fallback=1){{const parsed=parseFloat(value);return Number.isFinite(parsed)?parsed:fallback}}
function render(rebuildControls=false){{host.innerHTML=document.getElementById('sourceSvg').innerHTML;const svg=host.querySelector('svg');assignTextIds(svg);svg.style.background=settings.background;host.style.transform=`scale(${{settings.previewScale}})`;host.style.marginBottom=`${{(settings.previewScale-1)*100}}px`;
 [...svg.querySelectorAll('text')].forEach(node=>{{node.textContent=settings.texts[node.dataset.tunerId]??node.textContent;node.style.fontFamily=settings.fontFamily;const size=numeric(node.getAttribute('font-size')||getComputedStyle(node).fontSize,10);node.style.fontSize=(size*settings.fontScale)+'px';const fill=(node.getAttribute('fill')||'').toLowerCase();if(colorMap[fill])node.setAttribute('fill',settings[colorMap[fill]])}});
 [...svg.querySelectorAll('[stroke]')].forEach(node=>{{const original=(node.getAttribute('stroke')||'').toLowerCase();if(colorMap[original])node.setAttribute('stroke',settings[colorMap[original]]);const width=numeric(node.getAttribute('stroke-width'),NaN);if(Number.isFinite(width))node.setAttribute('stroke-width',width*settings.strokeScale);node.style.vectorEffect='non-scaling-stroke';if(original==='#b0b0b0'||original==='#d9d9d9'){{node.style.opacity=settings.showGrid?settings.gridOpacity:0}}}});
 [...svg.querySelectorAll('[fill]')].forEach(node=>{{const original=(node.getAttribute('fill')||'').toLowerCase();if(colorMap[original])node.setAttribute('fill',settings[colorMap[original]])}});
 const box=svg.viewBox.baseVal;const cx=box.x+box.width/2,cy=box.y+box.height/2;[...svg.querySelectorAll('g[id^="axes_"]')].forEach(group=>{{const old=group.getAttribute('transform')||'';group.setAttribute('transform',`${{old}} translate(${{cx+settings.axisShiftX}} ${{cy+settings.axisShiftY}}) scale(${{settings.axisScaleX}} ${{settings.axisScaleY}}) translate(${{-cx}} ${{-cy}})`);[...group.querySelectorAll('text,use,circle')].forEach(node=>{{node.style.transformBox='fill-box';node.style.transformOrigin='center';node.style.transform=`scale(${{1/settings.axisScaleX}} ${{1/settings.axisScaleY}})`}})}});
 [...svg.querySelectorAll('circle')].forEach(node=>{{const radius=numeric(node.getAttribute('r'),NaN);if(Number.isFinite(radius))node.setAttribute('r',radius*settings.markerScale)}});[...svg.querySelectorAll('use')].forEach(node=>{{node.style.transformBox='fill-box';node.style.transformOrigin='center';node.style.transform+=` scale(${{settings.markerScale}})`}});
 if(rebuildControls)textControls(svg);save()}}
document.querySelectorAll('[data-key]').forEach(input=>{{const key=input.dataset.key;input.value=settings[key];if(input.type==='checkbox')input.checked=!!settings[key];input.addEventListener('input',()=>{{settings[key]=input.type==='checkbox'?input.checked:(input.type==='number'?numeric(input.value):input.value);render()}})}});
document.getElementById('copy').onclick=async()=>{{save();await navigator.clipboard.writeText(jsonBox.value).catch(()=>{{}})}};
document.getElementById('apply').onclick=()=>{{try{{settings={{...defaults,...JSON.parse(jsonBox.value),texts:{{...defaults.texts,...(JSON.parse(jsonBox.value).texts||{{}})}}}};document.querySelectorAll('[data-key]').forEach(input=>{{const key=input.dataset.key;if(input.type==='checkbox')input.checked=!!settings[key];else input.value=settings[key]}});render(true)}}catch(e){{alert('Invalid settings JSON')}}}};
document.getElementById('reset').onclick=()=>{{settings={{...defaults,texts:{{}}}};localStorage.removeItem(STORAGE_KEY);render(true)}};
function currentSvg(){{const svg=host.querySelector('svg').cloneNode(true);svg.style.background=settings.background;return new XMLSerializer().serializeToString(svg)}}
document.getElementById('svgExport').onclick=()=>{{const blob=new Blob([currentSvg()],{{type:'image/svg+xml'}});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download={json.dumps(slug+'.svg')};a.click();URL.revokeObjectURL(a.href)}};
document.getElementById('pngExport').onclick=()=>{{const svg=host.querySelector('svg');const vb=svg.viewBox.baseVal;const scale=settings.pngScale;const canvas=document.createElement('canvas');canvas.width=Math.ceil(vb.width*scale);canvas.height=Math.ceil(vb.height*scale);const ctx=canvas.getContext('2d');ctx.fillStyle=settings.background;ctx.fillRect(0,0,canvas.width,canvas.height);const image=new Image();const blob=new Blob([currentSvg()],{{type:'image/svg+xml'}});const url=URL.createObjectURL(blob);image.onload=()=>{{ctx.drawImage(image,0,0,canvas.width,canvas.height);URL.revokeObjectURL(url);canvas.toBlob(png=>{{const a=document.createElement('a');a.href=URL.createObjectURL(png);a.download={json.dumps(slug+'.png')};a.click();URL.revokeObjectURL(a.href)}},'image/png')}};image.src=url}};
load();render(true);
</script>
</body></html>"""
    output_path.write_text(page, encoding="utf-8")


def fold_point(E_kpa, params, guess=(0.32, 0.40, 0.84)):
    def equations(values):
        x_value, y_value, delta1 = values
        drift_values = drift(x_value, y_value, delta1, E_kpa, params)
        return [drift_values[0], drift_values[1], np.linalg.det(jacobian(x_value, y_value, delta1, E_kpa, params))]

    solution = root(equations, np.asarray(guess, dtype=float), method="hybr", tol=1e-11)
    if not solution.success or np.linalg.norm(equations(solution.x)) > 1e-7:
        raise RuntimeError(f"fold solve failed at E={E_kpa}: {solution.message}")
    return tuple(float(value) for value in solution.x)


def stationary_solution(grid_n, delta1, E_kpa, diffusion, params):
    grid = Grid.unit_square(grid_n)
    generator = build_generator(grid, delta1, E_kpa, params, diffusion)
    probability = stationary_distribution(generator)
    return grid, generator, probability


def build_fig2A(config, params):
    rows = []
    for name, value in params.to_dict().items():
        rows.append({"record_type": "parameter", "name": name, "value": value})
    for source, target, role in [("YAP/TEAD, y", "ITGB1, x", "delta1 feedback"), ("ITGB1, x", "YAP/TEAD, y", "delta2 M(E) feedback"), ("ECM stiffness, E", "YAP/TEAD, y", "mechanical gain M(E)")]:
        rows.append({"record_type": "edge", "source": source, "target": target, "role": role})
    figure, axis = plt.subplots(figsize=(3.55, 2.45))
    axis.set_xlim(0, 10); axis.set_ylim(0, 7); axis.axis("off")
    axis.set_title("Mechanochemical mutual activation", loc="left", pad=2, fontweight="bold")
    axis.add_patch(Circle((2.2, 4.1), 1.0, facecolor=COLORS["orange"], edgecolor="#9A5E08", lw=1.0))
    axis.add_patch(Circle((6.0, 4.1), 1.0, facecolor=COLORS["red"], edgecolor="#9D2B2B", lw=1.0))
    axis.add_patch(Polygon([[4.1,6.67],[5.40,6.1],[4.1,5.53],[2.80,6.1]], closed=True, facecolor=COLORS["blue"], edgecolor="#315F82", lw=1.0))
    axis.text(2.2,4.2,"ITGB1",ha="center",va="center",color="white",fontweight="bold",fontsize=9)
    axis.text(2.2,3.75,"normalized x",ha="center",va="center",color="white",fontsize=5.7)
    axis.text(6.0,4.2,"YAP/TEAD",ha="center",va="center",color="white",fontweight="bold",fontsize=8.4)
    axis.text(6.0,3.75,"normalized y",ha="center",va="center",color="white",fontsize=5.7)
    axis.text(4.1,6.12,"ECM stiffness\nE",ha="center",va="center",color="white",fontsize=6.5,linespacing=0.92)
    axis.add_patch(FancyArrowPatch((3.15,4.45),(5.03,4.45),connectionstyle="arc3,rad=-0.17",arrowstyle="-|>",mutation_scale=10,color=COLORS["green"],lw=2.0))
    axis.add_patch(FancyArrowPatch((5.03,3.73),(3.15,3.73),connectionstyle="arc3,rad=-0.17",arrowstyle="-|>",mutation_scale=10,color=COLORS["green"],lw=2.0))
    axis.add_patch(FancyArrowPatch((4.1,5.53),(5.42,4.95),arrowstyle="-|>",mutation_scale=10,color=COLORS["blue"],lw=1.8,linestyle="--"))
    axis.text(4.08,4.86,r"$\delta_2 M(E)$",ha="center",va="bottom",color=COLORS["green"],fontsize=7)
    axis.text(4.08,3.18,r"$\delta_1$",ha="center",va="top",color=COLORS["green"],fontsize=7)
    axis.text(7.10,5.1,r"$M(E)=E^p/(E_c^p+E^p)$",fontsize=6.3,color=COLORS["blue"])
    axis.text(0.15,1.45,r"$\dot{x}=[\alpha_1+\delta_1H_m(y)](1-x)-\gamma_1x$",fontsize=6.6,color=COLORS["black"])
    axis.text(0.15,0.72,r"$\dot{y}=[\alpha_2+\delta_2M(E)H_n(x)](1-y)-\gamma_2y$",fontsize=6.6,color=COLORS["black"])
    methods = common_methods("Fig2A", "The diagram is generated from the exact bounded ODE used in `src/model.py`. Both feedback directions and the stiffness-dependent gain are shown. All state variables remain in [0,1] because production is multiplied by the remaining inactive fraction `(1-x)` or `(1-y)`.", "The diagram establishes model topology only. It does not by itself demonstrate bistability or identify the high state with a complete malignant phenotype.")
    return save_panel("fig2A", figure, rows, methods)


def build_fig2B(config, params):
    E_kpa = 15.0
    delta_values = np.linspace(0.10, 2.20, 360)
    rows = []
    branches = {"stable_low": ([], []), "unstable_saddle": ([], []), "stable_high": ([], [])}
    for delta1 in delta_values:
        records = classify_fixed_points(fixed_points(float(delta1), E_kpa, params, n_grid=2200), float(delta1), E_kpa, params)
        stable = sorted([record for record in records if record["stable"]], key=lambda record: record["x"])
        unstable = sorted([record for record in records if not record["stable"]], key=lambda record: record["x"])
        if stable:
            branches["stable_low"][0].append(delta1); branches["stable_low"][1].append(stable[0]["x"])
            rows.append({"series": "stable_low", "delta1": delta1, "x_star": stable[0]["x"]})
        if len(stable) == 2:
            branches["stable_high"][0].append(delta1); branches["stable_high"][1].append(stable[1]["x"])
            rows.append({"series": "stable_high", "delta1": delta1, "x_star": stable[1]["x"]})
        if unstable:
            branches["unstable_saddle"][0].append(delta1); branches["unstable_saddle"][1].append(unstable[0]["x"])
            rows.append({"series": "unstable_saddle", "delta1": delta1, "x_star": unstable[0]["x"]})
    fold_x, fold_y, fold_delta = fold_point(E_kpa, params)
    rows.append({"series": "saddle_node", "delta1": fold_delta, "x_star": fold_x, "y_star": fold_y, "residual": 0.0})
    reference = classify_fixed_points(fixed_points(1.5, E_kpa, params), 1.5, E_kpa, params)[-1]
    rows.append({"series": "reference_high", "delta1": 1.5, "x_star": reference["x"], "y_star": reference["y"]})
    figure, axis = plt.subplots(figsize=(3.15, 2.55))
    axis.plot(*branches["stable_low"], color=COLORS["blue"], lw=1.8, label="stable low state")
    axis.plot(*branches["stable_high"], color=COLORS["red"], lw=1.8, label="stable high state")
    axis.plot(*branches["unstable_saddle"], color=COLORS["gray"], lw=1.3, ls="--", label="unstable saddle")
    axis.scatter([fold_delta],[fold_x],s=24,facecolor="white",edgecolor=COLORS["black"],zorder=5)
    axis.annotate("saddle-node onset",(fold_delta,fold_x),xytext=(fold_delta+0.34,fold_x+0.11),arrowprops={"arrowstyle":"->","lw":0.7},fontsize=6.3)
    axis.scatter([1.5],[reference["x"]],s=22,color=COLORS["red"],edgecolor="white",lw=0.6,zorder=5)
    axis.text(1.54,reference["x"]+0.025,"reference",fontsize=6.2,color=COLORS["red"])
    axis.set(xlim=(0.1,2.2),ylim=(0,0.72),xlabel=r"feedback strength, $\delta_1$",ylabel=r"steady-state ITGB1, $x^*$",title=r"Bistability onset at $E=15$ kPa")
    axis.legend(loc="upper left")
    methods = common_methods("Fig2B", f"For each delta1 on a dense scan, all roots of the scalar self-consistency equation were bracketed and refined with Brent's method, then classified using the analytic Jacobian eigenvalues. The fold was independently solved from `b_x=b_y=det(J)=0`, giving delta1_SN={fold_delta:.6f}, x_SN={fold_x:.6f}, y_SN={fold_y:.6f}.", "Crossing this fold permits coexistence of a stable high state and a saddle while the low state remains stable. It is therefore a bistability-onset boundary, not a deterministic commitment or irreversibility threshold.")
    return save_panel("fig2B", figure, rows, methods)


def separatrix_branches(delta1, E_kpa, params, saddle):
    matrix = jacobian(saddle[0], saddle[1], delta1, E_kpa, params)
    values, vectors = np.linalg.eig(matrix)
    stable_index = int(np.argmin(np.real(values)))
    vector = np.real(vectors[:, stable_index]); vector /= np.linalg.norm(vector)
    branches = []
    for sign in [-1.0, 1.0]:
        start = np.asarray(saddle) + sign * 2e-5 * vector
        def reverse_field(_, state):
            drift_values = drift(state[0], state[1], delta1, E_kpa, params)
            return [-drift_values[0], -drift_values[1]]
        solution = solve_ivp(reverse_field, (0.0, 30.0), start, rtol=1e-9, atol=1e-11, max_step=0.025)
        path = solution.y.T
        inside = np.all((path >= 0.0) & (path <= 1.0), axis=1)
        branches.append(path[inside])
    return branches


def build_fig2C(config, params):
    delta1, E_kpa = 1.5, 15.0
    points = fixed_points(delta1, E_kpa, params)
    records = classify_fixed_points(points, delta1, E_kpa, params)
    saddle = points[1]
    branches = separatrix_branches(delta1, E_kpa, params, saddle)
    x_values = np.linspace(0.0,1.0,320); y_values=np.linspace(0.0,1.0,320)
    x_null = x_nullcline(y_values,delta1,params); y_null=y_nullcline(x_values,E_kpa,params)
    mesh=np.linspace(0.02,0.98,33); X,Y=np.meshgrid(mesh,mesh); U,V=drift(X,Y,delta1,E_kpa,params)
    rows=[]
    for x_value,y_value in zip(x_null,y_values): rows.append({"series":"x_nullcline","x":x_value,"y":y_value})
    for x_value,y_value in zip(x_values,y_null): rows.append({"series":"y_nullcline","x":x_value,"y":y_value})
    for branch_index,branch in enumerate(branches):
        for x_value,y_value in branch: rows.append({"series":f"separatrix_{branch_index+1}","x":x_value,"y":y_value})
    for index,record in enumerate(records): rows.append({"series":"fixed_point","label":["L","S","H"][index],**record})
    figure,axis=plt.subplots(figsize=(3.05,2.75))
    speed=np.hypot(U,V); axis.streamplot(X,Y,U,V,color=np.clip(speed,0,0.9),cmap="Greys",density=1.05,linewidth=0.45,arrowsize=0.55)
    axis.plot(x_null,y_values,color=COLORS["orange"],lw=1.8,label=r"$\dot{x}=0$")
    axis.plot(x_values,y_null,color=COLORS["blue"],lw=1.8,label=r"$\dot{y}=0$")
    for branch_index,branch in enumerate(branches): axis.plot(branch[:,0],branch[:,1],color=COLORS["purple"],lw=1.3,ls="--",label="separatrix" if branch_index==0 else None)
    for index,record in enumerate(records):
        if record["stable"]: axis.scatter(record["x"],record["y"],s=28,color=COLORS["blue"] if index==0 else COLORS["red"],edgecolor="white",lw=0.6,zorder=6)
        else: axis.scatter(record["x"],record["y"],s=32,marker="s",facecolor="white",edgecolor=COLORS["gray"],lw=1.0,zorder=6)
        axis.text(record["x"]+0.025,record["y"]+0.02,["L","S","H"][index],fontsize=7,fontweight="bold")
    axis.set(xlim=(0,0.75),ylim=(0,0.78),xlabel="normalized ITGB1, x",ylabel="normalized YAP/TEAD, y",title="Phase portrait and basin separatrix")
    phase_legend=axis.legend(loc="upper left",ncol=1,frameon=True,framealpha=0.88); phase_legend.get_frame().set_facecolor("white"); phase_legend.get_frame().set_edgecolor("#D5D9DD")
    methods=common_methods("Fig2C","The phase portrait uses the exact vector field at delta1=1.5 and E=15 kPa. Nullclines are analytic. Fixed points are classified by Jacobian eigenvalues. The basin separatrix is the stable manifold of the saddle, traced by integrating the reversed deterministic flow from both sides of the stable eigenvector.","The labels L and H denote model low- and high-activity states. Their biological interpretation requires the experimental mapping and should not be read as a proof that the entire cancer phenotype is a two-variable state.")
    return save_panel("fig2C",figure,rows,methods)


def build_fig2D(config, params):
    delta_values=np.linspace(0.2,2.2,81); E_values=np.linspace(1.0,30.0,81); regime=np.zeros((len(E_values),len(delta_values)))
    rows=[]
    for j,E_kpa in enumerate(E_values):
        for i,delta1 in enumerate(delta_values):
            count=len([record for record in classify_fixed_points(fixed_points(float(delta1),float(E_kpa),params,n_grid=1200),float(delta1),float(E_kpa),params) if record["stable"]])
            regime[j,i]=1 if count==2 else 0
            rows.append({"series":"regime","delta1":delta1,"E_kpa":E_kpa,"bistable":int(count==2),"stable_states":count})
    boundary_E=np.linspace(30.0,1.0,180); boundary_delta=[]; boundary_stiffness=[]; continuation_guess=(0.314,0.406,0.797)
    for E_kpa in boundary_E:
        try:
            fold_x,fold_y,fold_delta=fold_point(float(E_kpa),params,continuation_guess); continuation_guess=(fold_x,fold_y,fold_delta)
            if 0.2 <= fold_delta <= 2.2:
                boundary_delta.append(fold_delta); boundary_stiffness.append(float(E_kpa)); rows.append({"series":"smooth_saddle_node_boundary","delta1":fold_delta,"E_kpa":float(E_kpa),"x_star":fold_x,"y_star":fold_y})
        except RuntimeError:
            continue
    grades=config["operating_points"]["grade_path"]
    for grade in grades: rows.append({"series":"representative_grade_anchor",**grade})
    figure,axis=plt.subplots(figsize=(3.2,2.6))
    from matplotlib.colors import ListedColormap
    axis.pcolormesh(delta_values,E_values,regime,cmap=ListedColormap([COLORS["pale"],"#DCEAF6"]),shading="nearest",vmin=0,vmax=1)
    axis.plot(boundary_delta,boundary_stiffness,color=COLORS["blue"],lw=1.8)
    grade_x=[grade["delta1"] for grade in grades]; grade_y=[grade["E_kpa"] for grade in grades]
    axis.plot(grade_x,grade_y,color=COLORS["gray"],lw=1.0,ls=":")
    axis.scatter(grade_x,grade_y,c=[COLORS["green"],COLORS["yellow"],COLORS["orange"],COLORS["red"]],s=26,edgecolor="white",lw=0.6,zorder=5)
    for grade in grades: axis.text(grade["delta1"]+0.04,grade["E_kpa"]+0.6,grade["grade"],fontsize=6.4)
    axis.text(0.34,26.5,"one stable state",color=COLORS["gray"],fontsize=6.4)
    axis.text(1.36,16.5,"two stable states",color=COLORS["blue"],fontsize=6.4,fontweight="bold")
    axis.set(xlim=(0.2,2.2),ylim=(1,30),xlabel=r"feedback strength, $\delta_1$",ylabel="ECM stiffness, E (kPa)",title="Parameter-dependent bistability")
    methods=common_methods("Fig2D","Each point in the (delta1,E) plane was classified by the number of stable fixed points obtained from the self-consistency roots and analytic Jacobian. The blue contour marks the transition from one to two stable states. G1-G4 are retained only as representative operating anchors from the canonical configuration.","The grade anchors are not patient-level fits: their stiffness values are literature-based representatives and their delta1 values are illustrative model anchors. The bistable region is not synonymous with kinetic locking, which also depends on D and physical time calibration.")
    return save_panel("fig2D",figure,rows,methods)


def build_fig3A(config, params):
    delta1=1.4; stiffness=np.linspace(1.0,25.0,25); diffusions=[0.004,0.008,0.016]; rows=[]
    figure,axis=plt.subplots(figsize=(3.15,2.55))
    for diffusion,color in zip(diffusions,[COLORS["purple"],COLORS["blue"],COLORS["teal"]]):
        values=[]
        for E_kpa in stiffness:
            grid,generator,probability=stationary_solution(40,delta1,float(E_kpa),diffusion,params)
            value=mutual_information(probability,grid); values.append(value); rows.append({"series":"FPE_MI","delta1":delta1,"E_kpa":E_kpa,"D":diffusion,"MI_nats":value,"grid_n":40})
        axis.plot(stiffness,values,color=color,lw=1.6,marker="o",ms=2.2,label=f"D = {diffusion:.3f}")
    onset=estimate_stiffness_onset(delta1,params); axis.axvline(onset,color=COLORS["gray"],ls="--",lw=1.0)
    axis.text(onset+0.40,0.012,"bistability onset",rotation=0,va="bottom",ha="left",fontsize=6.1,color=COLORS["gray"])
    rows.append({"series":"bistability_onset","delta1":delta1,"E_kpa":onset})
    axis.set(xlabel="ECM stiffness, E (kPa)",ylabel="mutual information, I(X;Y) (nats)",title=r"FPE dependence at fixed $\delta_1=1.4$")
    axis.legend(loc="upper right")
    methods=common_methods("Fig3A","Mutual information is computed directly from the normalized two-dimensional stationary FPE cell masses on a 40x40 reflecting grid. Curves vary only D while holding delta1=1.4 and all other canonical parameters fixed. The vertical line is the deterministic bistability onset.","MI and Spearman rho are different statistics and operate at different observational levels. This panel is a model prediction about statistical dependence, not a fit to the TCGA grade coefficients.")
    return save_panel("fig3A",figure,rows,methods)


def tcga_grade_data():
    source=FIGURES_ROOT/"fig1E"/"01-原始数据-fig1e_i_expression_correlations_source_data"/"01-原始数据-fig1e_i_plotting_data.csv"
    frame=pd.read_csv(source)
    selected=frame[frame["dataset_key"].astype(str).str.startswith("I_") & frame["grade"].isin(["G1","G2","G3","G4"])].copy()
    return source,selected


def build_fig3B(config, params):
    source,frame=tcga_grade_data(); rng=np.random.default_rng(20260712); summary=[]; raw_rows=[]; boot_matrix=[]
    grades=["G1","G2","G3","G4"]
    for grade_index,grade in enumerate(grades):
        group=frame[frame["grade"]==grade][["x_value","y_value","sample_id"]].dropna(); x=group["x_value"].to_numpy(); y=group["y_value"].to_numpy(); rho=float(spearmanr(x,y).statistic)
        boot=np.empty(10000)
        for index in range(10000):
            sample_index=rng.integers(0,len(x),len(x)); boot[index]=spearmanr(x[sample_index],y[sample_index]).statistic
        low,high=np.nanquantile(boot,[0.025,0.975]); boot_matrix.append(boot)
        summary.append({"grade":grade,"grade_index":grade_index+1,"n":len(x),"spearman_rho":rho,"ci95_low":float(low),"ci95_high":float(high)})
        for _,record in group.iterrows(): raw_rows.append({"record_type":"raw_pair","grade":grade,"sample_id":record["sample_id"],"ITGB1":record["x_value"],"YAP1":record["y_value"]})
    boot_matrix=np.column_stack(boot_matrix); slopes=np.array([np.polyfit(np.arange(1,5),row,1)[0] for row in boot_matrix])
    probability_positive=float(np.mean(slopes>0)); probability_strict=float(np.mean(np.all(np.diff(boot_matrix,axis=1)>0,axis=1)))
    rows=raw_rows+[{"record_type":"summary",**record,"bootstrap_replicates":10000,"probability_positive_grade_slope":probability_positive,"probability_strict_monotonic":probability_strict,"source":str(source)} for record in summary]
    figure,axis=plt.subplots(figsize=(3.05,2.55))
    x=np.arange(1,5); rho=np.array([record["spearman_rho"] for record in summary]); low=np.array([record["ci95_low"] for record in summary]); high=np.array([record["ci95_high"] for record in summary])
    axis.errorbar(x,rho,yerr=[rho-low,high-rho],fmt="D",ms=4.2,color=COLORS["blue"],ecolor="#9BBAD8",elinewidth=1.3,capsize=3)
    for index,record in enumerate(summary): axis.text(x[index],0.965,f"n={record['n']}",ha="center",va="top",fontsize=6.1,color=COLORS["gray"])
    axis.set(xticks=x,xticklabels=grades,xlim=(0.75,4.25),ylim=(0,1),xlabel="TCGA-LIHC tumour grade",ylabel=r"Spearman $\rho$(ITGB1, YAP1)",title="Grade-stratified bulk-tumour association")
    methods=common_methods("Fig3B",f"Raw grade-stratified ITGB1-YAP1 pairs were read from `{source}`. Spearman rho was recomputed within each grade. Percentile 95% intervals use 10,000 within-grade bootstrap resamples with seed 20260712. The bootstrap probability of a positive grade slope is {probability_positive:.3f}; the probability of strictly increasing adjacent coefficients is {probability_strict:.3f}.","These are patient-level bulk-RNA correlations, not single-cell stationary distributions. The G4 interval is wide because n=12. Representative stiffness anchors are intentionally omitted from the x-axis because stiffness was not measured in these TCGA samples.")
    return save_panel("fig3B",figure,rows,methods)


def build_fig3C(config, params):
    delta1=1.4; stiffness=np.linspace(2.0,25.0,17); diffusions=np.linspace(0.004,0.020,13); heat=np.zeros((len(diffusions),len(stiffness))); rows=[]
    for j,diffusion in enumerate(diffusions):
        for i,E_kpa in enumerate(stiffness):
            grid,generator,probability=stationary_solution(28,delta1,float(E_kpa),float(diffusion),params); heat[j,i]=mutual_information(probability,grid); rows.append({"series":"FPE_MI_map","delta1":delta1,"E_kpa":E_kpa,"D":diffusion,"MI_nats":heat[j,i],"grid_n":28})
    figure,axis=plt.subplots(figsize=(3.15,2.55)); image=axis.imshow(heat,origin="lower",aspect="auto",extent=[stiffness[0],stiffness[-1],diffusions[0],diffusions[-1]],cmap="cividis")
    colorbar=figure.colorbar(image,ax=axis,pad=0.03,fraction=0.06); colorbar.set_label("MI (nats)",fontsize=7); colorbar.ax.tick_params(labelsize=6)
    axis.axhline(float(config["stochastic"]["D_reference"]),color="white",ls="--",lw=0.9)
    axis.set(xlabel="ECM stiffness, E (kPa)",ylabel="noise intensity, D",title="Noise-dependent FPE information map")
    methods=common_methods("Fig3C","Each heat-map value is the mutual information of the stationary reflecting FPE distribution at fixed delta1=1.4 on a 28x28 screening grid. The white dashed line marks the uncalibrated reference D=0.008.","This is a sensitivity map. D is not fitted to experimental time-series or single-cell covariance data, so the dashed reference line is a modeling scenario rather than a measured biological noise level.")
    return save_panel("fig3C",figure,rows,methods)


def build_fig5A(config, params):
    hcc=config["operating_points"]["hcc_reference"]; delta1=float(hcc["delta1"]); E_kpa=float(hcc["E_kpa"]); diffusion=float(config["stochastic"]["D_reference"]); grid_n=int(config["analysis"]["baseline_grid"])
    grid,generator,probability=stationary_solution(grid_n,delta1,E_kpa,diffusion,params); density=probability.reshape((grid_n,grid_n))/(grid.spacing**2); log_density=np.log10(np.maximum(density,1e-300)); relative_log_density=log_density-float(np.max(log_density)); clipped_relative_log_density=np.maximum(relative_log_density,-12.0); points=fixed_points(delta1,E_kpa,params)
    path_frame=pd.read_csv(FINAL_RESULTS/"minimum_action_paths_final.csv")
    rows=[]
    for j,y_value in enumerate(grid.centers):
        for i,x_value in enumerate(grid.centers): rows.append({"series":"stationary_density","x":x_value,"y":y_value,"density":density[j,i],"log10_density":log_density[j,i],"relative_log10_density":relative_log_density[j,i],"display_relative_log10_density":clipped_relative_log_density[j,i],"grid_n":grid_n,"D":diffusion})
    for record in path_frame.to_dict("records"): rows.append({"series":"minimum_action_path",**record})
    for index,point in enumerate(points): rows.append({"series":"fixed_point","label":["L","S","H"][index],"x":point[0],"y":point[1]})
    figure,axis=plt.subplots(figsize=(3.2,2.7)); image=axis.contourf(grid.centers,grid.centers,clipped_relative_log_density,levels=np.linspace(-12.0,0.0,25),cmap="magma",extend="min"); colorbar=figure.colorbar(image,ax=axis,pad=0.03,fraction=0.06); colorbar.set_label(r"$\log_{{10}}[p/p_{\max}]$ (clipped)",fontsize=7); colorbar.ax.tick_params(labelsize=6)
    for direction,color,label in [("normal_to_saddle",COLORS["blue"],"L to S action path"),("high_to_saddle",COLORS["red"],"H to S action path")]:
        selected=path_frame[path_frame["direction"]==direction]; axis.plot(selected["x"],selected["y"],color=color,lw=1.8,label=label)
    for index,point in enumerate(points):
        marker="s" if index==1 else "o"; face="white" if index==1 else (COLORS["blue"] if index==0 else COLORS["red"]); axis.scatter(point[0],point[1],s=28,marker=marker,facecolor=face,edgecolor="white" if index!=1 else COLORS["gray"],lw=0.8,zorder=5); axis.text(point[0]+0.022,point[1]+0.018,["L","S","H"][index],fontsize=6.7,fontweight="bold",color="white" if index==2 else COLORS["black"])
    axis.set(xlim=(0,0.75),ylim=(0,0.78),xlabel="normalized ITGB1, x",ylabel="normalized YAP/TEAD, y",title="Stationary density and FW action paths"); action_legend=axis.legend(loc="upper left",frameon=True,framealpha=0.92); action_legend.get_frame().set_facecolor("white"); action_legend.get_frame().set_edgecolor("#D5D9DD")
    methods=common_methods("Fig5A",f"The stationary density is the normalized solution of the two-dimensional reflecting FPE on the reviewed {grid_n}x{grid_n} grid at delta1={delta1}, E={E_kpa} kPa and D={diffusion}. For legibility the displayed field is log10[p/p_max], clipped below -12; the CSV retains the unclipped density and log-density. This scale is not thermodynamic energy. The two paths are independently optimized 64-node Freidlin-Wentzell geometric action paths from each attractor to the saddle.","The finite-D log stationary density is not an equilibrium energy landscape. The path actions are quasipotential/action barriers for the specified isotropic-noise model. D remains uncalibrated.")
    return save_panel("fig5A",figure,rows,methods)


def build_fig5B(config, params):
    hcc=config["operating_points"]["hcc_reference"]; delta1=float(hcc["delta1"]); E_kpa=float(hcc["E_kpa"]); states=stable_points(delta1,E_kpa,params); diffusion_values=np.linspace(0.0038,0.020,18); rows=[]; ratios=[]
    for diffusion in diffusion_values:
        grid,generator,probability=stationary_solution(60,delta1,E_kpa,float(diffusion),params); labels=deterministic_basin_labels(grid,delta1,E_kpa,params,states); forward,_=mean_first_passage_time(generator,labels==1,states[0],grid); reverse,_=mean_first_passage_time(generator,labels==0,states[1],grid); ratio=reverse/forward; ratios.append(ratio); rows.append({"series":"backward_MFPT_ratio","D":diffusion,"mfpt_normal_to_high":forward,"mfpt_high_to_normal":reverse,"mfpt_ratio":ratio,"grid_n":60})
    validation=json.loads((FINAL_RESULTS/"final_validation_summary.json").read_text(encoding="utf-8")); threshold=validation["D_threshold_mean"]; half_range=validation["D_threshold_half_range"]
    for record in validation["D_threshold_grid_values"]: rows.append({"series":"D_threshold_grid","grid_n":record["grid_n"],"D":record["D_for_mfpt_ratio_1e4"],"mfpt_ratio":1e4})
    figure,axis=plt.subplots(figsize=(3.15,2.55)); axis.semilogy(diffusion_values,ratios,color=COLORS["purple"],marker="o",ms=2.7,lw=1.7,label="backward MFPT ratio"); axis.axhline(1e4,color=COLORS["gray"],ls="--",lw=1.0); axis.axvspan(threshold-half_range,threshold+half_range,color=COLORS["orange"],alpha=0.32,lw=0); axis.axvline(float(config["stochastic"]["D_reference"]),color=COLORS["black"],ls=":",lw=1.0)
    axis.text(threshold+0.00018,2.3e4,r"$D^*$",color=COLORS["orange"],fontsize=6.5); axis.text(float(config["stochastic"]["D_reference"])+0.00032,4.2e4,"reference D",rotation=0,va="bottom",ha="left",fontsize=6.0)
    axis.set(xlim=(diffusion_values.min(),diffusion_values.max()),xlabel="noise intensity, D",ylabel="MFPT ratio, H→L / L→H",title="Kinetic asymmetry is noise dependent")
    axis.set_ylabel(r"MFPT ratio, $T_{H\to L}/T_{L\to H}$")
    methods=common_methods("Fig5B",f"For each D, the same 60x60 reflecting generator is used for the stationary FPE, deterministic basin targets and both backward Kolmogorov MFPT solves. The orange band is the half-range of D* obtained independently on 60, 80 and 100 grids: D*={threshold:.6f} +/- {half_range:.6f} for an MFPT ratio of 1e4.","The ratio is dimensionless and does not establish clinical irreversibility until both D and the physical time unit tau0 are calibrated. At the scenario D=0.008, the reviewed 100x100 ratio is about 398, not 1e4.")
    return save_panel("fig5B",figure,rows,methods)


def build_fig5C(config, params):
    diffusion=float(config["stochastic"]["D_reference"]); hcc=config["operating_points"]["hcc_reference"]; normal=config["operating_points"]["normal"]; rows=[]
    marginals={}
    for label,condition,color in [("normal",normal,COLORS["blue"]),("HCC reference",hcc,COLORS["red"])]:
        grid,generator,probability=stationary_solution(100,float(condition["delta1"]),float(condition["E_kpa"]),diffusion,params); marginal=probability.reshape((100,100)).sum(axis=0)/grid.spacing; marginals[label]=(grid.centers,marginal,color)
        for x_value,value in zip(grid.centers,marginal): rows.append({"series":"x_marginal","condition":label,"x":x_value,"density":value,"D":diffusion,"grid_n":100})
    sde=pd.read_csv(FINAL_RESULTS/"sde_timestep_validation.csv"); finest=sde[np.isclose(sde["time_step"],0.0025)]
    for record in sde.to_dict("records"): rows.append({"series":"SDE_timestep_validation",**record})
    figure,axis=plt.subplots(figsize=(3.25,2.65))
    for label,(x_values,marginal,color) in marginals.items(): axis.semilogy(x_values,marginal,color=color,lw=1.8,label=label)
    axis.set(xlim=(0,0.82),ylim=(1e-7,2e2),xlabel="normalized ITGB1, x",ylabel="marginal density, p(x)",title="State weights and independent SDE check"); axis.legend(loc="upper left")
    inset=axis.inset_axes([0.63,0.58,0.33,0.34]); fpe=finest["fpe_mfpt"].to_numpy(); sde_mean=finest["sde_mean"].to_numpy(); low=finest["sde_ci95_low"].to_numpy(); high=finest["sde_ci95_high"].to_numpy(); inset.errorbar(fpe,sde_mean,yerr=[sde_mean-low,high-sde_mean],fmt="o",color=COLORS["teal"],ecolor=COLORS["teal"],capsize=2,ms=3.5); limits=[min(fpe.min(),low.min())*0.75,max(fpe.max(),high.max())*1.3]; inset.loglog(limits,limits,color=COLORS["gray"],ls="--",lw=0.8); inset.set(xlim=limits,ylim=limits,xlabel="FPE MFPT",ylabel="SDE mean",title=r"$\Delta t=0.0025$"); inset.tick_params(labelsize=4.7); inset.xaxis.label.set_size(5.2); inset.yaxis.label.set_size(5.2); inset.title.set_size(5.5)
    validation=json.loads((FINAL_RESULTS/"final_validation_summary.json").read_text(encoding="utf-8")); high_mass=validation["baseline"]["high_basin_mass"]; axis.text(0.03,1.7e-6,f"HCC high-basin mass = {high_mass:.4f}",fontsize=6.1,color=COLORS["red"])
    methods=common_methods("Fig5C",f"Normal and HCC-reference x marginals are obtained by integrating the reviewed 100x100 stationary FPE density over y. A logarithmic y-axis preserves the true state weights rather than separately normalizing peaks. The inset compares backward MFPT with 1,200 reflected Euler-Maruyama trajectories per direction at D=0.02 and the finest tested step dt=0.0025; both directions had zero censoring and relative differences below 2%.","The HCC reference is mathematically bistable but the low-state stationary weight is very small; the distribution should not be described as visibly symmetric bimodality. SDE validation is numerical validation at D=0.02, not biological calibration of D.")
    return save_panel("fig5C",figure,rows,methods)


BUILDERS: dict[str, Callable] = {"fig2A":build_fig2A,"fig2B":build_fig2B,"fig2C":build_fig2C,"fig2D":build_fig2D,"fig3A":build_fig3A,"fig3B":build_fig3B,"fig3C":build_fig3C,"fig5A":build_fig5A,"fig5B":build_fig5B,"fig5C":build_fig5C}


def build_index(outputs: dict[str, dict[str, Path]]) -> Path:
    cards=[]; safe_cards=[]
    for panel,paths in outputs.items():
        _,title=PANEL_META[panel]
        image_rel=paths["candidate"].relative_to(FIGURES_ROOT).as_posix(); html_rel=paths["html"].relative_to(FIGURES_ROOT).as_posix(); methods_rel=paths["methods"].relative_to(FIGURES_ROOT).as_posix(); data_rel=paths["data"].relative_to(FIGURES_ROOT).as_posix()
        safe_card=f'<article><div class="tag">{panel}</div><h2>{html.escape(title)}</h2><img src="{html.escape(image_rel)}" alt="{panel} preview"><p><a href="{html.escape(html_rel)}">Open persistent tuner</a> &middot; <a href="{html.escape(methods_rel)}">Methods</a> &middot; <a href="{html.escape(data_rel)}">Data</a></p></article>'; safe_cards.append(safe_card)
        cards.append(f'<article><div class="tag">{panel}</div><h2>{html.escape(title)}</h2><img src="{html.escape(image_rel)}" alt="{panel} preview"><p><a href="{html.escape(html_rel)}">Open persistent tuner</a> · <a href="{html.escape(methods_rel)}">Methods</a> · <a href="{html.escape(data_rel)}">Data</a></p></article>')
    page=f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reviewed Figures 2, 3 and 5</title><style>body{{margin:0;background:#f4f5f7;color:#111;font:14px Arial,sans-serif}}header{{padding:28px 4vw 20px;background:#fff;border-bottom:1px solid #d8dce1}}h1{{margin:0 0 8px;font-size:25px}}header p{{max-width:950px;color:#4b5563;line-height:1.5}}main{{padding:24px 4vw;display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:18px}}article{{background:#fff;border:1px solid #dde1e6;border-radius:8px;padding:15px;box-shadow:0 2px 8px rgba(0,0,0,.04)}}article h2{{font-size:16px;margin:5px 0 10px}}img{{width:100%;height:255px;object-fit:contain;background:#fff;border:1px solid #edf0f2}}a{{color:#245f8d;text-decoration:none}}a:hover{{text-decoration:underline}}.tag{{display:inline-block;padding:3px 7px;border-radius:12px;background:#e4eef6;color:#315f82;font-weight:bold;font-size:12px}}.warning{{color:#8a4b08;font-weight:bold}}</style></head><body><header><h1>Reviewed theory panels · Figures 2, 3 and 5</h1><p>These panels use the final reviewed ODE/FPE/Freidlin-Wentzell/backward-MFPT/SDE chain. <span class="warning">No manuscript text has been changed.</span> Open each HTML tuner to adjust style and exported English text; scientific coordinates remain traceable to the numbered CSV and Python renderer.</p></header><main>{''.join(cards)}</main></body></html>"""
    cards=safe_cards
    heading_start=page.index("<h1>")+4; heading_end=page.index("</h1>"); page=page[:heading_start]+"Reviewed theory panels &middot; Figures 2, 3 and 5"+page[heading_end:]
    path=FIGURES_ROOT/f"Figure_2_3_5_reviewed_theory_index_{DATE}.html"; path.write_text(page,encoding="utf-8"); return path


def build_panel(panel: str) -> dict[str, Path]:
    configure_style(); config=load_config(ROOT/"config"/"canonical_model.json"); params=params_from_config(config)
    if panel not in BUILDERS: raise KeyError(panel)
    return BUILDERS[panel](config,params)


def build_all() -> None:
    configure_style(); config=load_config(ROOT/"config"/"canonical_model.json"); params=params_from_config(config); outputs={}
    for panel,builder in BUILDERS.items():
        print("building",panel,flush=True); outputs[panel]=builder(config,params)
    index=build_index(outputs); print(index)


if __name__ == "__main__":
    selected=sys.argv[1:]
    if selected:
        for panel in selected: build_panel(panel)
    else: build_all()
