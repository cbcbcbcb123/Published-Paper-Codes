from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.sparse import coo_matrix, csr_matrix
from scipy.sparse.linalg import spsolve

from model import ModelParams, drift


@dataclass(frozen=True)
class Grid:
    n: int
    centers: np.ndarray
    spacing: float

    @classmethod
    def unit_square(cls, n: int) -> "Grid":
        spacing = 1.0 / n
        centers = (np.arange(n, dtype=float) + 0.5) * spacing
        return cls(n=n, centers=centers, spacing=spacing)


def _exponential_fit(argument: float) -> float:
    if argument > 50.0:
        return argument
    if argument < -50.0:
        return 0.0
    if abs(argument) < 1e-7:
        return 1.0 + 0.5 * argument + argument * argument / 12.0
    return float(argument / (-np.expm1(-argument)))


def _flat_index(i: int, j: int, n: int) -> int:
    return j * n + i


def build_generator(
    grid: Grid,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    diffusion: float,
) -> csr_matrix:
    """Backward generator with exponentially fitted face rates and reflecting walls."""
    if diffusion <= 0.0:
        raise ValueError("diffusion must be positive")
    n = grid.n
    h = grid.spacing
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    outgoing = np.zeros(n * n, dtype=float)

    def add_pair(left: int, right: int, face_drift: float):
        peclet = face_drift * h / diffusion
        rate_forward = diffusion / (h * h) * _exponential_fit(peclet)
        rate_backward = diffusion / (h * h) * _exponential_fit(-peclet)
        rows.extend([left, right])
        columns.extend([right, left])
        data.extend([rate_forward, rate_backward])
        outgoing[left] += rate_forward
        outgoing[right] += rate_backward

    for j, y_value in enumerate(grid.centers):
        for i in range(n - 1):
            x_face = (i + 1) * h
            face_drift, _ = drift(x_face, y_value, delta1, E_kpa, params)
            add_pair(_flat_index(i, j, n), _flat_index(i + 1, j, n), face_drift)

    for j in range(n - 1):
        y_face = (j + 1) * h
        for i, x_value in enumerate(grid.centers):
            _, face_drift = drift(x_value, y_face, delta1, E_kpa, params)
            add_pair(_flat_index(i, j, n), _flat_index(i, j + 1, n), face_drift)

    for state, rate in enumerate(outgoing):
        rows.append(state)
        columns.append(state)
        data.append(-rate)
    return coo_matrix((data, (rows, columns)), shape=(n * n, n * n)).tocsr()


def stationary_distribution(generator: csr_matrix) -> np.ndarray:
    size = generator.shape[0]
    system = generator.transpose().tolil()
    rhs = np.zeros(size, dtype=float)
    system[-1, :] = np.ones(size, dtype=float)
    rhs[-1] = 1.0
    probability = np.asarray(spsolve(system.tocsr(), rhs), dtype=float)
    probability[np.abs(probability) < 1e-15] = 0.0
    if probability.min() < -1e-9:
        raise RuntimeError(f"stationary solve produced negative mass {probability.min()}")
    probability = np.clip(probability, 0.0, None)
    probability /= probability.sum()
    return probability


def stationarity_residual(generator: csr_matrix, probability: np.ndarray) -> float:
    residual = generator.transpose() @ probability
    scale = max(float(np.linalg.norm(probability, ord=1)), 1e-15)
    return float(np.linalg.norm(residual, ord=1) / scale)


def generator_moment_errors(
    generator: csr_matrix,
    grid: Grid,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    diffusion: float,
    margin_cells: int = 2,
) -> dict[str, float]:
    """Check local consistency of the discrete backward generator on test polynomials."""
    x_mesh, y_mesh = np.meshgrid(grid.centers, grid.centers)
    x_flat = x_mesh.ravel()
    y_flat = y_mesh.ravel()
    drift_x, drift_y = drift(x_flat, y_flat, delta1, E_kpa, params)
    discrete_x = np.asarray(generator @ x_flat).ravel()
    discrete_y = np.asarray(generator @ y_flat).ravel()
    quadratic = np.square(x_flat) + np.square(y_flat)
    discrete_quadratic = np.asarray(generator @ quadratic).ravel()
    exact_quadratic = 2.0 * x_flat * drift_x + 2.0 * y_flat * drift_y + 4.0 * diffusion
    mask_2d = np.zeros((grid.n, grid.n), dtype=bool)
    mask_2d[margin_cells : grid.n - margin_cells, margin_cells : grid.n - margin_cells] = True
    mask = mask_2d.ravel()
    return {
        "max_abs_x": float(np.max(np.abs(discrete_x[mask] - drift_x[mask]))),
        "max_abs_y": float(np.max(np.abs(discrete_y[mask] - drift_y[mask]))),
        "max_abs_quadratic": float(np.max(np.abs(discrete_quadratic[mask] - exact_quadratic[mask]))),
    }


def mutual_information(probability: np.ndarray, grid: Grid) -> float:
    joint = probability.reshape((grid.n, grid.n))
    marginal_x = joint.sum(axis=0, keepdims=True)
    marginal_y = joint.sum(axis=1, keepdims=True)
    product = marginal_y @ marginal_x
    mask = joint > 0.0
    return float(np.sum(joint[mask] * np.log(joint[mask] / product[mask])))


def deterministic_basin_labels(
    grid: Grid,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    stable_states: list[tuple[float, float]],
    step: float = 0.03,
    max_steps: int = 4000,
) -> np.ndarray:
    if len(stable_states) != 2:
        raise ValueError("basin labeling requires exactly two stable states")
    x_mesh, y_mesh = np.meshgrid(grid.centers, grid.centers)
    x_values = x_mesh.ravel().copy()
    y_values = y_mesh.ravel().copy()
    labels = np.full(x_values.size, -1, dtype=np.int8)
    active = np.ones(x_values.size, dtype=bool)
    capture_radius_squared = 1e-6
    for _ in range(max_steps):
        if not active.any():
            break
        active_indices = np.flatnonzero(active)
        current_x = x_values[active_indices]
        current_y = y_values[active_indices]
        k1x, k1y = drift(current_x, current_y, delta1, E_kpa, params)
        k2x, k2y = drift(current_x + 0.5 * step * k1x, current_y + 0.5 * step * k1y, delta1, E_kpa, params)
        k3x, k3y = drift(current_x + 0.5 * step * k2x, current_y + 0.5 * step * k2y, delta1, E_kpa, params)
        k4x, k4y = drift(current_x + step * k3x, current_y + step * k3y, delta1, E_kpa, params)
        next_x = np.clip(current_x + step * (k1x + 2.0 * k2x + 2.0 * k3x + k4x) / 6.0, 0.0, 1.0)
        next_y = np.clip(current_y + step * (k1y + 2.0 * k2y + 2.0 * k3y + k4y) / 6.0, 0.0, 1.0)
        x_values[active_indices] = next_x
        y_values[active_indices] = next_y
        for state_index, (state_x, state_y) in enumerate(stable_states):
            captured = np.square(next_x - state_x) + np.square(next_y - state_y) <= capture_radius_squared
            if captured.any():
                captured_indices = active_indices[captured]
                labels[captured_indices] = state_index
                active[captured_indices] = False
        if max(float(np.max(np.abs(k1x))), float(np.max(np.abs(k1y)))) < 1e-9:
            break
    distances = []
    for state_x, state_y in stable_states:
        distances.append(np.square(x_values - state_x) + np.square(y_values - state_y))
    unresolved = labels < 0
    if unresolved.any():
        labels[unresolved] = np.argmin(np.vstack(distances)[:, unresolved], axis=0).astype(np.int8)
    return labels


def point_to_index(point: tuple[float, float], grid: Grid) -> int:
    i = int(np.clip(np.floor(point[0] / grid.spacing), 0, grid.n - 1))
    j = int(np.clip(np.floor(point[1] / grid.spacing), 0, grid.n - 1))
    return _flat_index(i, j, grid.n)


def mean_first_passage_time(
    generator: csr_matrix,
    target_mask: np.ndarray,
    start_point: tuple[float, float],
    grid: Grid,
) -> tuple[float, np.ndarray]:
    target_mask = np.asarray(target_mask, dtype=bool)
    unknown = np.flatnonzero(~target_mask)
    if unknown.size == 0:
        return 0.0, np.zeros(generator.shape[0], dtype=float)
    reduced = generator[unknown][:, unknown]
    rhs = -np.ones(unknown.size, dtype=float)
    solution = np.asarray(spsolve(reduced, rhs), dtype=float)
    if np.nanmin(solution) < -1e-7:
        raise RuntimeError("backward solve produced negative MFPT")
    full = np.zeros(generator.shape[0], dtype=float)
    full[unknown] = np.maximum(solution, 0.0)
    return float(full[point_to_index(start_point, grid)]), full


def high_state_mass(probability: np.ndarray, basin_labels: np.ndarray) -> float:
    return float(probability[basin_labels == 1].sum())


def reflect_unit_interval(values: np.ndarray) -> np.ndarray:
    wrapped = np.mod(values, 2.0)
    return 1.0 - np.abs(wrapped - 1.0)


def simulate_first_passage(
    grid: Grid,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    diffusion: float,
    basin_labels: np.ndarray,
    start_point: tuple[float, float],
    target_label: int,
    particles: int = 2000,
    time_step: float = 0.005,
    max_time: float = 300.0,
    seed: int = 20260712,
) -> dict:
    rng = np.random.default_rng(seed)
    x_values = np.full(particles, start_point[0], dtype=float)
    y_values = np.full(particles, start_point[1], dtype=float)
    hit_times = np.full(particles, np.nan, dtype=float)
    active = np.ones(particles, dtype=bool)
    noise_scale = np.sqrt(2.0 * diffusion * time_step)
    steps = int(np.ceil(max_time / time_step))
    for step_index in range(1, steps + 1):
        if not active.any():
            break
        active_indices = np.flatnonzero(active)
        drift_x, drift_y = drift(x_values[active], y_values[active], delta1, E_kpa, params)
        x_values[active] = reflect_unit_interval(
            x_values[active] + drift_x * time_step + noise_scale * rng.standard_normal(active_indices.size)
        )
        y_values[active] = reflect_unit_interval(
            y_values[active] + drift_y * time_step + noise_scale * rng.standard_normal(active_indices.size)
        )
        i_values = np.clip((x_values[active] / grid.spacing).astype(int), 0, grid.n - 1)
        j_values = np.clip((y_values[active] / grid.spacing).astype(int), 0, grid.n - 1)
        labels = basin_labels[j_values * grid.n + i_values]
        newly_hit_local = labels == target_label
        if newly_hit_local.any():
            newly_hit_global = active_indices[newly_hit_local]
            hit_times[newly_hit_global] = step_index * time_step
            active[newly_hit_global] = False
    observed = hit_times[np.isfinite(hit_times)]
    standard_error = float(np.std(observed, ddof=1) / np.sqrt(observed.size)) if observed.size > 1 else float("nan")
    return {
        "particles": particles,
        "observed_transitions": int(observed.size),
        "censored": int(particles - observed.size),
        "max_time": max_time,
        "mean_observed": float(observed.mean()) if observed.size else float("nan"),
        "median_observed": float(np.median(observed)) if observed.size else float("nan"),
        "mean_ci95_low": float(observed.mean() - 1.96 * standard_error) if observed.size > 1 else float("nan"),
        "mean_ci95_high": float(observed.mean() + 1.96 * standard_error) if observed.size > 1 else float("nan"),
        "standard_error": standard_error,
        "censor_fraction": float(1.0 - observed.size / particles),
        "hit_times": hit_times,
    }
