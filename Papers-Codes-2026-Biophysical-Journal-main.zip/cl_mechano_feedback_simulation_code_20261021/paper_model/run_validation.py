from __future__ import annotations

import csv
import json
from pathlib import Path
import sys
import time

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from fpe import (
    Grid,
    build_generator,
    deterministic_basin_labels,
    high_state_mass,
    mean_first_passage_time,
    mutual_information,
    simulate_first_passage,
    stationarity_residual,
    stationary_distribution,
)
from freidlin_wentzell import minimum_action_path
from model import fixed_points, load_config, params_from_config, stable_points


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def solve_fpe_metrics(grid_n, diffusion, delta1, E_kpa, params, stable_states):
    grid = Grid.unit_square(grid_n)
    generator = build_generator(grid, delta1, E_kpa, params, diffusion)
    probability = stationary_distribution(generator)
    labels = deterministic_basin_labels(grid, delta1, E_kpa, params, stable_states)
    forward, _ = mean_first_passage_time(generator, labels == 1, stable_states[0], grid)
    reverse, _ = mean_first_passage_time(generator, labels == 0, stable_states[1], grid)
    return {
        "grid_n": grid_n,
        "D": diffusion,
        "mi_nats": mutual_information(probability, grid),
        "high_basin_mass": high_state_mass(probability, labels),
        "mfpt_normal_to_cancer": forward,
        "mfpt_cancer_to_normal": reverse,
        "mfpt_ratio": reverse / forward,
        "stationarity_l1_residual": stationarity_residual(generator, probability),
    }, grid, generator, probability, labels


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    params = params_from_config(config)
    results_dir = ROOT / "results"
    hcc = config["operating_points"]["hcc_reference"]
    delta1 = float(hcc["delta1"])
    E_kpa = float(hcc["E_kpa"])
    diffusion_reference = float(config["stochastic"]["D_reference"])
    stable_states = stable_points(delta1, E_kpa, params)
    all_points = fixed_points(delta1, E_kpa, params)
    saddle = all_points[1]

    convergence_rows = []
    for grid_n in config["analysis"]["convergence_grids"]:
        started = time.perf_counter()
        metrics, *_ = solve_fpe_metrics(int(grid_n), diffusion_reference, delta1, E_kpa, params, stable_states)
        metrics["elapsed_seconds"] = time.perf_counter() - started
        convergence_rows.append(metrics)
        print("grid", grid_n, metrics)

    noise_rows = []
    for diffusion in [0.004, 0.005, 0.006, 0.008, 0.010, 0.012, 0.016, 0.020]:
        metrics, *_ = solve_fpe_metrics(60, diffusion, delta1, E_kpa, params, stable_states)
        noise_rows.append(metrics)
        print("D", diffusion, metrics)

    path_rows = []
    for nodes in [24, 32, 48, 64]:
        normal_path = minimum_action_path(
            stable_states[0], saddle, delta1, E_kpa, params, nodes=nodes, restarts=2, adam_steps=800, seed=20260712
        )
        cancer_path = minimum_action_path(
            stable_states[1], saddle, delta1, E_kpa, params, nodes=nodes, restarts=2, adam_steps=800, seed=20260713
        )
        path_rows.append(
            {
                "nodes": nodes,
                "action_normal_to_saddle": normal_path.action,
                "action_cancer_to_saddle": cancer_path.action,
                "action_difference": cancer_path.action - normal_path.action,
                "asymptotic_ratio_D_reference": np.exp((cancer_path.action - normal_path.action) / diffusion_reference),
            }
        )

    validation_diffusion = float(config["stochastic"]["D_validation"])
    validation_metrics, validation_grid, validation_generator, validation_probability, validation_labels = solve_fpe_metrics(
        60, validation_diffusion, delta1, E_kpa, params, stable_states
    )
    simulation_rows = []
    for direction, start, target_label, seed in [
        ("normal_to_cancer", stable_states[0], 1, 20260712),
        ("cancer_to_normal", stable_states[1], 0, 20260713),
    ]:
        fpe_value = (
            validation_metrics["mfpt_normal_to_cancer"]
            if direction == "normal_to_cancer"
            else validation_metrics["mfpt_cancer_to_normal"]
        )
        maximum_time = min(max(8.0 * fpe_value, 30.0), 500.0)
        simulation = simulate_first_passage(
            validation_grid,
            delta1,
            E_kpa,
            params,
            validation_diffusion,
            validation_labels,
            start,
            target_label,
            particles=1500,
            time_step=0.005,
            max_time=maximum_time,
            seed=seed,
        )
        simulation_rows.append(
            {
                "direction": direction,
                "D": validation_diffusion,
                "fpe_mfpt": fpe_value,
                "sde_mean_observed": simulation["mean_observed"],
                "sde_median_observed": simulation["median_observed"],
                "observed_transitions": simulation["observed_transitions"],
                "particles": simulation["particles"],
                "censored": simulation["censored"],
                "max_time": maximum_time,
            }
        )

    write_csv(results_dir / "grid_convergence.csv", convergence_rows)
    write_csv(results_dir / "noise_sweep.csv", noise_rows)
    write_csv(results_dir / "minimum_action_convergence.csv", path_rows)
    write_csv(results_dir / "sde_validation.csv", simulation_rows)

    summary = {
        "grid_convergence": convergence_rows,
        "noise_sweep": noise_rows,
        "minimum_action_convergence": path_rows,
        "sde_validation": simulation_rows,
    }
    with (results_dir / "validation_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    figure, axes = plt.subplots(1, 3, figsize=(11.0, 3.4), constrained_layout=True)
    axes[0].plot([row["grid_n"] for row in convergence_rows], [row["mfpt_ratio"] for row in convergence_rows], "o-")
    axes[0].set(xlabel="grid cells per axis", ylabel="MFPT ratio C->N / N->C", title="Grid convergence")
    axes[1].semilogy([row["D"] for row in noise_rows], [row["mfpt_ratio"] for row in noise_rows], "o-", color="#C0392B")
    axes[1].axhline(1e4, color="#777777", ls="--", lw=1)
    axes[1].set(xlabel="noise intensity D", ylabel="MFPT ratio", title="Noise calibration requirement")
    axes[2].plot([row["nodes"] for row in path_rows], [row["action_normal_to_saddle"] for row in path_rows], "o-", label="N to S")
    axes[2].plot([row["nodes"] for row in path_rows], [row["action_cancer_to_saddle"] for row in path_rows], "o-", label="C to S")
    axes[2].set(xlabel="path nodes", ylabel="geometric action", title="Minimum-action convergence")
    axes[2].legend(fontsize=8)
    figure.savefig(results_dir / "validation_overview.png", dpi=220)
    plt.close(figure)
    print(json.dumps(simulation_rows, indent=2))


if __name__ == "__main__":
    main()
