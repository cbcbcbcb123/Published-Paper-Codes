from __future__ import annotations

import csv
import json
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import qmc, rankdata, spearmanr


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from fpe import (
    Grid,
    build_generator,
    deterministic_basin_labels,
    high_state_mass,
    mean_first_passage_time,
    mutual_information,
    stationary_distribution,
)
from model import ModelParams, classify_fixed_points, fixed_points, load_config, params_from_config


PARAMETER_FIELDS = {
    "alpha1",
    "alpha2",
    "delta2",
    "K1",
    "K2",
    "m",
    "n",
    "gamma1",
    "gamma2",
    "Ec_kpa",
    "p_mech",
}


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def scale_samples(unit_samples: np.ndarray, names: list[str], ranges: dict) -> np.ndarray:
    output = np.empty_like(unit_samples)
    for index, name in enumerate(names):
        low, high = ranges[name]
        output[:, index] = low + unit_samples[:, index] * (high - low)
    return output


def partial_rank_correlations(rows: list[dict], parameter_names: list[str], output_name: str) -> list[dict]:
    matrix = np.array([[row[name] for name in parameter_names] for row in rows], dtype=float)
    output = np.array([row[output_name] for row in rows], dtype=float)
    finite = np.isfinite(output) & np.all(np.isfinite(matrix), axis=1)
    matrix = matrix[finite]
    output = output[finite]
    if matrix.shape[0] <= len(parameter_names) + 3:
        return []
    ranked_matrix = np.column_stack([rankdata(matrix[:, index]) for index in range(matrix.shape[1])])
    ranked_output = rankdata(output)
    records = []
    for index, name in enumerate(parameter_names):
        controls = np.delete(ranked_matrix, index, axis=1)
        design = np.column_stack([np.ones(controls.shape[0]), controls])
        residual_x = ranked_matrix[:, index] - design @ np.linalg.lstsq(design, ranked_matrix[:, index], rcond=None)[0]
        residual_y = ranked_output - design @ np.linalg.lstsq(design, ranked_output, rcond=None)[0]
        coefficient = float(np.corrcoef(residual_x, residual_y)[0, 1])
        records.append(
            {
                "output": output_name,
                "parameter": name,
                "prcc": coefficient,
                "n": int(matrix.shape[0]),
            }
        )
    return records


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    baseline_params = params_from_config(config)
    ranges = dict(config["uncertainty_ranges"])
    ranges["D"] = config["stochastic"]["D_uncertainty_range"]
    parameter_names = list(ranges)
    sample_count = 128
    sampler = qmc.LatinHypercube(d=len(parameter_names), seed=int(config["analysis"]["random_seed"]))
    samples = scale_samples(sampler.random(sample_count), parameter_names, ranges)
    grid = Grid.unit_square(30)
    rows: list[dict] = []

    for sample_index, sample in enumerate(samples):
        values = dict(zip(parameter_names, sample))
        parameter_updates = {key: values[key] for key in PARAMETER_FIELDS if key in values}
        params = baseline_params.updated(**parameter_updates)
        delta1 = float(values["delta1_hcc"])
        E_kpa = float(values["E_kpa_hcc"])
        diffusion = float(values["D"])
        points = fixed_points(delta1, E_kpa, params, n_grid=1400)
        classified = classify_fixed_points(points, delta1, E_kpa, params)
        stable_states = [(record["x"], record["y"]) for record in classified if record["stable"]]
        generator = build_generator(grid, delta1, E_kpa, params, diffusion)
        probability = stationary_distribution(generator)
        record = {
            "sample": sample_index,
            **values,
            "n_fixed_points": len(points),
            "n_stable": len(stable_states),
            "bistable": int(len(stable_states) == 2),
            "mutual_information_nats": mutual_information(probability, grid),
            "high_basin_mass": float("nan"),
            "mfpt_normal_to_cancer": float("nan"),
            "mfpt_cancer_to_normal": float("nan"),
            "mfpt_ratio": float("nan"),
            "log10_mfpt_ratio": float("nan"),
        }
        if len(stable_states) == 2:
            labels = deterministic_basin_labels(grid, delta1, E_kpa, params, stable_states)
            forward, _ = mean_first_passage_time(generator, labels == 1, stable_states[0], grid)
            reverse, _ = mean_first_passage_time(generator, labels == 0, stable_states[1], grid)
            ratio = reverse / forward
            record.update(
                {
                    "high_basin_mass": high_state_mass(probability, labels),
                    "mfpt_normal_to_cancer": forward,
                    "mfpt_cancer_to_normal": reverse,
                    "mfpt_ratio": ratio,
                    "log10_mfpt_ratio": np.log10(ratio),
                }
            )
        rows.append(record)
        if (sample_index + 1) % 16 == 0:
            print(f"completed {sample_index + 1}/{sample_count}")

    sensitivity_rows = []
    for output_name in ["mutual_information_nats", "high_basin_mass", "log10_mfpt_ratio"]:
        sensitivity_rows.extend(partial_rank_correlations(rows, parameter_names, output_name))
    for name in parameter_names:
        coefficient = spearmanr([row[name] for row in rows], [row["bistable"] for row in rows]).statistic
        sensitivity_rows.append(
            {
                "output": "bistable_indicator",
                "parameter": name,
                "prcc": float(coefficient),
                "n": sample_count,
            }
        )

    bistable_rows = [row for row in rows if row["bistable"] == 1]
    ratios = np.array([row["mfpt_ratio"] for row in bistable_rows], dtype=float)
    high_masses = np.array([row["high_basin_mass"] for row in bistable_rows], dtype=float)
    summary = {
        "sample_count": sample_count,
        "bistable_fraction": len(bistable_rows) / sample_count,
        "bistable_sample_count": len(bistable_rows),
        "mfpt_ratio_quantiles_bistable": {
            "q05": float(np.quantile(ratios, 0.05)) if ratios.size else float("nan"),
            "q50": float(np.quantile(ratios, 0.50)) if ratios.size else float("nan"),
            "q95": float(np.quantile(ratios, 0.95)) if ratios.size else float("nan"),
            "fraction_gt_1e4": float(np.mean(ratios > 1e4)) if ratios.size else float("nan"),
        },
        "high_basin_mass_quantiles_bistable": {
            "q05": float(np.quantile(high_masses, 0.05)) if high_masses.size else float("nan"),
            "q50": float(np.quantile(high_masses, 0.50)) if high_masses.size else float("nan"),
            "q95": float(np.quantile(high_masses, 0.95)) if high_masses.size else float("nan"),
        },
        "top_sensitivity": {},
    }
    for output_name in sorted({row["output"] for row in sensitivity_rows}):
        selected = [row for row in sensitivity_rows if row["output"] == output_name and np.isfinite(row["prcc"])]
        selected.sort(key=lambda row: abs(row["prcc"]), reverse=True)
        summary["top_sensitivity"][output_name] = selected[:5]

    results_dir = ROOT / "results"
    write_csv(results_dir / "global_uncertainty_samples.csv", rows)
    write_csv(results_dir / "global_uncertainty_sensitivity.csv", sensitivity_rows)
    with (results_dir / "global_uncertainty_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    figure, axes = plt.subplots(1, 3, figsize=(11.2, 3.5), constrained_layout=True)
    axes[0].bar(["monostable", "bistable"], [sample_count - len(bistable_rows), len(bistable_rows)], color=["#7F8C8D", "#1F6EBA"])
    axes[0].set(ylabel="Latin-hypercube samples", title="Regime uncertainty")
    if ratios.size:
        axes[1].hist(np.log10(ratios), bins=16, color="#C0392B", alpha=0.85)
        axes[1].axvline(4.0, color="#111111", ls="--", lw=1)
    axes[1].set(xlabel="log10 MFPT ratio", ylabel="count", title="Irreversibility uncertainty")
    ratio_sensitivity = [row for row in sensitivity_rows if row["output"] == "log10_mfpt_ratio" and np.isfinite(row["prcc"])]
    ratio_sensitivity.sort(key=lambda row: abs(row["prcc"]), reverse=True)
    top = ratio_sensitivity[:7]
    axes[2].barh([row["parameter"] for row in reversed(top)], [row["prcc"] for row in reversed(top)], color="#8E44AD")
    axes[2].set(xlabel="PRCC", title="Top controls of MFPT asymmetry")
    figure.savefig(results_dir / "global_uncertainty_overview.png", dpi=220)
    plt.close(figure)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
