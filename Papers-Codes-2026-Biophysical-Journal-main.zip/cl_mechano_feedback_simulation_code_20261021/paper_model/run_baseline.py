from __future__ import annotations

import csv
import json
import math
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from fpe import (
    Grid,
    build_generator,
    deterministic_basin_labels,
    high_state_mass,
    mean_first_passage_time,
    mutual_information,
    stationarity_residual,
    stationary_distribution,
)
from freidlin_wentzell import minimum_action_path
from model import (
    classify_fixed_points,
    fixed_points,
    load_config,
    params_from_config,
    stable_points,
)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def analyze_stationary(delta1: float, E_kpa: float, diffusion: float, grid_n: int, params):
    grid = Grid.unit_square(grid_n)
    generator = build_generator(grid, delta1, E_kpa, params, diffusion)
    probability = stationary_distribution(generator)
    return grid, generator, probability, {
        "mutual_information_nats": mutual_information(probability, grid),
        "stationarity_l1_residual": stationarity_residual(generator, probability),
    }


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    params = params_from_config(config)
    results_dir = ROOT / "results"
    results_dir.mkdir(exist_ok=True)
    diffusion = float(config["stochastic"]["D_reference"])
    grid_n = int(config["analysis"]["baseline_grid"])

    operating_points = {
        "normal": config["operating_points"]["normal"],
        "hcc_reference": config["operating_points"]["hcc_reference"],
    }
    for record in config["operating_points"]["grade_path"]:
        operating_points[record["grade"]] = record

    fixed_point_rows: list[dict] = []
    deterministic_summary: dict[str, dict] = {}
    for label, operating in operating_points.items():
        delta1 = float(operating["delta1"])
        E_kpa = float(operating["E_kpa"])
        points = fixed_points(delta1, E_kpa, params)
        classified = classify_fixed_points(points, delta1, E_kpa, params)
        deterministic_summary[label] = {
            "delta1": delta1,
            "E_kpa": E_kpa,
            "fixed_points": classified,
            "n_fixed_points": len(classified),
            "n_stable": sum(record["stable"] for record in classified),
        }
        for point_index, record in enumerate(classified):
            fixed_point_rows.append(
                {
                    "condition": label,
                    "delta1": delta1,
                    "E_kpa": E_kpa,
                    "point_index": point_index,
                    **record,
                }
            )

    hcc = config["operating_points"]["hcc_reference"]
    hcc_delta1 = float(hcc["delta1"])
    hcc_E = float(hcc["E_kpa"])
    hcc_all = fixed_points(hcc_delta1, hcc_E, params)
    hcc_stable = stable_points(hcc_delta1, hcc_E, params)
    if len(hcc_all) != 3 or len(hcc_stable) != 2:
        raise RuntimeError("HCC reference must contain two attractors and one saddle")
    low_state, high_state = hcc_stable[0], hcc_stable[-1]
    saddle = hcc_all[1]

    grid, generator, probability, stationary_metrics = analyze_stationary(
        hcc_delta1, hcc_E, diffusion, grid_n, params
    )
    basin_labels = deterministic_basin_labels(grid, hcc_delta1, hcc_E, params, hcc_stable)
    mfpt_normal_to_cancer, mfpt_field_normal = mean_first_passage_time(
        generator, basin_labels == 1, low_state, grid
    )
    mfpt_cancer_to_normal, mfpt_field_cancer = mean_first_passage_time(
        generator, basin_labels == 0, high_state, grid
    )

    path_normal = minimum_action_path(
        low_state,
        saddle,
        hcc_delta1,
        hcc_E,
        params,
        nodes=int(config["analysis"]["fw_path_nodes"]),
        seed=int(config["analysis"]["random_seed"]),
    )
    path_cancer = minimum_action_path(
        high_state,
        saddle,
        hcc_delta1,
        hcc_E,
        params,
        nodes=int(config["analysis"]["fw_path_nodes"]),
        seed=int(config["analysis"]["random_seed"]) + 1,
    )
    action_difference = path_cancer.action - path_normal.action
    log_asymptotic_ratio = action_difference / diffusion

    stochastic_summary = {
        "delta1": hcc_delta1,
        "E_kpa": hcc_E,
        "diffusion": diffusion,
        "grid_n": grid_n,
        **stationary_metrics,
        "high_basin_stationary_mass": high_state_mass(probability, basin_labels),
        "mfpt_normal_to_cancer_dimensionless": mfpt_normal_to_cancer,
        "mfpt_cancer_to_normal_dimensionless": mfpt_cancer_to_normal,
        "mfpt_ratio_backward": mfpt_cancer_to_normal / mfpt_normal_to_cancer,
        "fw_action_normal_to_saddle": path_normal.action,
        "fw_action_cancer_to_saddle": path_cancer.action,
        "fw_action_difference": action_difference,
        "fw_log_ratio_asymptotic": log_asymptotic_ratio,
        "fw_ratio_asymptotic": math.exp(min(log_asymptotic_ratio, 700.0)),
        "physical_time_scenarios": [
            {
                "tau0_hours": tau0,
                "normal_to_cancer_hours": mfpt_normal_to_cancer * tau0,
                "cancer_to_normal_hours": mfpt_cancer_to_normal * tau0,
            }
            for tau0 in config["stochastic"]["physical_time_scale_hours_scenarios"]
        ],
    }

    comparison_rows: list[dict] = []
    revised_spearman = {2.0: 0.6259740259740261, 6.0: 0.6641013016281091, 14.0: 0.7237727033448711, 25.0: 0.7272727272727274}
    for E_kpa in [2.0, 6.0, 14.0, 25.0]:
        comparison_grid, comparison_generator, comparison_probability, comparison_metrics = analyze_stationary(
            1.4, E_kpa, diffusion, max(50, grid_n // 2), params
        )
        comparison_rows.append(
            {
                "analysis": "fixed_delta1_stiffness_sweep",
                "delta1": 1.4,
                "E_kpa": E_kpa,
                "mutual_information_nats": comparison_metrics["mutual_information_nats"],
                "spearman_TCGA": revised_spearman[E_kpa],
                "stationarity_l1_residual": comparison_metrics["stationarity_l1_residual"],
            }
        )
    for grade_record in config["operating_points"]["grade_path"]:
        grade_grid, grade_generator, grade_probability, grade_metrics = analyze_stationary(
            float(grade_record["delta1"]),
            float(grade_record["E_kpa"]),
            diffusion,
            max(50, grid_n // 2),
            params,
        )
        comparison_rows.append(
            {
                "analysis": "grade_anchor_path",
                "grade": grade_record["grade"],
                "delta1": grade_record["delta1"],
                "E_kpa": grade_record["E_kpa"],
                "mutual_information_nats": grade_metrics["mutual_information_nats"],
                "spearman_TCGA": revised_spearman[float(grade_record["E_kpa"])],
                "stationarity_l1_residual": grade_metrics["stationarity_l1_residual"],
            }
        )

    path_rows = []
    for direction, result in [("normal_to_saddle", path_normal), ("cancer_to_saddle", path_cancer)]:
        for node_index, (x_value, y_value) in enumerate(result.path):
            path_rows.append(
                {
                    "direction": direction,
                    "node": node_index,
                    "x": x_value,
                    "y": y_value,
                    "action": result.action,
                    "restart": result.restart,
                }
            )

    probability_grid = probability.reshape((grid.n, grid.n))
    probability_rows = []
    for j, y_value in enumerate(grid.centers):
        for i, x_value in enumerate(grid.centers):
            index = j * grid.n + i
            probability_rows.append(
                {
                    "x": x_value,
                    "y": y_value,
                    "probability_mass": probability[index],
                    "basin": int(basin_labels[index]),
                    "mfpt_to_cancer": mfpt_field_normal[index],
                    "mfpt_to_normal": mfpt_field_cancer[index],
                }
            )

    summary = {
        "canonical_parameters": params.to_dict(),
        "deterministic": deterministic_summary,
        "stochastic_hcc_reference": stochastic_summary,
        "interpretation_status": {
            "parameter_calibration": config["stochastic"]["calibration_status"],
            "grade_anchors": "representative_not_patient_specific",
        },
    }
    with (results_dir / "baseline_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    write_csv(results_dir / "fixed_points.csv", fixed_point_rows)
    write_csv(results_dir / "minimum_action_paths.csv", path_rows)
    write_csv(results_dir / "stationary_probability_and_mfpt.csv", probability_rows)
    write_csv(results_dir / "mutual_information_comparison.csv", comparison_rows)

    figure, axes = plt.subplots(1, 3, figsize=(11.0, 3.5), constrained_layout=True)
    contour = axes[0].contourf(grid.centers, grid.centers, probability_grid, levels=24, cmap="magma")
    figure.colorbar(contour, ax=axes[0], label="stationary probability mass")
    axes[0].plot(path_normal.path[:, 0], path_normal.path[:, 1], color="#1F77B4", lw=2, label="N to S MAP")
    axes[0].plot(path_cancer.path[:, 0], path_cancer.path[:, 1], color="#C0392B", lw=2, label="C to S MAP")
    axes[0].scatter([low_state[0], saddle[0], high_state[0]], [low_state[1], saddle[1], high_state[1]], c=["#1F77B4", "#777777", "#C0392B"], s=35)
    axes[0].set(xlabel="ITGB1, x", ylabel="YAP/TEAD, y", title="Stationary FPE and minimum-action paths")
    axes[0].legend(fontsize=7)

    fixed_rows = [row for row in comparison_rows if row["analysis"] == "fixed_delta1_stiffness_sweep"]
    axes[1].plot([row["E_kpa"] for row in fixed_rows], [row["mutual_information_nats"] for row in fixed_rows], "o-", color="#8E44AD")
    axes[1].set(xlabel="ECM stiffness (kPa)", ylabel="FPE mutual information (nats)", title="Fixed feedback strength")

    marginal_x = probability_grid.sum(axis=0)
    marginal_y = probability_grid.sum(axis=1)
    axes[2].plot(grid.centers, marginal_x / marginal_x.max(), color="#E67E22", label="ITGB1")
    axes[2].plot(grid.centers, marginal_y / marginal_y.max(), color="#1F6EBA", label="YAP/TEAD")
    axes[2].set(xlabel="normalized state", ylabel="marginal probability / max", title="Stationary marginals")
    axes[2].legend(fontsize=8)
    figure.savefig(results_dir / "baseline_theory_rebuild.png", dpi=220)
    plt.close(figure)

    print(json.dumps(stochastic_summary, indent=2))


if __name__ == "__main__":
    main()
