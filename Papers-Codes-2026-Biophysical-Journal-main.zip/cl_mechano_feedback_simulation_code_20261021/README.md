# CL-mechano-feedback simulation code

Packaged on 21 October 2026. Start with `paper_model/`.

This archive contains the deterministic ITGB1-YAP/TEAD feedback model,
reflecting Fokker-Planck solver, backward mean first-passage times (MFPT),
Freidlin-Wentzell geometric action paths, reflected-SDE validation, parameter
scans, and retained numerical outputs. All copied scientific source files and
configuration files are byte-identical to the project originals.

## Which version belongs to the proof?

* `paper_model/`: source directory v01_20260713, internal model v3_reviewed.
  This matches the latest available 17 October proof: 512 Sobol points,
  249 bistable points and 42/249 above the 10^4 MFPT-ratio criterion.
  The retained summary records one grid fallback; it has not been hidden.
* `additional_analysis/`: source directory v02_20260728, internal model v4.
  A separate robustness extension with 8 x 512 randomized QMC points,
  alternative target sets, noise forms and coupling structures. It is not
  a substitute for the proof's 512-point analysis. Its original README calls
  it a replacement; that statement belongs to its July revision context.

The version assignment was checked against
`manuscript_language_revised_red_20261017_v05.docx` and the retained numerical
summaries. Manuscript documents, patient data and experimental images are not
included in this simulation-code archive.

## Environment and quick verification

The local verification used CPython 3.13.7 on Windows. Exact observed package
versions and the command results are in `verification/verification.json`.
From an extracted copy of this archive, use an existing Python environment or
create one inside that extracted folder:

```text
python -m venv .venv
```

Activate `.venv` using the command for your operating system, then:

```text
python -m pip install -r requirements.txt
python -B verify_package.py
python -B -m pytest -p no:cacheprovider -q paper_model/tests/test_theory.py
python -B -m pytest -p no:cacheprovider -q additional_analysis/tests/test_theory.py
```

Run the two test files in separate Python processes: both historical versions
use the same module names. No GPU is required by the supplied commands. The
historical environment used a CUDA-tagged PyTorch wheel, but all packaged
model routines use CPU tensors by default. `requirements.txt` pins the public
PyTorch version; `additional_analysis/environment/requirements-lock.txt`
preserves the original wheel build record. Installation and a clean-environment
install were not performed during packaging.

## Recompute the proof model

Run these commands from `paper_model/`, in a working copy: the scripts write
their results into their own `results/` directory and can replace retained
outputs. These are substantial computations, not installation checks.

```text
python -X utf8 run_baseline.py
python -X utf8 run_validation.py
python -X utf8 run_final_validation.py
python -X utf8 run_global_uncertainty_final.py
```

`run_uncertainty.py` is an earlier exploratory scan and is not the final
512-point proof scan. Final reference summaries are
`results/final_review/final_validation_summary.json` and
`results/final_review/global_range_scan_summary.json`.

## Theory panels and figure numbering

`paper_model/plotting_inputs/` contains retained simulation plotting tables;
the clinical TCGA correlation panel and its stale plotting manifest are
excluded. Historical Fig.2/3/5 directory labels predate proof renumbering:
the information panel appears in proof Fig.5 and the density/kinetics panels
in proof Fig.6. These scripts reproduce scientific panel data and historical
layouts, not the final proof's complete artwork or typesetting.

From `paper_model/`, use the supplied wrapper, which directs all panel output
inside this extracted package and limits selection to simulation panels:

```text
python -X utf8 run_theory_panels.py --help
python -X utf8 run_theory_panels.py fig2B fig2C fig2D fig3A fig3C fig5A fig5B fig5C
```

The original `build_final_panels.py` and `build_compressed_panels.py` are
included unchanged for provenance. Direct execution retains their original
submission-directory assumptions; use `run_theory_panels.py` for portable
panel generation. The conceptual Fig.2A drawing and the clinical Fig.3B are
excluded from the wrapper. `make_candidate_figures.py` and its candidate
outputs are omitted because they include provisional illustrative values.

## Additional robustness analyses

See `additional_analysis/README.md` for its original reproduction commands,
run from that directory. Retained output tables and the self-contained
robustness notebook are included. Existing historical reports describe the
July analysis and are not new verification of the October proof. Cached
bytecode, intermediate in-progress tables and machine logs are excluded.

## Interpretation and verification boundary

The original configuration retains `grade_path` and G1-G4 field labels.
These are the illustrative S1-S4 model scenarios in the current paper, not
patient-specific grades or measured stiffness. The noise level and physical
time scale are not biologically calibrated. Existing NaN fields in historical
JSON results are preserved; Python can read these files, while strict JSON
consumers may require explicit handling.

Packaging verification covers source-copy hashes, Python syntax, the two
existing CPU test suites, retained scan row counts, manifest integrity and
ZIP readback. Full parameter scans, new SDE campaigns, path optimization and
complete figure regeneration were NOT_RUN during packaging. See
`verification/verification.json` for exact results.

`package_manifest.json` lists payload hashes and project-relative provenance.
The manifest excludes itself. `verify_package.py` reads this manifest and
does not write files. No redistribution license or citation metadata has
been assigned by the packaging process.
