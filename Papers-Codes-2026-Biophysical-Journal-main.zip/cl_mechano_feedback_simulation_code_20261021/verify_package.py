from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "package_manifest.json").read_text(encoding="utf-8"))
errors = []
for record in manifest["files"]:
    relative = Path(record["path"])
    path = (ROOT / relative).resolve()
    if relative.is_absolute() or not path.is_relative_to(ROOT):
        errors.append(f"Unsafe manifest path: {relative}")
        continue
    if not path.is_file():
        errors.append(f"Missing: {relative}")
        continue
    with path.open("rb") as handle:
        digest = hashlib.file_digest(handle, "sha256").hexdigest()
    if path.stat().st_size != record["bytes"] or digest != record["sha256"]:
        errors.append(f"Mismatch: {relative}")
if errors:
    print("FAIL\n" + "\n".join(errors))
    sys.exit(1)
print(f"PASS: {len(manifest['files'])} payload files match SHA-256 manifest.")
