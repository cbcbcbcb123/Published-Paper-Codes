# Version-4 mechanochemical model robustness package

This directory is the canonical replacement for the version-1 rebuild package.
It preserves the original deterministic ITGB1-YAP/TEAD product-coupling model
and adds the analyses required to delimit its numerical and biological
accuracy.

## Canonical scope

- Primary deterministic model: product coupling `M(E) H(x)`.
- Primary stochastic model: additive isotropic noise with reflection on
  `[0,1]^2`.
- Primary MFPT endpoint: first entry into the opposite deterministic basin.
- Prespecified endpoint checks: attractor-core targets and 0.9 committor
  commitment targets.
- Prespecified stochastic-form checks: additive-reflecting, conservative
  Jacobi mobility, squared bounded mobility ("logit-mobility"), and
  anisotropic additive noise. The state-dependent alternatives use Fickian
  forward flux `b p - D g grad(p)`; their equivalent Ito drift is
  `b + D grad(g)`.
- Prespecified structural checks: product, additive, and
  stiffness-dependent-threshold coupling forms matched at the reference
  saddle input.
- Global uncertainty: independently scrambled randomized Sobol QMC in
  dimensionless parameters with `gamma1=1`. Uncertainty intervals quantify
  randomized-integration error across scrambles and are not biological
  confidence intervals.

## Reproduction

Run from this directory:

```text
python -X utf8 scripts/run_revised_baseline.py
python -X utf8 scripts/run_randomized_qmc.py
python -X utf8 scripts/repair_qmc_failures.py
python -X utf8 scripts/run_noise_thresholds.py
python -X utf8 scripts/build_robustness_notebook.py
python -m pytest -p no:cacheprovider -q tests/test_theory.py
python -X utf8 scripts/build_audit_manifest.py
```

Exact software versions are recorded in `environment/requirements-lock.txt`
and `environment/runtime_manifest.json`.

## Interpretation guardrails

The approximate 400-fold reference asymmetry is a conditional result of the
primary additive-reflecting scenario, not a calibrated biological constant.
The direction of high-state stabilization is compared across target
definitions and stochastic forms; its magnitude is explicitly treated as
model-form dependent. The alternative additive stiffness-coupling structure
does not support bistability at the matched reference condition, so
bistability is presented as a prediction of the specified feedback
architecture rather than a structure-independent consequence of stiffness.

No legacy outputs are stored in this directory. The unique canonical summaries
are `results/revised_baseline_summary.json` and
`results/randomized_qmc_summary.json`.
