from __future__ import annotations

import csv
import json
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np
from scipy.stats import qmc, rankdata, t


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from fpe import (  # noqa: E402
    Grid,
    build_generator,
    deterministic_basin_labels,
    high_state_mass,
    mean_first_passage_time,
    stationary_distribution,
)
from model import (  # noqa: E402
    classify_fixed_points,
    fixed_points,
    load_config,
    params_from_config,
)


RESULTS = ROOT / "results"


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def scale_unit_samples(unit_samples: np.ndarray, names: list[str], ranges: dict) -> np.ndarray:
    scaled = np.empty_like(unit_samples)
    for column, name in enumerate(names):
        lower, upper = ranges[name]
        scaled[:, column] = lower + unit_samples[:, column] * (upper - lower)
    return scaled


def partial_rank_coefficients(matrix: np.ndarray, output: np.ndarray) -> np.ndarray:
    ranked_matrix = np.column_stack(
        [rankdata(matrix[:, column]) for column in range(matrix.shape[1])]
    )
    ranked_output = rankdata(output)
    coefficients = np.full(matrix.shape[1], np.nan, dtype=float)
    for column in range(matrix.shape[1]):
        other_columns = [index for index in range(matrix.shape[1]) if index != column]
        design = np.column_stack(
            [np.ones(matrix.shape[0]), ranked_matrix[:, other_columns]]
        )
        residual_x = ranked_matrix[:, column] - design @ np.linalg.lstsq(
            design,
            ranked_matrix[:, column],
            rcond=None,
        )[0]
        residual_y = ranked_output - design @ np.linalg.lstsq(
            design,
            ranked_output,
            rcond=None,
        )[0]
        if np.std(residual_x) > 0.0 and np.std(residual_y) > 0.0:
            coefficients[column] = np.corrcoef(residual_x, residual_y)[0, 1]
    return coefficients


def randomized_qmc_interval(values: np.ndarray) -> dict[str, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    mean = float(np.mean(values))
    if values.size < 2:
        return {
            "mean": mean,
            "sd_across_scrambles": float("nan"),
            "randomization_se": float("nan"),
            "randomized_qmc_95_low": float("nan"),
            "randomized_qmc_95_high": float("nan"),
            "min": mean,
            "max": mean,
        }
    standard_deviation = float(np.std(values, ddof=1))
    standard_error = standard_deviation / np.sqrt(values.size)
    multiplier = float(t.ppf(0.975, values.size - 1))
    return {
        "mean": mean,
        "sd_across_scrambles": standard_deviation,
        "randomization_se": standard_error,
        "randomized_qmc_95_low": mean - multiplier * standard_error,
        "randomized_qmc_95_high": mean + multiplier * standard_error,
        "min": float(np.min(values)),
        "max": float(np.max(values)),
    }


def analyze_sample(
    values: dict[str, float],
    base_params,
    grid_n: int,
) -> dict:
    params = replace(
        base_params,
        alpha1=values["alpha1_over_gamma1"],
        alpha2=values["alpha2_over_gamma1"],
        delta2=values["delta2_over_gamma1"],
        gamma1=1.0,
        gamma2=values["gamma2_over_gamma1"],
        K1=values["K1"],
        K2=values["K2"],
        m=values["m"],
        n=values["n"],
        Ec_kpa=values["Ec_kpa"],
        p_mech=values["p_mech"],
    )
    delta1 = values["delta1_over_gamma1"]
    E_kpa = values["E_kpa_hcc"]
    diffusion = values["D_over_gamma1"]
    points = fixed_points(delta1, E_kpa, params, n_grid=3000)
    classified = classify_fixed_points(points, delta1, E_kpa, params)
    stable = [
        (record["x"], record["y"])
        for record in classified
        if record["stable"]
    ]
    output = {
        **values,
        "fixed_point_count": len(points),
        "stable_state_count": len(stable),
        "bistable": int(len(points) == 3 and len(stable) == 2),
        "mfpt_solve_failed": 0,
        "high_basin_mass": float("nan"),
        "basin_entry_low_to_high": float("nan"),
        "basin_entry_high_to_low": float("nan"),
        "basin_entry_ratio": float("nan"),
        "log10_basin_entry_ratio": float("nan"),
    }
    if not output["bistable"]:
        return output
    low_state, high_state = stable[0], stable[-1]
    grid = Grid.unit_square(grid_n)
    try:
        generator = build_generator(
            grid,
            delta1,
            E_kpa,
            params,
            diffusion,
        )
        probability = stationary_distribution(generator)
        basins = deterministic_basin_labels(
            grid,
            delta1,
            E_kpa,
            params,
            stable,
        )
        forward, _ = mean_first_passage_time(
            generator,
            basins == 1,
            low_state,
            grid,
        )
        reverse, _ = mean_first_passage_time(
            generator,
            basins == 0,
            high_state,
            grid,
        )
        ratio = reverse / forward
    except Exception:
        output["mfpt_solve_failed"] = 1
        return output
    output.update(
        {
            "high_basin_mass": high_state_mass(probability, basins),
            "basin_entry_low_to_high": forward,
            "basin_entry_high_to_low": reverse,
            "basin_entry_ratio": ratio,
            "log10_basin_entry_ratio": np.log10(ratio),
        }
    )
    return output


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    config = load_config(ROOT / "config" / "canonical_model.json")
    base_params = params_from_config(config)
    ranges = config["dimensionless_uncertainty_ranges"]
    names = list(ranges)
    sample_count = int(config["analysis"]["global_range_scan_samples_per_scramble"])
    scramble_count = int(config["analysis"]["global_range_scan_scrambles"])
    grid_n = int(config["analysis"]["global_range_scan_grid"])
    seed = int(config["analysis"]["random_seed"])
    power = int(round(np.log2(sample_count)))
    if 2**power != sample_count:
        raise ValueError("samples per scramble must be a power of two")

    all_rows: list[dict] = []
    scramble_rows: list[dict] = []
    sensitivity_rows: list[dict] = []
    convergence_rows: list[dict] = []

    for scramble_index in range(scramble_count):
        sampler = qmc.Sobol(
            d=len(names),
            scramble=True,
            seed=seed + 1009 * scramble_index,
        )
        unit_samples = sampler.random_base2(power)
        samples = scale_unit_samples(unit_samples, names, ranges)
        current_rows: list[dict] = []
        for sample_index, sample in enumerate(samples):
            values = {
                name: float(sample[column])
                for column, name in enumerate(names)
            }
            record = analyze_sample(values, base_params, grid_n)
            record.update(
                {
                    "scramble": scramble_index,
                    "sample_index": sample_index,
                }
            )
            current_rows.append(record)
        all_rows.extend(current_rows)

        for prefix_size in [64, 128, 256, 512]:
            if prefix_size > sample_count:
                continue
            prefix = current_rows[:prefix_size]
            bistable_prefix = [row for row in prefix if row["bistable"]]
            finite_prefix = [
                row
                for row in bistable_prefix
                if np.isfinite(row["basin_entry_ratio"])
            ]
            convergence_rows.append(
                {
                    "scramble": scramble_index,
                    "prefix_size": prefix_size,
                    "bistable_fraction": len(bistable_prefix) / prefix_size,
                    "fraction_ratio_gt_1e4_given_bistable": (
                        np.mean(
                            [
                                row["basin_entry_ratio"] > 1e4
                                for row in finite_prefix
                            ]
                        )
                        if finite_prefix
                        else float("nan")
                    ),
                }
            )

        bistable_rows = [row for row in current_rows if row["bistable"]]
        finite_rows = [
            row
            for row in bistable_rows
            if np.isfinite(row["basin_entry_ratio"])
        ]
        ratios = np.asarray(
            [row["basin_entry_ratio"] for row in finite_rows],
            dtype=float,
        )
        scramble_rows.append(
            {
                "scramble": scramble_index,
                "sample_count": sample_count,
                "bistable_count": len(bistable_rows),
                "bistable_fraction": len(bistable_rows) / sample_count,
                "finite_mfpt_count": len(finite_rows),
                "mfpt_solve_failure_count": sum(
                    row["mfpt_solve_failed"] for row in current_rows
                ),
                "fraction_ratio_gt_1e4_given_bistable": (
                    float(np.mean(ratios > 1e4))
                    if ratios.size
                    else float("nan")
                ),
                "ratio_q05": (
                    float(np.quantile(ratios, 0.05))
                    if ratios.size
                    else float("nan")
                ),
                "ratio_q50": (
                    float(np.quantile(ratios, 0.50))
                    if ratios.size
                    else float("nan")
                ),
                "ratio_q95": (
                    float(np.quantile(ratios, 0.95))
                    if ratios.size
                    else float("nan")
                ),
            }
        )

        if len(finite_rows) > len(names) + 4:
            matrix = np.asarray(
                [[row[name] for name in names] for row in finite_rows],
                dtype=float,
            )
            for output_name in ["log10_basin_entry_ratio", "high_basin_mass"]:
                output = np.asarray(
                    [row[output_name] for row in finite_rows],
                    dtype=float,
                )
                coefficients = partial_rank_coefficients(matrix, output)
                for parameter_name, coefficient in zip(names, coefficients):
                    sensitivity_rows.append(
                        {
                            "scramble": scramble_index,
                            "output": output_name,
                            "parameter": parameter_name,
                            "prcc": float(coefficient),
                            "conditional_bistable_sample_count": len(finite_rows),
                        }
                    )

        write_csv(RESULTS / "randomized_qmc_samples_in_progress.csv", all_rows)
        write_csv(RESULTS / "randomized_qmc_scramble_summary_in_progress.csv", scramble_rows)
        print(
            f"completed scramble {scramble_index + 1}/{scramble_count}: "
            f"bistable={len(bistable_rows)}/{sample_count}",
            flush=True,
        )

    write_csv(RESULTS / "randomized_qmc_samples.csv", all_rows)
    write_csv(RESULTS / "randomized_qmc_scramble_summary.csv", scramble_rows)
    write_csv(RESULTS / "randomized_qmc_prcc_by_scramble.csv", sensitivity_rows)
    write_csv(RESULTS / "randomized_qmc_convergence.csv", convergence_rows)

    bistable_estimates = np.asarray(
        [row["bistable_fraction"] for row in scramble_rows],
        dtype=float,
    )
    strong_ratio_estimates = np.asarray(
        [
            row["fraction_ratio_gt_1e4_given_bistable"]
            for row in scramble_rows
        ],
        dtype=float,
    )
    prcc_summary = []
    for output_name in sorted({row["output"] for row in sensitivity_rows}):
        for parameter_name in names:
            values = np.asarray(
                [
                    row["prcc"]
                    for row in sensitivity_rows
                    if row["output"] == output_name
                    and row["parameter"] == parameter_name
                ],
                dtype=float,
            )
            interval = randomized_qmc_interval(values)
            prcc_summary.append(
                {
                    "output": output_name,
                    "parameter": parameter_name,
                    **interval,
                }
            )
    write_csv(RESULTS / "randomized_qmc_prcc_summary.csv", prcc_summary)

    summary = {
        "design": {
            "method": "independently scrambled randomized Sobol QMC",
            "scrambles": scramble_count,
            "samples_per_scramble": sample_count,
            "total_samples": scramble_count * sample_count,
            "grid_n": grid_n,
            "gamma1_fixed": 1.0,
            "parameterization": "all kinetic rates and D expressed relative to gamma1",
            "uncertainty_interpretation": (
                "intervals quantify randomized-QMC integration error across "
                "independent scrambles, not biological sampling uncertainty"
            ),
        },
        "bistable_fraction": randomized_qmc_interval(bistable_estimates),
        "fraction_ratio_gt_1e4_given_bistable": randomized_qmc_interval(
            strong_ratio_estimates
        ),
        "mfpt_solve_failure_count": int(
            sum(row["mfpt_solve_failure_count"] for row in scramble_rows)
        ),
        "prcc_top_by_absolute_mean": {},
    }
    for output_name in sorted({row["output"] for row in prcc_summary}):
        selected = [row for row in prcc_summary if row["output"] == output_name]
        selected.sort(key=lambda row: abs(row["mean"]), reverse=True)
        summary["prcc_top_by_absolute_mean"][output_name] = selected[:7]
    with (RESULTS / "randomized_qmc_summary.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
