from __future__ import annotations

import csv
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import brentq


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from fpe import (  # noqa: E402
    Grid,
    build_generator,
    deterministic_basin_labels,
    mean_first_passage_time,
)
from model import fixed_points, load_config, params_from_config, stable_points  # noqa: E402


RESULTS = ROOT / "results"


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    params = params_from_config(config)
    delta1 = float(config["operating_points"]["hcc_reference"]["delta1"])
    E_kpa = float(config["operating_points"]["hcc_reference"]["E_kpa"])
    points = fixed_points(delta1, E_kpa, params, n_grid=8000)
    stable = stable_points(delta1, E_kpa, params)
    low_state, saddle, high_state = stable[0], points[1], stable[-1]
    target_ratio = 1e4
    rows = []

    for noise_model in config["analysis"]["noise_models"]:
        for grid_n in [60, 80, 100]:
            grid = Grid.unit_square(grid_n)
            basins = deterministic_basin_labels(
                grid,
                delta1,
                E_kpa,
                params,
                stable,
            )
            cache: dict[float, float] = {}

            def log_ratio_minus_target(diffusion: float) -> float:
                key = float(diffusion)
                if key not in cache:
                    try:
                        generator = build_generator(
                            grid,
                            delta1,
                            E_kpa,
                            params,
                            key,
                            noise_model=noise_model,
                            reference_state=saddle,
                        )
                        forward, _ = mean_first_passage_time(
                            generator,
                            basins == 1,
                            low_state,
                            grid,
                        )
                        reverse, _ = mean_first_passage_time(
                            generator,
                            basins == 0,
                            high_state,
                            grid,
                        )
                        cache[key] = float(
                            np.log(reverse / forward) - np.log(target_ratio)
                        )
                    except Exception:
                        cache[key] = float("nan")
                return cache[key]

            scan = np.geomspace(0.0025, 0.02, 18)
            values = [log_ratio_minus_target(float(value)) for value in scan]
            lower = float("nan")
            upper = float("nan")
            for left, right, left_value, right_value in zip(
                scan[:-1],
                scan[1:],
                values[:-1],
                values[1:],
            ):
                if not (np.isfinite(left_value) and np.isfinite(right_value)):
                    continue
                if left_value == 0.0 or left_value * right_value < 0.0:
                    lower = float(left)
                    upper = float(right)
                    break
            if np.isfinite(lower):
                threshold = float(
                    brentq(
                        log_ratio_minus_target,
                        lower,
                        upper,
                        xtol=1e-10,
                        rtol=1e-10,
                    )
                )
                status = "crossing_found"
            else:
                threshold = float("nan")
                status = "no_resolved_crossing_in_0.0025_to_0.02"
            rows.append(
                {
                    "noise_model": noise_model,
                    "grid_n": grid_n,
                    "target_basin_entry_ratio": target_ratio,
                    "D_threshold": threshold,
                    "bracket_low": lower,
                    "bracket_high": upper,
                    "status": status,
                }
            )
            print(
                f"{noise_model} grid={grid_n}: D*={threshold}",
                flush=True,
            )

    write_csv(RESULTS / "noise_threshold_sensitivity.csv", rows)
    summary = {}
    for noise_model in config["analysis"]["noise_models"]:
        values = np.asarray(
            [
                row["D_threshold"]
                for row in rows
                if row["noise_model"] == noise_model
                and np.isfinite(row["D_threshold"])
            ],
            dtype=float,
        )
        summary[noise_model] = {
            "grid_values": values.tolist(),
            "mean": float(np.mean(values)) if values.size else float("nan"),
            "min": float(np.min(values)) if values.size else float("nan"),
            "max": float(np.max(values)) if values.size else float("nan"),
            "half_grid_range": (
                float(0.5 * (np.max(values) - np.min(values)))
                if values.size
                else float("nan")
            ),
        }
    with (RESULTS / "noise_threshold_summary.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            {
                "target_definition": "first entry into the opposite deterministic basin",
                "target_ratio": target_ratio,
                "uncertainty_note": (
                    "The grid range is numerical discretization variation, "
                    "not a statistical confidence interval."
                ),
                "noise_models": summary,
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )


if __name__ == "__main__":
    main()
