from __future__ import annotations

import csv
import json
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from model import load_config, params_from_config  # noqa: E402
from run_randomized_qmc import (  # noqa: E402
    analyze_sample,
    partial_rank_coefficients,
    randomized_qmc_interval,
    write_csv,
)


RESULTS = ROOT / "results"


def read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    config = load_config(ROOT / "config" / "canonical_model.json")
    base_params = params_from_config(config)
    names = list(config["dimensionless_uncertainty_ranges"])
    scramble_count = int(config["analysis"]["global_range_scan_scrambles"])
    sample_count = int(config["analysis"]["global_range_scan_samples_per_scramble"])
    rows = read_csv(RESULTS / "randomized_qmc_samples.csv")

    repaired = []
    for row in rows:
        failed = int(float(row.get("mfpt_solve_failed", 0))) == 1
        if "mfpt_used_fallback" not in row or row["mfpt_used_fallback"] == "":
            row["mfpt_used_fallback"] = 0
        if "mfpt_grid_used" not in row or row["mfpt_grid_used"] == "":
            row["mfpt_grid_used"] = int(
                config["analysis"]["global_range_scan_grid"]
            )
        if not failed:
            continue
        values = {name: float(row[name]) for name in names}
        result = None
        fallback_grid = None
        for candidate_grid in [40, 72, 100]:
            candidate = analyze_sample(values, base_params, grid_n=candidate_grid)
            result = candidate
            fallback_grid = candidate_grid
            if candidate["mfpt_solve_failed"] == 0:
                break
        assert result is not None and fallback_grid is not None
        for key, value in result.items():
            row[key] = value
        row["mfpt_used_fallback"] = 1
        row["mfpt_grid_used"] = fallback_grid
        repaired.append(
            {
                "scramble": int(float(row["scramble"])),
                "sample_index": int(float(row["sample_index"])),
                "fallback_grid": fallback_grid,
                "fallback_succeeded": int(result["mfpt_solve_failed"] == 0),
                "basin_entry_ratio": result["basin_entry_ratio"],
            }
        )

    write_csv(RESULTS / "randomized_qmc_samples.csv", rows)

    scramble_rows = []
    sensitivity_rows = []
    for scramble_index in range(scramble_count):
        current = [
            row
            for row in rows
            if int(float(row["scramble"])) == scramble_index
        ]
        bistable = [row for row in current if int(float(row["bistable"])) == 1]
        finite = [
            row
            for row in bistable
            if np.isfinite(float(row["basin_entry_ratio"]))
        ]
        ratios = np.asarray(
            [float(row["basin_entry_ratio"]) for row in finite],
            dtype=float,
        )
        scramble_rows.append(
            {
                "scramble": scramble_index,
                "sample_count": sample_count,
                "bistable_count": len(bistable),
                "bistable_fraction": len(bistable) / sample_count,
                "finite_mfpt_count": len(finite),
                "mfpt_solve_failure_count": sum(
                    int(float(row["mfpt_solve_failed"])) for row in current
                ),
                "mfpt_fallback_count": sum(
                    int(float(row["mfpt_used_fallback"])) for row in current
                ),
                "fraction_ratio_gt_1e4_given_bistable": float(
                    np.mean(ratios > 1e4)
                ),
                "ratio_q05": float(np.quantile(ratios, 0.05)),
                "ratio_q50": float(np.quantile(ratios, 0.50)),
                "ratio_q95": float(np.quantile(ratios, 0.95)),
            }
        )
        matrix = np.asarray(
            [[float(row[name]) for name in names] for row in finite],
            dtype=float,
        )
        for output_name in ["log10_basin_entry_ratio", "high_basin_mass"]:
            output = np.asarray(
                [float(row[output_name]) for row in finite],
                dtype=float,
            )
            coefficients = partial_rank_coefficients(matrix, output)
            for parameter_name, coefficient in zip(names, coefficients):
                sensitivity_rows.append(
                    {
                        "scramble": scramble_index,
                        "output": output_name,
                        "parameter": parameter_name,
                        "prcc": float(coefficient),
                        "conditional_bistable_sample_count": len(finite),
                    }
                )

    write_csv(RESULTS / "randomized_qmc_scramble_summary.csv", scramble_rows)
    write_csv(RESULTS / "randomized_qmc_prcc_by_scramble.csv", sensitivity_rows)

    prcc_summary = []
    for output_name in sorted({row["output"] for row in sensitivity_rows}):
        for parameter_name in names:
            values = np.asarray(
                [
                    row["prcc"]
                    for row in sensitivity_rows
                    if row["output"] == output_name
                    and row["parameter"] == parameter_name
                ],
                dtype=float,
            )
            prcc_summary.append(
                {
                    "output": output_name,
                    "parameter": parameter_name,
                    **randomized_qmc_interval(values),
                }
            )
    write_csv(RESULTS / "randomized_qmc_prcc_summary.csv", prcc_summary)

    bistable_estimates = np.asarray(
        [row["bistable_fraction"] for row in scramble_rows],
        dtype=float,
    )
    strong_estimates = np.asarray(
        [
            row["fraction_ratio_gt_1e4_given_bistable"]
            for row in scramble_rows
        ],
        dtype=float,
    )
    summary = {
        "design": {
            "method": "independently scrambled randomized Sobol QMC",
            "scrambles": scramble_count,
            "samples_per_scramble": sample_count,
            "total_samples": scramble_count * sample_count,
            "primary_grid_n": int(config["analysis"]["global_range_scan_grid"]),
                "fallback_grid_sequence": [40, 72, 100],
            "gamma1_fixed": 1.0,
            "parameterization": "all kinetic rates and D expressed relative to gamma1",
            "uncertainty_interpretation": (
                "intervals quantify randomized-QMC integration error across "
                "independent scrambles, not biological sampling uncertainty"
            ),
        },
        "bistable_fraction": randomized_qmc_interval(bistable_estimates),
        "fraction_ratio_gt_1e4_given_bistable": randomized_qmc_interval(
            strong_estimates
        ),
        "mfpt_solve_failure_count_after_fallback": int(
            sum(row["mfpt_solve_failure_count"] for row in scramble_rows)
        ),
        "mfpt_fallback_count": int(
            sum(row["mfpt_fallback_count"] for row in scramble_rows)
        ),
        "prcc_top_by_absolute_mean": {},
    }
    for output_name in sorted({row["output"] for row in prcc_summary}):
        selected = [row for row in prcc_summary if row["output"] == output_name]
        selected.sort(key=lambda row: abs(row["mean"]), reverse=True)
        summary["prcc_top_by_absolute_mean"][output_name] = selected[:7]
    with (RESULTS / "randomized_qmc_summary.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    with (RESULTS / "randomized_qmc_repair_report.json").open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            {
                "attempted": len(repaired),
                "succeeded": sum(row["fallback_succeeded"] for row in repaired),
                "records": repaired,
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
