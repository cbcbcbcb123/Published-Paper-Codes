from __future__ import annotations

import csv
import json
import math
from dataclasses import replace
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from fpe import (  # noqa: E402
    Grid,
    build_generator,
    committor_probability,
    core_set_mask,
    deterministic_basin_labels,
    high_state_mass,
    mean_first_passage_time,
    mutual_information,
    stationarity_residual,
    stationary_distribution,
)
from model import (  # noqa: E402
    classify_fixed_points,
    estimate_stiffness_onset,
    fixed_points,
    load_config,
    matched_coupling_scale,
    params_from_config,
    stable_points,
)


RESULTS = ROOT / "results"


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def safe_mfpt(
    generator,
    target: np.ndarray,
    start: tuple[float, float],
    grid: Grid,
) -> float:
    try:
        value, _ = mean_first_passage_time(generator, target, start, grid)
    except Exception:
        return float("nan")
    return float(value)


def reference_states(delta1: float, E_kpa: float, params, coupling_mode: str = "product", coupling_scale: float = 1.0):
    all_points = fixed_points(
        delta1,
        E_kpa,
        params,
        n_grid=8000,
        coupling_mode=coupling_mode,
        coupling_scale=coupling_scale,
    )
    stable = stable_points(
        delta1,
        E_kpa,
        params,
        coupling_mode=coupling_mode,
        coupling_scale=coupling_scale,
    )
    if len(all_points) != 3 or len(stable) != 2:
        raise RuntimeError(
            f"{coupling_mode} reference is not bistable: "
            f"{len(all_points)} fixed points, {len(stable)} stable"
        )
    return stable[0], all_points[1], stable[-1], all_points


def analyze_targets(
    grid_n: int,
    delta1: float,
    E_kpa: float,
    params,
    diffusion: float,
    noise_model: str,
    low_state: tuple[float, float],
    saddle: tuple[float, float],
    high_state: tuple[float, float],
    coupling_mode: str = "product",
    coupling_scale: float = 1.0,
    diffusion_y: float | None = None,
    core_radius: float = 0.04,
    commitment_probability: float = 0.9,
) -> dict:
    grid = Grid.unit_square(grid_n)
    generator = build_generator(
        grid,
        delta1,
        E_kpa,
        params,
        diffusion,
        noise_model=noise_model,
        reference_state=saddle,
        diffusion_y=diffusion_y,
        coupling_mode=coupling_mode,
        coupling_scale=coupling_scale,
    )
    probability = stationary_distribution(generator)
    basins = deterministic_basin_labels(
        grid,
        delta1,
        E_kpa,
        params,
        [low_state, high_state],
        coupling_mode=coupling_mode,
        coupling_scale=coupling_scale,
    )
    low_core = core_set_mask(grid, low_state, core_radius)
    high_core = core_set_mask(grid, high_state, core_radius)
    committor = committor_probability(generator, low_core, high_core)

    basin_forward = safe_mfpt(generator, basins == 1, low_state, grid)
    basin_reverse = safe_mfpt(generator, basins == 0, high_state, grid)
    core_forward = safe_mfpt(generator, high_core, low_state, grid)
    core_reverse = safe_mfpt(generator, low_core, high_state, grid)
    committed_forward = safe_mfpt(
        generator,
        committor >= commitment_probability,
        low_state,
        grid,
    )
    committed_reverse = safe_mfpt(
        generator,
        committor <= (1.0 - commitment_probability),
        high_state,
        grid,
    )

    output = {
        "grid_n": grid_n,
        "noise_model": noise_model,
        "diffusion_x": diffusion,
        "diffusion_y": diffusion if diffusion_y is None else diffusion_y,
        "coupling_mode": coupling_mode,
        "coupling_scale": coupling_scale,
        "stationarity_l1_residual": stationarity_residual(generator, probability),
        "mutual_information_nats": mutual_information(probability, grid),
        "high_basin_mass": high_state_mass(probability, basins),
        "basin_entry_low_to_high": basin_forward,
        "basin_entry_high_to_low": basin_reverse,
        "basin_entry_ratio": basin_reverse / basin_forward,
        "core_radius": core_radius,
        "core_low_to_high": core_forward,
        "core_high_to_low": core_reverse,
        "core_ratio": core_reverse / core_forward,
        "committor_commitment_probability": commitment_probability,
        "committed_low_to_high": committed_forward,
        "committed_high_to_low": committed_reverse,
        "committed_ratio": committed_reverse / committed_forward,
        "probability": probability,
        "basins": basins,
        "committor": committor,
        "grid": grid,
    }
    return output


def serializable_metrics(record: dict) -> dict:
    return {
        key: value
        for key, value in record.items()
        if key not in {"probability", "basins", "committor", "grid"}
    }


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    config = load_config(ROOT / "config" / "canonical_model.json")
    params = params_from_config(config)
    delta1 = float(config["operating_points"]["hcc_reference"]["delta1"])
    E_kpa = float(config["operating_points"]["hcc_reference"]["E_kpa"])
    diffusion = float(config["stochastic"]["D_reference"])
    baseline_grid = int(config["analysis"]["baseline_grid"])
    low_state, saddle, high_state, all_points = reference_states(delta1, E_kpa, params)

    fixed_rows = []
    for index, record in enumerate(
        classify_fixed_points(all_points, delta1, E_kpa, params)
    ):
        fixed_rows.append({"point_index": index, **record})
    write_csv(RESULTS / "baseline_fixed_points.csv", fixed_rows)

    target_rows = []
    for grid_n in config["analysis"]["convergence_grids"]:
        analysis = analyze_targets(
            int(grid_n),
            delta1,
            E_kpa,
            params,
            diffusion,
            "additive_reflecting",
            low_state,
            saddle,
            high_state,
        )
        target_rows.append({"target_definition": "basin_entry", **serializable_metrics(analysis)})
    for radius in config["analysis"]["core_radii"]:
        analysis = analyze_targets(
            baseline_grid,
            delta1,
            E_kpa,
            params,
            diffusion,
            "additive_reflecting",
            low_state,
            saddle,
            high_state,
            core_radius=float(radius),
        )
        target_rows.append(
            {
                "target_definition": f"core_radius_{float(radius):.2f}",
                **serializable_metrics(analysis),
            }
        )
    write_csv(RESULTS / "target_definition_and_grid_sensitivity.csv", target_rows)

    noise_rows = []
    noise_reference_records: dict[str, dict] = {}
    for noise_model in config["analysis"]["noise_models"]:
        for grid_n in [60, 80, 100]:
            analysis = analyze_targets(
                int(grid_n),
                delta1,
                E_kpa,
                params,
                diffusion,
                noise_model,
                low_state,
                saddle,
                high_state,
            )
            noise_rows.append(serializable_metrics(analysis))
            if int(grid_n) == baseline_grid:
                noise_reference_records[noise_model] = analysis
    write_csv(RESULTS / "noise_model_sensitivity.csv", noise_rows)

    boundary_rows = []
    for noise_model, record in noise_reference_records.items():
        probability = record["probability"]
        basins = record["basins"]
        grid = record["grid"]
        low_probability = probability[basins == 0]
        low_total = float(low_probability.sum())
        x_mesh, y_mesh = np.meshgrid(grid.centers, grid.centers)
        for threshold in [0.03, 0.05, 0.10]:
            near_boundary = (x_mesh.ravel() < threshold) | (y_mesh.ravel() < threshold)
            conditional_mass = float(probability[(basins == 0) & near_boundary].sum() / low_total)
            boundary_rows.append(
                {
                    "noise_model": noise_model,
                    "threshold": threshold,
                    "conditional_low_basin_mass_near_boundary": conditional_mass,
                }
            )
    write_csv(RESULTS / "boundary_mass_diagnostics.csv", boundary_rows)

    anisotropic_rows = []
    for diffusion_x, diffusion_y in config["analysis"]["anisotropic_noise_pairs"]:
        analysis = analyze_targets(
            baseline_grid,
            delta1,
            E_kpa,
            params,
            float(diffusion_x),
            "additive_reflecting",
            low_state,
            saddle,
            high_state,
            diffusion_y=float(diffusion_y),
        )
        anisotropic_rows.append(serializable_metrics(analysis))
    write_csv(RESULTS / "anisotropic_noise_sensitivity.csv", anisotropic_rows)

    scale_rows = []
    for rate_scale in [0.5, 1.0, 2.0]:
        scaled_params = replace(
            params,
            alpha1=params.alpha1 * rate_scale,
            alpha2=params.alpha2 * rate_scale,
            delta2=params.delta2 * rate_scale,
            gamma1=params.gamma1 * rate_scale,
            gamma2=params.gamma2 * rate_scale,
        )
        scaled_delta1 = delta1 * rate_scale
        scaled_low, scaled_saddle, scaled_high, _ = reference_states(
            scaled_delta1,
            E_kpa,
            scaled_params,
        )
        analysis = analyze_targets(
            baseline_grid,
            scaled_delta1,
            E_kpa,
            scaled_params,
            diffusion * rate_scale,
            "additive_reflecting",
            scaled_low,
            scaled_saddle,
            scaled_high,
        )
        scale_rows.append({"rate_scale": rate_scale, **serializable_metrics(analysis)})
    write_csv(RESULTS / "rate_scale_invariance.csv", scale_rows)

    coupling_rows = []
    map_rows = []
    product_saddle_x = saddle[0]
    delta1_values = np.linspace(0.3, 2.2, 40)
    stiffness_values = np.linspace(0.2, 30.0, 40)
    for mode in config["analysis"]["coupling_modes"]:
        scale = matched_coupling_scale(
            mode,
            product_saddle_x,
            E_kpa,
            params,
        )
        mode_points = fixed_points(
            delta1,
            E_kpa,
            params,
            n_grid=8000,
            coupling_mode=mode,
            coupling_scale=scale,
        )
        mode_classified = classify_fixed_points(
            mode_points,
            delta1,
            E_kpa,
            params,
            mode,
            scale,
        )
        mode_stable = [
            (record["x"], record["y"])
            for record in mode_classified
            if record["stable"]
        ]
        onset = estimate_stiffness_onset(
            1.4,
            params,
            coupling_mode=mode,
            coupling_scale=scale,
        )
        summary_row = {
            "coupling_mode": mode,
            "matched_scale": scale,
            "reference_fixed_point_count": len(mode_points),
            "reference_stable_count": len(mode_stable),
            "onset_E_kpa_at_delta1_1p4": onset,
        }
        if len(mode_points) == 3 and len(mode_stable) == 2:
            mode_low = mode_stable[0]
            mode_saddle = mode_points[1]
            mode_high = mode_stable[-1]
            analysis = analyze_targets(
                80,
                delta1,
                E_kpa,
                params,
                diffusion,
                "additive_reflecting",
                mode_low,
                mode_saddle,
                mode_high,
                coupling_mode=mode,
                coupling_scale=scale,
            )
            summary_row.update(serializable_metrics(analysis))
        coupling_rows.append(summary_row)

        for scan_delta1 in delta1_values:
            for scan_E in stiffness_values:
                points = fixed_points(
                    float(scan_delta1),
                    float(scan_E),
                    params,
                    n_grid=1600,
                    coupling_mode=mode,
                    coupling_scale=scale,
                )
                classified = classify_fixed_points(
                    points,
                    float(scan_delta1),
                    float(scan_E),
                    params,
                    mode,
                    scale,
                )
                stable_count = sum(record["stable"] for record in classified)
                map_rows.append(
                    {
                        "coupling_mode": mode,
                        "matched_scale": scale,
                        "delta1": float(scan_delta1),
                        "E_kpa": float(scan_E),
                        "stable_state_count": int(stable_count),
                    }
                )
    write_csv(RESULTS / "coupling_structure_sensitivity.csv", coupling_rows)
    write_csv(RESULTS / "coupling_structure_maps.csv", map_rows)

    baseline = noise_reference_records["additive_reflecting"]
    summary = {
        "model_name": config["model_name"],
        "reference_condition": {
            "delta1": delta1,
            "E_kpa": E_kpa,
            "D": diffusion,
            "low_state": low_state,
            "saddle": saddle,
            "high_state": high_state,
        },
        "primary_additive_reflecting": serializable_metrics(baseline),
        "noise_models_grid100": {
            key: serializable_metrics(value)
            for key, value in noise_reference_records.items()
        },
        "interpretation": {
            "mfpt_primary_definition": "first entry into the opposite deterministic basin",
            "core_and_committor_status": "prespecified target-set sensitivity analyses",
            "alternative_noise_normalization": "diffusion matched to D separately in x and y at the reference saddle",
            "coupling_variants": "matched to the product coupling input at the product-model reference saddle",
            "D_and_time_calibration": "not fitted",
        },
    }
    with (RESULTS / "revised_baseline_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    compact = {
        "primary_basin_entry_ratio": baseline["basin_entry_ratio"],
        "primary_core_ratio": baseline["core_ratio"],
        "primary_committed_ratio": baseline["committed_ratio"],
        "noise_model_ratios": {
            key: {
                "basin_entry": value["basin_entry_ratio"],
                "core": value["core_ratio"],
                "committed": value["committed_ratio"],
            }
            for key, value in noise_reference_records.items()
        },
        "coupling_reference_stable_counts": {
            row["coupling_mode"]: row["reference_stable_count"]
            for row in coupling_rows
        },
    }
    print(json.dumps(compact, indent=2))


if __name__ == "__main__":
    main()
