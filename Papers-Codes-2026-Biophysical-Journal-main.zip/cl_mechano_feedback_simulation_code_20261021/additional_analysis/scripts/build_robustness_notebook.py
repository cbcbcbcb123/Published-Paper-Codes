from __future__ import annotations

from pathlib import Path

import nbformat as nbf


ROOT = Path(__file__).resolve().parents[1]
REVISION_DIR = (
    ROOT
    / "figures"
    / "FigS3_model_robustness"
    / "FigS3_model_robustness_v01_20260728"
)
PREFIX = "FigS3_model_robustness_v01_20260728"


def main() -> None:
    notebook = nbf.v4.new_notebook()
    notebook.metadata["kernelspec"] = {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3",
    }
    notebook.metadata["language_info"] = {"name": "python", "version": "3.13"}
    notebook.cells = [
        nbf.v4.new_markdown_cell(
            "# 模型准确性与结构稳健性\n\n"
            "本 Notebook 只读取版本包中保留的模型输出。各面板用于检验 MFPT "
            "目标定义、噪声形式、各向异性、边界质量、共同时间尺度、耦合结构以及"
            "随机化 QMC 推断。"
        ),
        nbf.v4.new_code_cell(
            "from pathlib import Path\n"
            "import numpy as np\n"
            "import pandas as pd\n"
            "import matplotlib as mpl\n"
            "import matplotlib.pyplot as plt\n"
            "from scipy.stats import t\n"
            "from IPython.display import Image, display\n\n"
            f"PREFIX = {PREFIX!r}\n"
            "REVISION_DIR = Path.cwd().resolve()\n"
            "STYLE_SOURCE = 'Existing manuscript Figure 5 visual system'\n"
            "FIGURE_SIZE_IN = (14.0, 7.2)\n"
            "DPI = 400\n"
            "PRIMARY_DATA_NAME = f'01_{PREFIX}_data.csv'\n"
            "PRIMARY_DATA = REVISION_DIR / PRIMARY_DATA_NAME\n"
            "OUTPUT_PNG = REVISION_DIR / f\"04_{PREFIX}.png\"\n"
            "OUTPUT_SVG = REVISION_DIR / f\"05_{PREFIX}.svg\"\n"
            "assert REVISION_DIR.name == PREFIX\n"
        ),
        nbf.v4.new_markdown_cell(
            "## 输入数据\n\n"
            "所有曲线、点、误差区间和注释均由下列 CSV 中的保留模型输出生成；"
            "不使用示例值或手工输入统计量。"
        ),
        nbf.v4.new_code_cell(
            "noise = pd.read_csv(REVISION_DIR / f'01_{PREFIX}_data.csv')\n"
            "targets = pd.read_csv(REVISION_DIR / f'01a_{PREFIX}_data_targets.csv')\n"
            "boundary = pd.read_csv(REVISION_DIR / f'01b_{PREFIX}_data_boundary.csv')\n"
            "anisotropy = pd.read_csv(REVISION_DIR / f'01c_{PREFIX}_data_anisotropy.csv')\n"
            "coupling_summary = pd.read_csv(REVISION_DIR / f'01d_{PREFIX}_data_coupling_summary.csv')\n"
            "coupling_maps = pd.read_csv(REVISION_DIR / f'01e_{PREFIX}_data_coupling_maps.csv')\n"
            "rate_scale = pd.read_csv(REVISION_DIR / f'01f_{PREFIX}_data_rate_scale.csv')\n"
            "qmc_scrambles = pd.read_csv(REVISION_DIR / f'01g_{PREFIX}_data_qmc_scrambles.csv')\n"
            "qmc_prcc = pd.read_csv(REVISION_DIR / f'01h_{PREFIX}_data_qmc_prcc.csv')\n"
            "thresholds = pd.read_csv(REVISION_DIR / f'01i_{PREFIX}_data_noise_thresholds.csv')\n"
        ),
        nbf.v4.new_markdown_cell(
            "## 绘图\n\n"
            "视觉语言沿用现有 Figure 5：Arial、蓝/红状态色、紫色动力学曲线、"
            "橙色参考条件和简洁白底。纵轴跨度较大时使用对数尺度。"
        ),
        nbf.v4.new_code_cell(
            r"""
mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.size": 8.2,
        "axes.titlesize": 9.0,
        "axes.labelsize": 8.5,
        "axes.linewidth": 0.9,
        "xtick.labelsize": 7.4,
        "ytick.labelsize": 7.4,
        "legend.fontsize": 7.0,
        "legend.frameon": False,
        "svg.fonttype": "none",
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    }
)

COLORS = {
    "red": "#FF4A4A",
    "blue": "#5F97CF",
    "orange": "#F28E2B",
    "purple": "#8E63B6",
    "teal": "#17A2A4",
    "green": "#55B879",
    "gray": "#6B6B6B",
    "black": "#111111",
    "light": "#D9D9D9",
}
noise_labels = {
    "additive_reflecting": "additive + reflection",
    "jacobi": "Jacobi mobility",
    "logit": "logit mobility",
}
noise_colors = {
    "additive_reflecting": COLORS["purple"],
    "jacobi": COLORS["teal"],
    "logit": COLORS["orange"],
}

figure = plt.figure(figsize=FIGURE_SIZE_IN)
grid_spec = figure.add_gridspec(2, 4, hspace=0.48, wspace=0.42)
axes = [figure.add_subplot(grid_spec[row, column]) for row in range(2) for column in range(4)]

# A: Target-definition sensitivity at the 100 x 100 primary model.
axis = axes[0]
primary_grid100 = targets[
    (targets["target_definition"] == "basin_entry") & (targets["grid_n"] == 100)
].iloc[0]
core_rows = targets[targets["target_definition"].str.startswith("core_radius")].copy()
core_rows = core_rows.sort_values("core_radius")
target_labels = ["basin\nentry"] + [
    f"core\nr={radius:.2f}" for radius in core_rows["core_radius"]
] + ["committor\nq=0.9"]
target_values = [primary_grid100["basin_entry_ratio"]] + core_rows["core_ratio"].tolist() + [
    primary_grid100["committed_ratio"]
]
axis.plot(
    np.arange(len(target_values)),
    target_values,
    color=COLORS["purple"],
    marker="o",
    lw=2,
)
axis.set_yscale("log")
axis.set_xticks(np.arange(len(target_values)), target_labels, rotation=0)
axis.set_ylabel(r"$T_{H\to L}/T_{L\to H}$")
axis.set_title("MFPT endpoint definition")

# B: Noise-form sensitivity for three endpoint definitions.
axis = axes[1]
noise100 = noise[noise["grid_n"] == 100].copy()
positions = np.arange(len(noise100))
for offset, column, label, color, marker in [
    (-0.16, "basin_entry_ratio", "basin entry", COLORS["purple"], "o"),
    (0.00, "core_ratio", "core r=0.04", COLORS["blue"], "s"),
    (0.16, "committed_ratio", "committor", COLORS["orange"], "^"),
]:
    axis.scatter(
        positions + offset,
        noise100[column],
        label=label,
        color=color,
        marker=marker,
        s=30,
        zorder=3,
    )
axis.set_yscale("log")
axis.set_xticks(
    positions,
    [noise_labels[value] for value in noise100["noise_model"]],
    rotation=18,
    ha="right",
)
axis.set_ylabel(r"$T_{H\to L}/T_{L\to H}$")
axis.set_title("Stochastic model form")
axis.legend(loc="upper right")

# C: Anisotropic additive noise at fixed Dx + Dy.
axis = axes[2]
anisotropy = anisotropy.sort_values("diffusion_x")
x_fraction = anisotropy["diffusion_x"] / (
    anisotropy["diffusion_x"] + anisotropy["diffusion_y"]
)
axis.plot(
    x_fraction,
    anisotropy["basin_entry_ratio"],
    color=COLORS["purple"],
    marker="o",
    lw=2,
    label="basin entry",
)
axis.plot(
    x_fraction,
    anisotropy["core_ratio"],
    color=COLORS["blue"],
    marker="s",
    lw=1.6,
    label="core r=0.04",
)
axis.axvline(0.5, color=COLORS["gray"], ls="--", lw=1)
axis.set_yscale("log")
axis.set_xlabel(r"$D_x/(D_x+D_y)$")
axis.set_ylabel(r"$T_{H\to L}/T_{L\to H}$")
axis.set_title("Noise anisotropy")
axis.legend()

# D: Conditional low-basin mass near the lower boundary.
axis = axes[3]
for noise_model, group in boundary.groupby("noise_model"):
    group = group.sort_values("threshold")
    axis.plot(
        group["threshold"],
        group["conditional_low_basin_mass_near_boundary"],
        marker="o",
        lw=1.8,
        color=noise_colors[noise_model],
        label=noise_labels[noise_model],
    )
axis.set_xlabel("boundary threshold")
axis.set_ylabel("conditional low-basin mass")
axis.set_ylim(0, 0.70)
axis.set_title("Low-state boundary proximity")
axis.legend()

# E: Common-rate/time-scale invariance.
axis = axes[4]
reference = rate_scale.loc[np.isclose(rate_scale["rate_scale"], 1.0)].iloc[0]
for column, label, color, marker in [
    ("high_basin_mass", "high-basin mass", COLORS["red"], "o"),
    ("basin_entry_ratio", "MFPT ratio", COLORS["purple"], "s"),
    ("mutual_information_nats", "mutual information", COLORS["teal"], "^"),
]:
    axis.plot(
        rate_scale["rate_scale"],
        rate_scale[column] / reference[column],
        marker=marker,
        lw=1.8,
        color=color,
        label=label,
    )
scaled_reverse = (
    rate_scale["rate_scale"]
    * rate_scale["basin_entry_high_to_low"]
    / reference["basin_entry_high_to_low"]
)
axis.plot(
    rate_scale["rate_scale"],
    scaled_reverse,
    color=COLORS["blue"],
    marker="D",
    lw=1.5,
    label=r"scale $\times T_{H\to L}$",
)
axis.axhline(1.0, color=COLORS["gray"], lw=0.8, ls=":")
axis.set_xlabel("common rate and D scale")
axis.set_ylabel("value / reference")
axis.set_ylim(0.96, 1.04)
axis.set_title("Time-scale gauge invariance")
axis.legend(loc="lower center")

# F: Coupling-structure dependence.
axis = axes[5]
for coupling_mode, group in coupling_maps.groupby("coupling_mode"):
    summary_by_E = group.groupby("E_kpa")["stable_state_count"].apply(
        lambda values: np.mean(values == 2)
    )
    style = {
        "product": (COLORS["purple"], "-"),
        "additive": (COLORS["orange"], "--"),
        "threshold": (COLORS["teal"], "-."),
    }[coupling_mode]
    axis.plot(
        summary_by_E.index,
        summary_by_E.values,
        color=style[0],
        ls=style[1],
        lw=2,
        label=coupling_mode,
    )
axis.axvline(15.0, color=COLORS["gray"], ls=":", lw=1)
axis.set_xlabel("ECM stiffness (kPa)")
axis.set_ylabel("fraction bistable across delta1 scan")
axis.set_ylim(-0.02, 1.02)
axis.set_title("Stiffness-coupling structure")
axis.legend()

# G: Independent randomized-QMC scramble estimates.
axis = axes[6]
metrics = [
    ("bistable_fraction", "bistable"),
    ("fraction_ratio_gt_1e4_given_bistable", r"ratio $>10^4$"),
]
for metric_index, (column, label) in enumerate(metrics):
    values = qmc_scrambles[column].dropna().to_numpy()
    horizontal = np.full(values.size, metric_index, dtype=float)
    jitter = np.linspace(-0.08, 0.08, values.size)
    axis.scatter(
        horizontal + jitter,
        values,
        color=[COLORS["teal"], COLORS["purple"]][metric_index],
        s=25,
        alpha=0.85,
    )
    mean = values.mean()
    standard_error = values.std(ddof=1) / np.sqrt(values.size)
    half_width = t.ppf(0.975, values.size - 1) * standard_error
    axis.errorbar(
        metric_index,
        mean,
        yerr=half_width,
        color=COLORS["black"],
        marker="_",
        ms=14,
        capsize=4,
        lw=1.3,
        zorder=4,
    )
axis.set_xticks([0, 1], [label for _, label in metrics])
axis.set_ylim(0, 0.75)
axis.set_ylabel("range-scan fraction")
axis.set_title("Randomized QMC replicates")
axis.text(
    0.03,
    0.97,
    f"{len(qmc_scrambles)} independent scrambles",
    transform=axis.transAxes,
    va="top",
    fontsize=7.0,
)

# H: Across-scramble PRCC summary, conditional on bistability.
axis = axes[7]
prcc_ratio = qmc_prcc[qmc_prcc["output"] == "log10_basin_entry_ratio"].copy()
prcc_ratio["absolute_mean"] = prcc_ratio["mean"].abs()
prcc_ratio = prcc_ratio.sort_values("absolute_mean").tail(7)
y_positions = np.arange(len(prcc_ratio))
lower_error = prcc_ratio["mean"] - prcc_ratio["randomized_qmc_95_low"]
upper_error = prcc_ratio["randomized_qmc_95_high"] - prcc_ratio["mean"]
axis.barh(
    y_positions,
    prcc_ratio["mean"],
    color=[
        COLORS["red"] if value > 0 else COLORS["blue"]
        for value in prcc_ratio["mean"]
    ],
    alpha=0.88,
)
axis.errorbar(
    prcc_ratio["mean"],
    y_positions,
    xerr=np.vstack([lower_error, upper_error]),
    fmt="none",
    ecolor=COLORS["black"],
    capsize=2,
    lw=0.9,
)
label_map = {
    "K2": "K2",
    "K1": "K1",
    "delta2_over_gamma1": "delta2/gamma1",
    "gamma2_over_gamma1": "gamma2/gamma1",
    "delta1_over_gamma1": "delta1/gamma1",
    "n": "n",
    "m": "m",
}
labels = [label_map.get(value, value) for value in prcc_ratio["parameter"]]
axis.set_yticks(y_positions, labels)
axis.axvline(0.0, color=COLORS["gray"], lw=0.8)
axis.set_xlabel("partial rank correlation")
axis.set_title("Dimensionless sensitivity")

for panel_index, axis in enumerate(axes):
    axis.text(
        -0.17,
        1.08,
        chr(ord("A") + panel_index),
        transform=axis.transAxes,
        fontsize=14,
        fontweight="bold",
        va="top",
    )
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)

figure.suptitle(
    "Model-form, endpoint, and randomized-QMC robustness",
    fontsize=12,
    y=1.01,
)
figure.savefig(OUTPUT_PNG, dpi=DPI, bbox_inches="tight", pad_inches=0.05)
figure.savefig(OUTPUT_SVG, bbox_inches="tight", pad_inches=0.05)
plt.show()
""".strip()
        ),
        nbf.v4.new_markdown_cell(
            "## 输出预览\n\n"
            "最后显示本版本包实际生成的 PNG，用于视觉验收。"
        ),
        nbf.v4.new_code_cell(
            "display(Image(filename=str(OUTPUT_PNG)))"
        ),
    ]
    destination = REVISION_DIR / f"03_{PREFIX}_plot.ipynb"
    nbf.write(notebook, destination)
    methods_path = REVISION_DIR / f"02_{PREFIX}_methods.txt"
    methods_path.write_text(
        """# 图件方法与验证记录
## 人工填写内容
- 风格来源: 沿用现有稿件 Figure 5 视觉系统（Arial；蓝/红状态色；紫色动力学曲线；橙色参考条件；白底）。
- 用户提供的期刊规格: 未指定；按现有稿件视觉系统执行。
- 03_材料方法来源: `../../../config/canonical_model.json`、`../../../src/` 与 `../../../scripts/`；均属于 `Fig2_Fig3_Fig5_mechanochemical_model_v02_20260728`。
- 数据/模型变换: 各面板只读取版本包保留的 CSV，不手工输入数值。跨数量级比值使用对数轴；耦合结构图按每个刚度下扫描的 delta1 中具有两个稳定状态的比例汇总。
- 统计方法与不确定性: 随机化 QMC 区间是独立 scramble 估计值的 t 区间，仅量化随机化积分误差。PRCC 在每个 scramble 内、条件于有限双稳态样本分别计算；不使用逐行 bootstrap 或 Wilson 区间。
- 生物学分组颜色: 不适用；颜色编码分析类型或模型形式，不编码生物学分组。
- 人工/代理视觉验收: 待检查
## 自动记录
<!-- 自动记录开始 -->
- 前缀: FigS3_model_robustness_v01_20260728
- 包状态: 工作版本
- 创建日期: 20260728
- 执行时间: 待执行
- 自动校验: 待执行
- 颜色配置 SHA-256: 不适用
- Notebook SHA-256: 待校验
- 文件 SHA-256: 待校验
- Python 与主要库版本: 待校验
<!-- 自动记录结束 -->
""",
        encoding="utf-8",
    )
    print(f"wrote {destination}")


if __name__ == "__main__":
    main()
