from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INCLUDED_SUFFIXES = {".py", ".json", ".txt", ".csv", ".md", ".ipynb", ".png", ".svg"}
EXCLUDED_NAMES = {"audit_manifest_sha256.json"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    records = []
    for path in sorted(ROOT.rglob("*")):
        if (
            not path.is_file()
            or path.name in EXCLUDED_NAMES
            or path.suffix.lower() not in INCLUDED_SUFFIXES
            or "__pycache__" in path.parts
        ):
            continue
        records.append(
            {
                "path": path.relative_to(ROOT).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    output = {
        "package": ROOT.name,
        "file_count": len(records),
        "files": records,
    }
    destination = ROOT / "reports" / "audit_manifest_sha256.json"
    destination.write_text(
        json.dumps(output, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"wrote {destination} with {len(records)} records")


if __name__ == "__main__":
    main()
