from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
import torch

from model import ModelParams


torch.set_default_dtype(torch.float64)
torch.set_num_threads(1)


@dataclass
class MinimumActionResult:
    path: np.ndarray
    action: float
    objective: float
    iterations: int
    restart: int
    gradient_norm: float
    segment_cv: float
    converged: bool


def _torch_hill(value: torch.Tensor, exponent: float, half: float) -> torch.Tensor:
    numerator = torch.pow(value, exponent)
    return numerator / (half**exponent + numerator)


def _torch_drift(
    points: torch.Tensor,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
) -> torch.Tensor:
    x_value = points[..., 0]
    y_value = points[..., 1]
    mech = E_kpa**params.p_mech / (params.Ec_kpa**params.p_mech + E_kpa**params.p_mech)
    source_x = params.alpha1 + delta1 * _torch_hill(y_value, params.m, params.K1)
    source_y = params.alpha2 + params.delta2 * mech * _torch_hill(x_value, params.n, params.K2)
    drift_x = source_x * (1.0 - x_value) - params.gamma1 * x_value
    drift_y = source_y * (1.0 - y_value) - params.gamma2 * y_value
    return torch.stack((drift_x, drift_y), dim=-1)


def geometric_action_tensor(
    path: torch.Tensor,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
) -> torch.Tensor:
    increments = path[1:] - path[:-1]
    midpoints = 0.5 * (path[1:] + path[:-1])
    field = _torch_drift(midpoints, delta1, E_kpa, params)
    increment_norm = torch.linalg.vector_norm(increments, dim=1)
    field_norm = torch.linalg.vector_norm(field, dim=1)
    dot_product = torch.sum(field * increments, dim=1)
    return 0.5 * torch.sum(field_norm * increment_norm - dot_product)


def geometric_action(path: np.ndarray, delta1: float, E_kpa: float, params: ModelParams) -> float:
    tensor = torch.as_tensor(path, dtype=torch.float64)
    return float(geometric_action_tensor(tensor, delta1, E_kpa, params).detach().cpu())


def _logit(values: np.ndarray) -> np.ndarray:
    clipped = np.clip(values, 1e-7, 1.0 - 1e-7)
    return np.log(clipped / (1.0 - clipped))


def minimum_action_path(
    start: tuple[float, float],
    end: tuple[float, float],
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    nodes: int = 48,
    restarts: int = 3,
    adam_steps: int = 1200,
    lbfgs_steps: int = 250,
    penalty_weight: float = 0.05,
    gradient_tolerance: float = 2e-5,
    seed: int = 20260712,
) -> MinimumActionResult:
    if nodes < 8:
        raise ValueError("nodes must be at least 8")
    rng = np.random.default_rng(seed)
    start_array = np.asarray(start, dtype=float)
    end_array = np.asarray(end, dtype=float)
    parameter = np.linspace(0.0, 1.0, nodes)[:, None]
    base_path = start_array[None, :] + parameter * (end_array - start_array)[None, :]
    direction = end_array - start_array
    perpendicular = np.array([-direction[1], direction[0]], dtype=float)
    perpendicular /= max(np.linalg.norm(perpendicular), 1e-12)
    best: MinimumActionResult | None = None

    for restart_index in range(restarts):
        trial = base_path.copy()
        if restart_index > 0:
            amplitude = (0.025 + 0.02 * restart_index) * (-1.0 if restart_index % 2 else 1.0)
            trial += amplitude * np.sin(math.pi * parameter) * perpendicular[None, :]
            trial[1:-1] += rng.normal(0.0, 0.002, size=(nodes - 2, 2))
        trial = np.clip(trial, 1e-6, 1.0 - 1e-6)
        interior_logits = torch.nn.Parameter(torch.as_tensor(_logit(trial[1:-1]), dtype=torch.float64))
        optimizer = torch.optim.Adam([interior_logits], lr=0.03)
        last_objective = float("inf")

        def objective_tensor() -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
            interior = torch.sigmoid(interior_logits)
            path = torch.cat(
                [
                    torch.as_tensor(start_array[None, :]),
                    interior,
                    torch.as_tensor(end_array[None, :]),
                ],
                dim=0,
            )
            increments = path[1:] - path[:-1]
            lengths = torch.linalg.vector_norm(increments, dim=1)
            regularizer = torch.var(lengths / torch.mean(lengths), unbiased=False)
            action = geometric_action_tensor(path, delta1, E_kpa, params)
            return action + penalty_weight * regularizer, action, path

        completed_adam_steps = 0
        for step_index in range(adam_steps):
            optimizer.zero_grad()
            objective, _, _ = objective_tensor()
            objective.backward()
            optimizer.step()
            current_objective = float(objective.detach().cpu())
            completed_adam_steps = step_index + 1
            if abs(last_objective - current_objective) <= 1e-11 * max(1.0, abs(current_objective)):
                if step_index > 200:
                    break
            last_objective = current_objective

        lbfgs = torch.optim.LBFGS(
            [interior_logits],
            lr=0.8,
            max_iter=lbfgs_steps,
            tolerance_grad=gradient_tolerance,
            tolerance_change=1e-12,
            line_search_fn="strong_wolfe",
        )

        def closure() -> torch.Tensor:
            lbfgs.zero_grad()
            objective, _, _ = objective_tensor()
            objective.backward()
            return objective

        lbfgs.step(closure)

        interior_logits.grad = None
        final_objective_tensor, final_action_tensor, final_path = objective_tensor()
        final_objective_tensor.backward()
        gradient_norm = float(torch.linalg.vector_norm(interior_logits.grad).detach().cpu())
        final_action = float(final_action_tensor.detach().cpu())
        final_objective = float(final_objective_tensor.detach().cpu())
        segment_lengths = torch.linalg.vector_norm(final_path[1:] - final_path[:-1], dim=1)
        segment_cv = float((torch.std(segment_lengths, unbiased=False) / torch.mean(segment_lengths)).detach().cpu())
        result = MinimumActionResult(
            path=final_path.detach().cpu().numpy(),
            action=final_action,
            objective=final_objective,
            iterations=completed_adam_steps + lbfgs_steps,
            restart=restart_index,
            gradient_norm=gradient_norm,
            segment_cv=segment_cv,
            converged=bool(gradient_norm <= 5.0 * gradient_tolerance and segment_cv <= 0.15),
        )
        if best is None or result.objective < best.objective:
            best = result
    assert best is not None
    return best
