from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import json
from pathlib import Path
from typing import Iterable, Literal

import numpy as np
from scipy.optimize import brentq


CouplingMode = Literal["product", "additive", "threshold"]


@dataclass(frozen=True)
class ModelParams:
    alpha1: float = 0.05
    alpha2: float = 0.05
    delta2: float = 2.0
    K1: float = 0.4
    K2: float = 0.4
    m: float = 3.0
    n: float = 3.0
    gamma1: float = 1.0
    gamma2: float = 1.0
    Ec_kpa: float = 5.0
    p_mech: float = 2.0

    def updated(self, **kwargs: float) -> "ModelParams":
        return replace(self, **kwargs)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


def load_config(path: str | Path) -> dict:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def params_from_config(config: dict) -> ModelParams:
    return ModelParams(**config["parameters"])


def hill(value: np.ndarray | float, exponent: float, half: float):
    value_array = np.asarray(value, dtype=float)
    numerator = np.power(value_array, exponent)
    result = numerator / (np.power(half, exponent) + numerator)
    return float(result) if np.isscalar(value) else result


def hill_derivative(value: np.ndarray | float, exponent: float, half: float):
    value_array = np.asarray(value, dtype=float)
    denominator = np.power(half, exponent) + np.power(value_array, exponent)
    result = exponent * np.power(half, exponent) * np.power(value_array, exponent - 1.0) / np.square(denominator)
    return float(result) if np.isscalar(value) else result


def mechanosensing(E_kpa: np.ndarray | float, params: ModelParams):
    E_array = np.asarray(E_kpa, dtype=float)
    numerator = np.power(E_array, params.p_mech)
    result = numerator / (np.power(params.Ec_kpa, params.p_mech) + numerator)
    return float(result) if np.isscalar(E_kpa) else result


def coupling_value(
    x: np.ndarray | float,
    E_kpa: float,
    params: ModelParams,
    mode: CouplingMode = "product",
):
    """Dimensionless ITGB1/stiffness input used by the YAP/TEAD equation.

    The product model is the manuscript model. The other two forms are
    prespecified structural-sensitivity models, not fitted alternatives.
    """
    mech = mechanosensing(E_kpa, params)
    activity = hill(x, params.n, params.K2)
    if mode == "product":
        return mech * activity
    if mode == "additive":
        return 0.5 * (mech + activity)
    if mode == "threshold":
        effective_half = params.K2 / max(float(mech), 1e-12)
        return hill(x, params.n, effective_half)
    raise ValueError(f"unsupported coupling mode: {mode}")


def coupling_derivative_x(
    x: np.ndarray | float,
    E_kpa: float,
    params: ModelParams,
    mode: CouplingMode = "product",
):
    mech = mechanosensing(E_kpa, params)
    if mode == "product":
        return mech * hill_derivative(x, params.n, params.K2)
    if mode == "additive":
        return 0.5 * hill_derivative(x, params.n, params.K2)
    if mode == "threshold":
        effective_half = params.K2 / max(float(mech), 1e-12)
        return hill_derivative(x, params.n, effective_half)
    raise ValueError(f"unsupported coupling mode: {mode}")


def matched_coupling_scale(
    mode: CouplingMode,
    reference_x: float,
    reference_E_kpa: float,
    params: ModelParams,
) -> float:
    """Match each structural variant to the product input at one reference point."""
    product_value = float(coupling_value(reference_x, reference_E_kpa, params, "product"))
    candidate_value = float(coupling_value(reference_x, reference_E_kpa, params, mode))
    if candidate_value <= 0.0:
        raise ValueError("candidate coupling is zero at the matching point")
    return product_value / candidate_value


def drift(
    x: np.ndarray | float,
    y: np.ndarray | float,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> tuple[np.ndarray | float, np.ndarray | float]:
    source_x = params.alpha1 + delta1 * hill(y, params.m, params.K1)
    source_y = params.alpha2 + params.delta2 * coupling_scale * coupling_value(
        x, E_kpa, params, coupling_mode
    )
    drift_x = source_x * (1.0 - np.asarray(x)) - params.gamma1 * np.asarray(x)
    drift_y = source_y * (1.0 - np.asarray(y)) - params.gamma2 * np.asarray(y)
    if np.isscalar(x) and np.isscalar(y):
        return float(drift_x), float(drift_y)
    return drift_x, drift_y


def x_nullcline(y: np.ndarray | float, delta1: float, params: ModelParams):
    source = params.alpha1 + delta1 * hill(y, params.m, params.K1)
    return source / (source + params.gamma1)


def y_nullcline(
    x: np.ndarray | float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
):
    source = params.alpha2 + params.delta2 * coupling_scale * coupling_value(
        x, E_kpa, params, coupling_mode
    )
    return source / (source + params.gamma2)


def self_consistency(
    y: float,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> float:
    return float(
        y_nullcline(
            x_nullcline(y, delta1, params),
            E_kpa,
            params,
            coupling_mode,
            coupling_scale,
        )
        - y
    )


def fixed_points(
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    n_grid: int = 5000,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> list[tuple[float, float]]:
    y_values = np.linspace(1e-9, 1.0 - 1e-9, n_grid)
    # Vectorized scan is mathematically identical to scalar evaluation and is
    # important for high-dimensional range scans with thousands of root grids.
    values = np.asarray(
        y_nullcline(
            x_nullcline(y_values, delta1, params),
            E_kpa,
            params,
            coupling_mode,
            coupling_scale,
        )
        - y_values,
        dtype=float,
    )
    points: list[tuple[float, float]] = []
    for index in range(n_grid - 1):
        left_value = values[index]
        right_value = values[index + 1]
        if left_value == 0.0 or left_value * right_value < 0.0:
            root_y = brentq(
                self_consistency,
                y_values[index],
                y_values[index + 1],
                args=(delta1, E_kpa, params, coupling_mode, coupling_scale),
                xtol=1e-13,
                rtol=1e-13,
            )
            if points and abs(root_y - points[-1][1]) < 1e-8:
                continue
            points.append((float(x_nullcline(root_y, delta1, params)), float(root_y)))
    return points


def jacobian(
    x: float,
    y: float,
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> np.ndarray:
    source_x = params.alpha1 + delta1 * hill(y, params.m, params.K1)
    source_y = params.alpha2 + params.delta2 * coupling_scale * coupling_value(
        x, E_kpa, params, coupling_mode
    )
    return np.array(
        [
            [
                -(source_x + params.gamma1),
                delta1 * hill_derivative(y, params.m, params.K1) * (1.0 - x),
            ],
            [
                params.delta2
                * coupling_scale
                * coupling_derivative_x(x, E_kpa, params, coupling_mode)
                * (1.0 - y),
                -(source_y + params.gamma2),
            ],
        ],
        dtype=float,
    )


def classify_fixed_points(
    points: Iterable[tuple[float, float]],
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> list[dict]:
    records = []
    for x_value, y_value in points:
        eigenvalues = np.linalg.eigvals(
            jacobian(
                x_value,
                y_value,
                delta1,
                E_kpa,
                params,
                coupling_mode,
                coupling_scale,
            )
        )
        records.append(
            {
                "x": float(x_value),
                "y": float(y_value),
                "eigenvalue_1_real": float(np.real(eigenvalues[0])),
                "eigenvalue_2_real": float(np.real(eigenvalues[1])),
                "stable": bool(np.all(np.real(eigenvalues) < 0.0)),
            }
        )
    return records


def stable_points(
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> list[tuple[float, float]]:
    records = classify_fixed_points(
        fixed_points(
            delta1,
            E_kpa,
            params,
            coupling_mode=coupling_mode,
            coupling_scale=coupling_scale,
        ),
        delta1,
        E_kpa,
        params,
        coupling_mode,
        coupling_scale,
    )
    return [(record["x"], record["y"]) for record in records if record["stable"]]


def is_bistable(
    delta1: float,
    E_kpa: float,
    params: ModelParams,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> bool:
    return len(stable_points(delta1, E_kpa, params, coupling_mode, coupling_scale)) == 2


def estimate_stiffness_onset(
    delta1: float,
    params: ModelParams,
    lower: float = 0.2,
    upper: float = 40.0,
    scan_points: int = 160,
    coupling_mode: CouplingMode = "product",
    coupling_scale: float = 1.0,
) -> float:
    scan = np.linspace(lower, upper, scan_points)
    states = [
        is_bistable(
            delta1,
            float(value),
            params,
            coupling_mode,
            coupling_scale,
        )
        for value in scan
    ]
    if not any(states):
        return float("nan")
    first_index = states.index(True)
    if first_index == 0:
        return float(scan[0])
    low_value = float(scan[first_index - 1])
    high_value = float(scan[first_index])
    for _ in range(35):
        middle = 0.5 * (low_value + high_value)
        if is_bistable(delta1, middle, params, coupling_mode, coupling_scale):
            high_value = middle
        else:
            low_value = middle
    return high_value
