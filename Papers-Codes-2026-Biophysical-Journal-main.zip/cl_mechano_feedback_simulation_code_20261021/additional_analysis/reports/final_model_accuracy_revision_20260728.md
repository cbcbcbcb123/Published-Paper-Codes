# Final model-accuracy revision

## Outcome

The original product-coupled deterministic model remains a valid conditional
mechanistic scenario, but the strongest numerical claim is not universal.
The defensible conclusion is:

> The specified ITGB1–YAP/TEAD product-coupling circuit can generate
> stiffness-sensitive bistability and directionally stabilize its
> high-activity state. The direction is robust across the tested endpoint and
> bounded-noise alternatives, whereas the magnitude of the MFPT asymmetry and
> even the presence of bistability depend on model form.

## Canonical reference result

At delta1 = 1.5, E = 15 kPa, and D = 0.008, the deterministic states are
L = (0.050403, 0.050868), S = (0.213160, 0.222756), and
H = (0.538070, 0.570048). On the 100 x 100 primary additive-reflecting
generator:

- high-basin stationary mass = 0.997728;
- mutual information = 0.121087 nats;
- basin-entry MFPT L to H = 5.45775;
- basin-entry MFPT H to L = 2172.33;
- H-to-L / L-to-H ratio = 398.03.

This ratio is a dimensionless reference-scenario output, not a measured
biological time-scale ratio.

## Robustness findings

- Endpoint definition: attractor-core radii 0.02–0.10 give ratios 365–428;
  the 0.9 committor-defined target gives 518.
- Bounded stochastic form at saddle-matched diffusion: the basin-entry ratio
  is 398 for additive reflection, 93 for conservative Jacobi mobility, and 27
  for squared bounded ("logit-mobility") diffusion.
- Noise anisotropy at fixed Dx + Dy = 0.016 gives basin-entry ratios 351–597.
- Boundary proximity is material: under the primary model, 33.6% of the
  stationary low-basin mass lies at x < 0.05 or y < 0.05.
- Common rate and D rescaling leaves stationary masses, mutual information,
  and MFPT ratios invariant; absolute MFPTs rescale inversely.
- Structural sensitivity: input-matched product and
  stiffness-dependent-threshold couplings remain bistable at the reference
  condition, but the matched additive coupling is monostable. Bistability is
  therefore not structure-independent.

The state-dependent alternatives are defined by conservative Fickian flux
`b_i p - D_i g_i partial_i p`. Their equivalent Ito drift is
`b_i + D_i partial_i g_i`; the code, manuscript, and generator-moment test use
this same convention.

## Global randomized-QMC result

Eight independent scrambled-Sobol replicates with 512 points each
(4096 evaluations; gamma1 fixed to one) give:

- bistable range fraction = 0.541, randomized-QMC interval 0.525–0.556;
- conditional fraction with basin-entry ratio above 10^4 = 0.196,
  interval 0.183–0.209.

Six ill-conditioned extreme samples were rerun on prespecified fallback grids
and all were resolved. The intervals quantify randomized numerical integration
error under the chosen parameter-range measure, not biological population
uncertainty.

## Remaining scientific limits

The revision does not claim to solve constraints that require new data:

- x and y remain latent activities without a calibrated observation model;
- TCGA bulk-RNA and public scRNA-seq constrain plausibility, not stochastic
  state distributions or ECM stiffness;
- ECM stiffness is externally fixed rather than dynamically co-evolving;
- D and the physical time unit remain uncalibrated;
- product stiffness coupling remains an explicit modeling assumption.

These limits are now stated in the title/abstract framing, Results, Methods,
Discussion, Conclusion, figure legends, and parameter table.

## Verification

- automated theory tests: 13 passed;
- randomized-QMC fallback failures after repair: 0;
- Supplementary Fig. S3: executable notebook, PNG/SVG, automated validation,
  and visual QA completed before the figure package was frozen;
- manuscript: 34-page render inspected; final DOCX ZIP/XML integrity,
  paragraph insertions, image count, table row non-splitting, and cell
  alignment verified;
- SHA-256 evidence manifest: `reports/audit_manifest_sha256.json`.
