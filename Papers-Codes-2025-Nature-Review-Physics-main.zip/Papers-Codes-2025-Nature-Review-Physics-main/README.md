Codes for paper "Mechanobiology across timescales"
