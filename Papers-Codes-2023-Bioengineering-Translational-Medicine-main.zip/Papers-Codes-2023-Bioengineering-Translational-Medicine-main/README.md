Codes for paper "Mechanochemical coupling of MGF mediates periodontal regeneration"
